---
name: web-clone
en_name: Website Clone
zh_name: 网站复刻
description: >
  网站复刻 / 克隆方法论。USE WHEN 用户说 复刻网站、克隆网站、clone website、抄个站、仿站、
  照着这个站做一个、reproduce site、还原某个网页效果、把这个站搬下来改成我的、
  复刻某个交互/WebGL/Canvas/Three.js 效果。提供「先拿真源码 → 判路径 → 逆向拆解 →
  搭工程 → 替换内容」的可移植决策树，覆盖静态站 / React-Vue-Next 内容站 /
  WebGL-Canvas 重前端站三大分支，并强制核对任何 AI 二手分析里的可执行代码。
triggers:
  - "网站复刻"
  - "复刻网站"
  - "clone website"
  - "reproduce site"
  - "仿站"
metadata:
  author: jane (xiaoer)
  version: "1.6.1"
  use_case: 个人本地复刻/学习网站，沉淀自 website-clones 克隆中枢
od:
  mode: prototype
  scenario: web-clone
  surface: web
  design_system:
    requires: false
---

# Web Clone · 网站复刻方法论

把"复刻一个网站"做成可重复的流程。在 OpenDesign 中，默认在当前项目目录工作：`NOTES.md`、`RECON/`、`CLONE_REPORT.md`、`CLONE_AUDIT.md` 和最终可预览的 `index.html` 都应写在当前项目内，除非用户明确指定外部工作目录。

**OpenDesign 环境准备（跑任何 `scripts/` 前先看）**：
- 本 skill 的脚本会被 stage 到项目内 `.od-skills/<插件目录>/scripts/`（skill 前言里有确切路径）。文中命令写的 `node scripts/xxx.mjs` 按该路径解析，例如 `node .od-skills/<插件目录>/scripts/recon-site.mjs ...`；`RECON/`、`assets/` 等产物仍写到项目根。
- 脚本内置基于 Chrome DevTools Protocol 的零依赖控制层，直接复用系统已有的 Chrome、Edge 或 Chromium；无需启动 Electron 客户端，也支持纯 `od` CLI。Agent 沙箱内会通过本地 daemon 创建临时 CDP 会话，避免沙箱阻止 Chrome 子进程。**禁止在用户项目里执行 `npm install playwright` 或下载 Chromium。** 若预检报告没有兼容浏览器，直接说明缺少系统浏览器或通过 `OD_BROWSER_EXECUTABLE_PATH` 指定路径，不要改为目测，也不要反复安装依赖。源码开发环境若已经提供 `OD_PLAYWRIGHT_PACKAGE`，脚本仍兼容该运行时，但它不是产品链路的前置条件。

## 头号铁律：真源码至上，绝不信 AI 推测的代码

> 任何 AI 生成的"复刻分析/施工图"，**正文的概念骨架可以参考，但里面的可执行代码块默认全是臆造的**，必须逐行用真源码核对，否则照抄必崩。

**实证（marbles 案例）**：一份 AI 分析文档把原站"解析法求光线-球体交点 + 把光学结果编码成位移图、交给 SVG `feDisplacementMap` 去扭曲真实 DOM"的真架构，臆造成了"ray-marching + SDF + 把 DOM 当纹理采样"——两套完全不同的实现，照抄做不出原效果且慢 N 倍。详见 `references/marbles-case.md`。

所以第一动作永远是：**拿到真源码**。

## 决策树（按顺序走，不许跳）

### Step 0 · 先建标准工程骨架

```bash
node scripts/init-clone.mjs <站名> --url <原站URL> --in-place
```

该脚本会在当前项目内创建 `NOTES.md`、`RECON/screenshots/`，避免每次手工漏掉产物。

### Step 1 · 先去 GitHub 搜源码，别急着抓站

```bash
unset SSL_CERT_FILE   # macOS 怪癖，bash 前先解
# 按站名/产品名搜
SSL_CERT_FILE=/etc/ssl/cert.pem gh api "search/repositories?q=<关键词>" \
  | jq -r '.items[] | "\(.full_name) ⭐\(.stargazers_count) \(.description)"' | head -10
# vercel.app/netlify.app/github.io 的 URL slug 常常就是 仓库名 / 部署者用户名
```
- 单文件站（github.io / 纯 HTML）→ 直接抓 raw：`curl -sL https://raw.githubusercontent.com/<user>/<repo>/main/index.html`
- **找到源码且许可允许 → 跳 Step 4 直接 clone。** 教训：先搜 GitHub 能省 30 分钟弯路。

### Step 2 · 没找到源码 → 浏览器侦察（探针）

使用内置的零依赖 CDP 浏览器控制层跑探针抽信号（框架 / `window.THREE` / canvas 数 / 平滑滚动库 / 字体 / scrollHeight）。截图 1440/768/390 三档 + 侦察 JSON 存 `RECON/`。

优先用内置脚本跑标准侦察：

```bash
node scripts/recon-site.mjs \
  --url <原站URL> \
  --out RECON \
  --label original

# 真浏览器全程滚动，把页面真实用到的图片/字体/媒体（含第三方 CDN、防盗链资产）
# 全部拔到本地，并生成 assets/fonts/fonts.css（自托管 @font-face）+ URL→本地路径映射。
node scripts/asset-harvest.mjs \
  --url <原站URL> \
  --recon RECON/original-recon.json \
  --out assets \
  --manifest RECON/asset-manifest.json

node scripts/network-capture.mjs \
  --url <原站URL> \
  --out RECON/network \
  --label original

node scripts/route-crawl.mjs \
  --url <原站URL> \
  --out RECON/routes \
  --label original \
  --max-pages 25 \
  --max-depth 2

node scripts/interaction-probe.mjs \
  --url <原站URL> \
  --out RECON/interactions \
  --label original

node scripts/sourcemap-hunt.mjs \
  --recon RECON/original-recon.json \
  --out RECON/sourcemaps
```

`--wait` 仅表示页面导航完成后的额外稳定等待，不是导航超时。导航超时只可用 `--navigation-timeout <毫秒>` 调整；同一错误不要通过增大 `--wait` 盲目重试。

> 登录态私域站需要使用当前环境里已登录的浏览器上下文；localhost / 无登录公开站直接用内置 CDP 探针。

### Step 2.5 · 先给复杂度定级，别盲目承诺

根据侦察结果先写一版"复刻前预判"：复杂度 L1-L6、推荐模式（忠实复刻 / 视觉复刻 / 内容爆改）、预计可还原范围、明确不克隆的部分。分级和评分规则见 `references/assessment.md`。

**模式选择纪律（用户没回答确认项时的默认）**：用户说的是"复刻/克隆这个网站"，默认就是**忠实复刻**——还原度是这个场景的第一目标。不许因为"原站是商业站/有版权内容"就自作主张降级成视觉复刻、换占位品牌、用排版块替代摄影图：那会被用户直接感知为"图片没抓下来、字体不对、颜色不还原"。正确姿势是**先忠实复刻到位**（真图真字体真色值全部落地），把版权/商标风险写进 NOTES.md 的"部署前须替换清单"，替换动作留给 Step 6 由用户决定。只有用户明确要"做我自己的站/换成我的品牌"时才走视觉复刻/内容爆改。同理，**不许因为"目标站是风控敏感的 SPA"就跳过脚本侦察**——`recon-site.mjs`/`asset-harvest.mjs` 用的就是真浏览器，先跑再说，跑不通再降级并如实记录。

**若模式是「视觉复刻」或「内容爆改」** → 顺手产出结构化设计身份 `design-dna.json`，把"那个站的感觉"变成可版本化、可对照的 token 规范，让 Step 6 替换时"DNA 留着、内容换掉"有据可依：

```bash
node scripts/dna-scaffold.mjs \
  --recon RECON/original-recon.json \
  --out   RECON/design-dna.json \
  --name  "<站名>"
```

脚本会把侦察到的字体/色候选/框架特效信号 best-effort 预填，其余字段人工 Analyze 补全。三维结构（design_system / design_style / visual_effects）、完整 schema、适用边界见 `references/design-dna.md`。
> ⚠️ **「忠实复刻」分支不要用 DNA**：真源码就是真相，别让"近似风格"的 DNA 稀释逐字节铁律。

### Step 3 · 按侦察结果选路径

| 侦察结果 | 走哪条路 |
|---|---|
| 静态 HTML/CSS，无框架 | `wget --mirror` 抓镜像 → 删追踪脚本 → 改文案 |
| React / Vue / Next（内容为主） | 重建模板（如 `ai-website-cloner-template`，Node 24+），灌内容 |
| SPA / SaaS / 数据驱动页面 | 先跑 `network-capture.mjs` 保存 API fixtures → 本地 JSON/mock server 替身 |
| 多页面官网 / 产品站 | 先跑 `route-crawl.mjs` 做路由地图 → 每类页面抽模板 → 统一替换内容 |
| 复杂交互站 | 先跑 `interaction-probe.mjs` 记录 hover/click/scroll/canvas drag 状态 → 按状态补交互，不许只截首屏 |
| **WebGL / Canvas / Three.js 重前端** | **深度逆向真源码（见下）→ 忠实复刻 或 找同类开源 3D 模板换内容**。单文件原生站常常逐字节保留=最忠实复刻。**找不到真源码时走运行时帧捕获 + baseline 闸门**，纪律见 `references/effect-extraction.md`（可委托 web-shader-extractor） |
| **静态构建站（Astro/Vite SSG/Hugo），含重 WebGL** | **`mirror-site.mjs` 全量镜像部署资产 → 自托管字体 + 删追踪 → 本地 web 根服务 = 真源码 1:1 忠实复刻**。对静态站，"拿到真源码"="镜像部署资产整套"。配方见 `references/static-mirror.md`。范例：oryzo.ai（Lusion，L6，高斯泼溅，hero 像素 diff 5/5） |
| 用现成开源主题的站（Astro/Hugo 主题） | 去对应主题市场找源主题（**仅限套用现成主题的站**；定制站走上一行的全量镜像，别来这行） |

L4-L6 复杂站按 `references/complex-playbooks.md` 走，不要只用普通官网流程。

### Step 4 · 在当前项目里搭工程

```bash
# 当前 OpenDesign 项目目录就是复刻工作区。
pwd
# git 源码：clone 到 source/ 或直接放入当前目录；单文件：放进来。原始源码留一份只读基准 index-original.html
# 检查 Node 版本（package.json engines），nvm use 对应版本，钉 .nvmrc
```

### Step 5 · 删追踪 + 写元信息 + 验证

- **删追踪**：Google Analytics（`gtag` / `googletagmanager`）、像素、热图——逐行精确切除（GA 块常在 `<head>` 顶部）。
- **OpenDesign 预览适配**：交付前必须把项目根资源引用改成相对路径，避免 `/reference-assets/...` 在文件预览里打到 OpenDesign 应用根导致裸 HTML：

```bash
node scripts/od-preview-rewrite.mjs --project .
```

- **写 NOTES.md**（必须）：包含复杂度、复刻模式、原站 vs 克隆站对比、保真度评分、已知缺口。模板见 `references/deliverables.md`。
- **复杂站写 TEARDOWN.md**（技术拆解）。所有结论标真源码行号。
- **复刻后评分**：按 `references/assessment.md` 给结构 / 视觉 / 交互 / 响应式 / 内容替换 / 功能完整度打分。分数要能被截图、源码、运行结果支撑。
- **浏览器真验证**（硬要求，不许只看代码就说"应该能跑"）：起本地服务器 → 浏览器打开 → 抓 console（不能有 JS/WebGL 编译错误）→ 截图对照原站。诚实记录验证不了的部分（如合成 PointerEvent `isTrusted=false` 触发不了拖拽，要如实写，别伪造"拖动成功"）。

复刻完成后再跑一次克隆站侦察，并生成自动对比报告：

```bash
node scripts/recon-site.mjs \
  --url http://127.0.0.1:<端口>/ \
  --out RECON \
  --label clone

node scripts/route-crawl.mjs \
  --url http://127.0.0.1:<端口>/ \
  --out RECON/routes-clone \
  --label clone \
  --max-pages 25 \
  --max-depth 2

node scripts/interaction-probe.mjs \
  --url http://127.0.0.1:<端口>/ \
  --out RECON/interactions-clone \
  --label clone

node scripts/compare-recon.mjs \
  --original RECON/original-recon.json \
  --clone RECON/clone-recon.json \
  --visual-diff RECON/visual-diff-1440.json \
  --original-routes RECON/routes/original-route-map.json \
  --clone-routes RECON/routes-clone/clone-route-map.json \
  --original-interactions RECON/interactions/original-interactions.json \
  --clone-interactions RECON/interactions-clone/clone-interactions.json \
  --out CLONE_REPORT.md

node scripts/visual-diff.mjs \
  --original RECON/screenshots/original-1440.png \
  --clone RECON/screenshots/clone-1440.png \
  --out RECON/visual-diff-1440.json \
  --diff RECON/screenshots/visual-diff-1440.png

# --recon + --strict: 字体/图片/颜色保真硬门槛，有硬伤 exit 2 —— 修完重跑，
# 不通过不许交付。
node scripts/audit-clone.mjs \
  --project . \
  --brand "<原站品牌名>" \
  --recon RECON/original-recon.json \
  --strict \
  --out CLONE_AUDIT.md
```

## 资产与颜色保真（硬性门槛，违反=复刻失败）

复刻最常见的翻车方式不是结构错，而是**字体不对、图片没下、颜色目测**。以下三条是铁律，`audit-clone.mjs --recon --strict` 会机器校验：

1. **字体必须自托管真字体，禁止系统字体近似。**
   原站的字体文件几乎都在第三方 CDN（Typekit / Google Fonts / 品牌自有 CDN），带防盗链——所以必须用 `asset-harvest.mjs --url`（真浏览器网络栈）抓，不能裸 curl。产物 `assets/fonts/fonts.css` 已把 @font-face 改写成本地路径，页面直接 `<link rel="stylesheet" href="assets/fonts/fonts.css">`，然后 `font-family` 逐字照抄 recon JSON 里 `palette.*.fontFamily` / `fontFaces[].family` 的值。写 `-apple-system` / `"Helvetica Neue"` 兜底链顶替原站自定义字体 = 直接不合格。
2. **图片必须落地本地真图，禁止渐变/SVG 占位顶替。**
   `asset-harvest.mjs --url` 会滚动全页把懒加载图、srcset 变体、CSS 背景图全部按 `asset-manifest.json`（originalUrl → localPath）落到 `assets/images/`。构建页面时照 manifest 机械替换引用；某张图下载失败就换 `--recon` 兜底源或从 `RECON/network` 捕获里捞，实在拿不到才允许占位并在 NOTES.md 写明。
3. **颜色必须照抄 recon 的计算值，禁止目测。**
   `RECON/original-recon.json` 的 `palette`（body/header/nav/main/footer/buttons 的 computed backgroundColor/color/borderColor）和 `rootVariables` 就是标准答案；`original-summary.md` 里也有摘要。写 CSS 变量时直接复制这些值——footer 是 `rgb(17,17,17)` 就写 `#111111`，不许写"看起来差不多"的 `#0a0a0a`。
4. **滚动体感必须一致，禁止默认原生滚动了事。**
   recon 的 `frameworks`（lenis / gsap 检测）+ `motion`（`htmlScrollBehavior` / `scroll-snap` 规则数 / sticky·fixed 元素数）就是原站的滚动配方：原站用惯性平滑滚动库就上同款（Lenis 等）或等效实现；有 `scroll-snap` 就还原 snap；sticky 导航、视差、滚动触发动画逐个对齐。验收时用 `interaction-probe.mjs` 的滚动序列截图对照原站，滚动中途的状态（吸顶阴影、进场动画触发点）也要像。

### Step 6 · 替换成 用户自己的内容

目标永远是"做用户自己的站"，不是搬一个一模一样的。替换三件套：文字（`index.html`/`data/*.json`/`content/*.md`）、媒体（`public`/`assets`）、品牌色（CSS 变量 / Tailwind theme）。结构非平凡就写 REPLACE_GUIDE.md。

**做过 `design-dna.json`（视觉/爆改模式）的**：这一步就是它的兑现——**DNA 留着、内容换掉**。把 `design_system` 落成 CSS 自定义属性、按 `design_style` 做主观取舍、按 `visual_effects.effect_intensity` 选实现层级（lightweight CSS / medium Canvas+GSAP / heavy Three.js）；素材优先用 `asset-harvest.mjs` 取原站真图，别 AI 重绘近似。生成流程见 `references/design-dna.md`。

## 逆向拆解 WebGL/Canvas 重前端（核心手艺）

把交互站拆成**技术支柱**，逐柱定位真实实现 + 标行号：渲染（WebGL/着色器算法）、合成（SVG filter / 多 canvas / 后期）、物理、交互、音频。然后才去核对任何二手分析。

**逆向特效时三件套纪律**（治"边抠边美化、最后既不像也说不清"）：
1. **证据分级**：每条结论标 `SOURCE`（真源码/source-map/运行时 dump/帧捕获）、`PARTIAL`（名字/切片，待证）、`GUESS`（视觉拟合/魔数）。**未标=GUESS，照抄前必须升级到 SOURCE。**
2. **no-compensation**：严禁靠调亮度/速度/位置/噪声去掩盖时序/坐标/状态错误；拟合值仍标 GUESS，写明要拿到什么证据才能升级。
3. **baseline-first 闸门**：先用真实 draw call/shader/uniform 做"最小原样可复现 RAW REPLAY"→ 逐帧比对通过 → **才允许**重构工程化。
详见 `references/effect-extraction.md`（含运行时捕获兜底 + 何时委托 web-shader-extractor）。

**可迁移的高级范式**（值得攒着）：
- **位移图折射 DOM**：离屏 WebGL 算出 RG=位移/B=菲涅尔的"位移图"，再用 SVG `<filter><feDisplacementMap scale=N>` 拿它去扭曲真实的、活的、可交互的 HTML——折射的是真 DOM，WebGL 全程不碰 DOM 像素。这是 marbles 的灵魂，也是 Three.js `MeshPhysicalMaterial(transmission)` 做不到的事（它只能做"玻璃球外观"，做不出"折射整个网页"）。

详细方法 + marbles 真架构逐项拆解 → `references/reverse-engineering.md`、`references/marbles-case.md`。

## 许可与署名（clone 前必查）

```bash
SSL_CERT_FILE=/etc/ssl/cert.pem gh api repos/<u>/<r> | jq '.license'  # + 找 LICENSE 文件 + 看 README
```

| 许可 | 能做什么 |
|---|---|
| MIT / Apache / BSD / Unlicense | 可改、可上线，保留致谢即可 |
| **NONE（无 LICENSE 文件 / 未声明）** | **默认保留所有权利**。仅本地学习/复刻，须署名原作者，**未经许可不得公开重新部署**。别因为代码公开就当成可自由用 |
| 专有 / 明确禁止 | 只读学习，不复制不部署 |

⚠️ 别把"GitHub 上是公开的"或"gh api 一时查不到"等同于 MIT——核实到底。

## 产物规范
- 每个子项目根目录：`NOTES.md`（源信息/技术栈/license/替换地图/跑起来命令）
- 复杂交互站追加：`TEARDOWN.md`（技术拆解，标行号）
- 需要对外汇报或评估 skill 效果时追加：`CLONE_REPORT.md`（原站 vs 克隆站完整对比）
- 上线前追加：`CLONE_AUDIT.md`（追踪脚本、原站品牌/语言残留、TODO、外链风险）
- `RECON/screenshots/`：原站 vs 克隆对照图
- 如用户有外部复刻索引，再按需更新该索引；OpenDesign 项目内不强制维护全局中枢 README。

## 内置脚本
- `scripts/init-clone.mjs`：初始化克隆项目骨架和 `NOTES.md`。
- `scripts/recon-site.mjs`：用内置 CDP 控制层打开页面并全程滚动，采集框架/资源/DOM 结构/console 错误、关键区块计算色（`palette`）、@font-face 规则与真实加载的字体/图片资源清单，并保存三档截图。
- `scripts/asset-harvest.mjs`：真浏览器网络栈全程滚动捕获并下载页面真实用到的图片/字体/媒体（含第三方 CDN、防盗链资产），生成 `assets/fonts/fonts.css` 自托管 @font-face 与 originalUrl→localPath 素材清单。
- `scripts/network-capture.mjs`：捕获 XHR/fetch 请求并保存 JSON/text 响应，给 SPA/SaaS 做本地 fixtures。
- `scripts/mirror-site.mjs`：真浏览器全程滚动捕获每一个真实请求 → 按路径镜像同源资产（含 JS 运行时 fetch 的 `.sog/.buf/.wasm/.riv`/字体），给静态构建站（Astro/Vite SSG/Hugo）做 1:1 忠实复刻。详见 `references/static-mirror.md`。
- `scripts/route-crawl.mjs`：爬同站内部链接，按路由保存截图、标题、H1、结构信号，解决多页面站只复刻首页的问题。
- `scripts/interaction-probe.mjs`：自动执行 scroll、hover、安全 click、canvas drag，保存交互前后状态、截图、网络和 console 证据。
- `scripts/sourcemap-hunt.mjs`：从 JS chunk 里找 source map，能拿到就保存源码映射。
- `scripts/compare-recon.mjs`：读取原站与克隆站的侦察 JSON、路由图、交互证据，生成 `CLONE_REPORT.md`。
- `scripts/visual-diff.mjs`：用浏览器 canvas 做截图像素差异，输出 visual score 和差异图。
- `scripts/audit-clone.mjs`：扫描追踪脚本、原站品牌残留、日文残留、TODO、外部 URL 风险；带 `--recon --strict` 时额外校验字体自托管/图片落地/关键区块颜色逐字一致，有硬伤 exit 2。
- `scripts/od-preview-rewrite.mjs`：把 HTML/CSS/SVG 里的项目根资源引用（如 `/reference-assets/main.css`）改成相对路径，保证 OpenDesign 文件预览和导出 zip 在嵌套路由下仍能加载资源。
- `scripts/dna-scaffold.mjs`：从侦察 JSON 生成 `design-dna.json` 设计身份骨架（字体/色候选/框架特效信号 best-effort 预填），给「视觉复刻 / 内容爆改」模式用。详见 `references/design-dna.md`。

## 能力边界（默认口径）
- **能高保真做**：静态营销页、企业官网、内容型 React/Vue/Next 前端、可直接拿到源码的动画站。
- **能视觉还原但会简化**：CMS 后台数据、复杂滚动叙事、多端断点、WebGL/Canvas 特效、第三方嵌入。
- **默认不承诺完整克隆**：登录、支付、下单、搜索推荐、权限系统、服务端业务逻辑、专有 API、受版权限制的素材。需要时只做可演示前端替身。
- **内容爆改时**：优先保留原站的信息架构、节奏、动效和视觉语法，把文案、图片、品牌色、业务主张换成 用户自己的内容。

## 旗舰案例
`./marbles-clone/` — 原生 WebGL + SVG Filter + 自研物理的玻璃弹珠站，逐字节忠实复刻 + 完整 TEARDOWN，是"WebGL 重前端分支"的范例。


<!-- ===== FILE: LICENSE ===== -->
````LICENSE
MIT License

Copyright (c) 2026 Jane (@xiaoerzhan / 小耳)

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

````

<!-- ===== FILE: references/assessment.md ===== -->
````md
# 复杂度分级与复刻评分

用于复刻前预判、复刻后验收，以及向 Jane 解释"这个站能克隆到什么程度"。

## 复刻模式

| 模式 | 目标 | 适用场景 |
|---|---|---|
| 忠实复刻 | 尽量保留原源码 / 原布局 / 原交互 | 找到合法源码、单文件站、学习复杂前端技法 |
| 视觉复刻 | 外观看起来接近，内部实现可替换 | 无源码、商业官网、内容站、组件化重建 |
| 内容爆改 | 保留原站节奏和视觉语法，换成 Jane 的业务内容 | 把参考站改成自己的站、品牌页、产品介绍 |
| 技术拆解 | 不急着重建，先确认真实实现 | WebGL/Canvas/复杂交互、AI 分析互相矛盾 |

## 复杂度 L1-L6

| 等级 | 类型 | 典型信号 | 通常可还原度 | 默认边界 |
|---|---|---|---|---|
| L1 | 静态 HTML/CSS | 少量 JS、无框架、页面数少 | 90-98% | 可接近像素级，素材版权另算 |
| L2 | CMS/企业内容站 | 多页面、CMS 生成、表单/新闻/地区站 | 70-90% | 前台可还原，CMS 后台不克隆 |
| L3 | React/Vue/Next 内容前端 | hydration、chunk、路由、接口取内容 | 65-90% | 数据/API 可用本地 JSON 替身 |
| L4 | 动画重品牌站 | GSAP、Lenis、复杂滚动、视频蒙版 | 50-80% | 主视觉可还原，微交互常近似 |
| L5 | WebGL/Canvas/Three.js | shader、物理、后期合成、GPU 资源 | 30-95% | 有源码可高，没源码先拆解再定 |
| L6 | SaaS/电商/登录业务系统 | 账号、支付、订单、权限、搜索推荐 | 展示层可做 | 服务端业务逻辑默认不克隆 |

## 复刻前预判模板

```markdown
## 复刻前预判
- 复杂度等级:
- 推荐模式: 忠实复刻 / 视觉复刻 / 内容爆改 / 技术拆解
- 可高保真的部分:
- 需要近似或替代的部分:
- 不克隆的部分:
- 主要风险: 许可 / 素材 / 登录态 / API / 性能 / WebGL / 响应式
```

## 复刻后评分

每项 0-5 分。只给能被源码、截图、浏览器运行结果支撑的分数。

| 维度 | 5 分 | 3 分 | 1 分 |
|---|---|---|---|
| 源证据 | 找到源码或完整静态资源，关键结论有文件/行号 | 有运行时侦察和资源抓取 | 主要靠目测和推断 |
| 结构保真 | 信息架构、区块顺序、断点都一致 | 主区块一致，细节有合并/删减 | 只保留大概风格 |
| 视觉保真 | 字体、间距、颜色、图片比例高度接近 | 主视觉接近，局部比例不同 | 明显像另一个设计 |
| 动效/交互 | 滚动、悬停、视频、Canvas/WebGL 行为接近 | 只保留核心交互 | 基本静态化 |
| 响应式 | 桌面/平板/手机都验证且无错位 | 验证 1-2 个宽度 | 移动端明显破版 |
| 功能完整 | 导航、表单、媒体、外链、本地运行都可用 | 主要浏览路径可用 | 多处死链或报错 |
| 内容替换 | 已改成 Jane 的内容，替换地图清晰 | 部分改造，仍有原站残留 | 大量原站文案/品牌残留 |
| 法务/部署风险 | 许可清楚，追踪移除，素材边界明确 | 风险已记录但未完全解决 | 风险不清楚 |

建议输出：

```markdown
## 复刻评分
- 源证据: /5
- 结构保真: /5
- 视觉保真: /5
- 动效/交互: /5
- 响应式: /5
- 功能完整: /5
- 内容替换: /5
- 法务/部署风险: /5
- 总评:
```

## 原站 vs 克隆站对比表

```markdown
| 模块 | 原站表现 | 克隆实现 | 差异 / 取舍 | 证据 |
|---|---|---|---|---|
| 首屏 |  |  |  | screenshot / file:line |
| 导航 |  |  |  |  |
| 核心动效 |  |  |  |  |
| 内容区块 |  |  |  |  |
| 移动端 |  |  |  |  |
```

````

<!-- ===== FILE: references/complex-playbooks.md ===== -->
````md
# 复杂站复刻 Playbooks

用于 L4-L6 站点，目标是把"看起来复杂"拆成可执行路径。

## L4 动画品牌站

1. `recon-site.mjs` 抓三档截图、sections、视频/canvas 数量。
2. 记录滚动库信号：GSAP / Lenis / ScrollTrigger / Locomotive。
3. 把页面拆成首屏、滚动叙事、视频蒙版、hover、过渡五类。
4. 优先复刻节奏和视觉语法；微交互可近似，但必须在 `CLONE_REPORT.md` 标差异。
5. 用 `visual-diff.mjs` 对首屏和关键滚动位置截图评分。

## L5 WebGL / Canvas / Three.js

1. 先找真源码、source map、公开 repo；找不到再逆向 bundle。
2. `recon-site.mjs` 记录 canvas 尺寸、数量、框架信号。
3. `sourcemap-hunt.mjs` 尝试下载 source map。
4. 拆技术支柱：渲染、shader、后期、物理、交互、音频、资源加载。
5. 复杂 shader 不盲写；先做最小可运行场景，再逐项补材质、光照、后期。
6. 交互验证必须用浏览器实际操作或截图/视频证据，不能只看代码。

## L6 SaaS / 电商 / 登录业务系统

默认只克隆展示层和可演示流程，不承诺真实账号、支付、订单、权限。

1. 登录态公开页面先确认授权和隐私边界。
2. `network-capture.mjs` 保存 XHR/fetch 响应作为 fixtures。
3. 把接口分成：内容接口、搜索筛选、用户态、交易/写入。
4. 内容接口可用本地 JSON 替身；交易/写入接口只做 mock 成功/失败状态。
5. 保留空态、加载态、错误态、权限不足态，别只做 happy path。
6. `audit-clone.mjs` 扫外链、原品牌残留和追踪脚本。

## 多页面 / CMS / 企业站

1. 先抓 sitemap、导航、页脚、主要模板。
2. 只复刻代表性模板：主页、列表页、详情页、搜索/筛选页、联系页。
3. 重复内容用数据文件生成，不逐页手写。
4. CMS 后台不克隆；如需要编辑能力，用本地 JSON/Markdown 替代。

## 成功标准

- 原站证据完整：截图、recon JSON、网络清单、素材清单。
- 克隆站可本地运行，console/page error 清零或解释清楚。
- `CLONE_REPORT.md` 有结构、视觉、交互、响应式、功能边界评分。
- `CLONE_AUDIT.md` 没有追踪脚本、原品牌残留、未解释的日文/外链风险。
- 对做不到的真实后端、专有 API、版权素材明确写边界。

````

<!-- ===== FILE: references/deliverables.md ===== -->
````md
# 产物规范与模板

每个复刻子项目（`当前项目目录/`）的标准产物。

## NOTES.md（必须）

```markdown
# <站名> · 克隆笔记

## 源信息
- 原站 URL:
- 源码仓库:（如有）
- 原作者:
- 许可证: MIT / Apache / NONE / 专有  ← 必须核实，见 SKILL.md 许可表
- 致谢要求:

## 技术栈
- 框架 / 关键库 / Node 版本:

## 复刻前预判
- 复杂度等级: L1 / L2 / L3 / L4 / L5 / L6（见 web-clone skill 的 references/assessment.md）
- 推荐模式: 忠实复刻 / 视觉复刻 / 内容爆改 / 技术拆解
- 可高保真的部分:
- 需要近似或替代的部分:
- 不克隆的部分:
- 主要风险:

## 跑起来
\`\`\`bash
cd 当前项目目录
# 单文件静态站: python3 -m http.server 8123
# 框架站: nvm use <ver> && npm install && npm run dev
\`\`\`

## 改了什么（对照原版）
- 删了追踪脚本: ...（GA/gtag 行号）
- ...

## 原站 vs 克隆站
| 模块 | 原站表现 | 克隆实现 | 差异 / 取舍 | 证据 |
|---|---|---|---|---|
| 首屏 |  |  |  | screenshot / file:line |
| 导航 |  |  |  |  |
| 核心动效 |  |  |  |  |
| 内容区块 |  |  |  |  |
| 移动端 |  |  |  |  |

## 复刻评分
- 源证据: /5
- 结构保真: /5
- 视觉保真: /5
- 动效/交互: /5
- 响应式: /5
- 功能完整: /5
- 内容替换: /5
- 法务/部署风险: /5
- 总评:

## 替换地图（要换什么改哪）
- 文字 → 文件 行
- 图片/媒体 → 目录
- 配色 → CSS 变量 / theme
- 3D 模型 / 字体 → ...

## 验证
- [ ] 本地跑通、console 0 error
- [ ] 截图对照原站（RECON/screenshots/）
- [ ] `route-crawl.mjs` 输出原站/克隆站路由地图（多页面站必做）
- [ ] `interaction-probe.mjs` 输出 hover/click/scroll/canvas 状态证据（交互站必做）
- [ ] `visual-diff.mjs` 输出截图差异报告（能做时）
- [ ] `audit-clone.mjs` 输出残留审计报告
- 验证不了的点（如实记，别伪造）: ...
```

## TEARDOWN.md（复杂交互站追加）

技术拆解文档，**所有结论标真源码行号**。结构：
- **0. 一句话本质**
- **A. 真实技术拆解**（按支柱：渲染/合成/物理/交互/音频，每条标行号 **+ 证据级别 `SOURCE`/`PARTIAL`/`GUESS`**，见 `effect-extraction.md`）
- **B. 二手分析校验表**（若有 AI 分析文档：`声称 | 真源码 | 准确度✅/⚠️/❌ | 说明`，重点揪实质性错误）
- **C. 可迁移方法论**（通用套路 / 本站特有 / 复刻路径）

范例：`当前项目目录/marbles-clone/TEARDOWN.md`。

## RECON/（侦察产物）
- `screenshots/original-{1440,768,390}.png` 原站三档
- `screenshots/clone-1440.png` 克隆图（对照）
- `screenshots/visual-diff-1440.png` 截图差异图（能做时）
- `global-recon.json` 侦察探针输出（框架/canvas/滚动库/字体等）
- `routes/original-route-map.json` / `.md` 原站内部路由地图和逐路由截图
- `routes-clone/clone-route-map.json` / `.md` 克隆站内部路由地图和逐路由截图
- `interactions/original-interactions.json` / `.md` 原站交互状态、网络、console、截图证据
- `interactions-clone/clone-interactions.json` / `.md` 克隆站交互状态、网络、console、截图证据
- `asset-manifest.json` 原站素材清单和下载状态（能做时）
- `network/original-network.json` API/XHR 捕获清单（SPA/SaaS 必做）
- `network/fixtures/` 保存下来的 JSON/text 响应
- `sourcemaps/sourcemap-manifest.json` source map 搜索结果（复杂前端优先做）
- `visual-diff-1440.json` 像素差异指标
- `design-dna.json` 结构化设计身份（视觉复刻/内容爆改模式产出，由 `dna-scaffold.mjs` 起手，人工补全；schema 见 `design-dna.md`）
- `baseline/` WebGL/特效逆向时"最小原样可复现"产物 + 证据包（见 `effect-extraction.md` 的 baseline-first 闸门）

## CLONE_REPORT.md（需要对外汇报或评估 skill 效果时追加）

```markdown
# <站名> · 原站 vs 克隆站评估报告

## 结论
- 复杂度等级:
- 复刻模式:
- 总体还原度:
- 最适合怎么用: 本地学习 / 继续爆改 / 可部署展示 / 仅技术拆解

## 对比
| 维度 | 原站 | 克隆站 | 结论 |
|---|---|---|---|
| 信息架构 |  |  |  |
| 视觉语言 |  |  |  |
| 动效交互 |  |  |  |
| 响应式 |  |  |  |
| 内容替换 |  |  |  |
| 功能边界 |  |  |  |

## 评分
按 web-clone skill 的 `references/assessment.md` 8 项维度打分。

## 已知缺口
-

## 下一步升级建议
-
```

## CLONE_AUDIT.md（上线前追加）

由 `scripts/audit-clone.mjs` 生成。重点看：
- 追踪脚本 / 统计像素是否已删
- 原站品牌名、日文、TODO 是否残留
- 外部 URL 是否仍指向原站或第三方不可控资源
- 素材和 license 风险是否已记录

## 收尾
- 更新中枢 `当前项目目录/README.md` 索引行（状态 emoji：🟡侦察/🟢跑通/🔵改造/✅上线/🔴卡住/🗂️归档）
- 原始源码留只读基准 `index-original.html`，不要在它上面改
- 跑完关掉本地服务器进程

````

<!-- ===== FILE: references/design-dna.md ===== -->
````md
# Design DNA · 结构化设计身份层（视觉复刻 / 内容爆改专用）

把"做成那个站的感觉"从模糊感觉变成**可版本化、可复用、可对照的 JSON 规范**。
用在「视觉复刻」和「内容爆改」两个模式——侦察之后、搭工程之前，多产出一个 `design-dna.json`，
让 Step 6「替换成 用户自己的内容」有据可依：**DNA 留着、内容换掉**。

> 方法与 schema 改编自 [zanwei/design-dna](https://github.com/zanwei/design-dna)（MIT），按 web-clone 的口径裁剪。

## ⚠️ 适用边界（必须先读）

Design DNA 的生成哲学是**"近似风格"**——它产出的是"风格一致的新站"，不是逐字节复制。
这和 web-clone 的头号铁律「真源码至上 / 逐字节忠实」是**相反方向**。所以：

| 模式 | 用不用 DNA |
|---|---|
| 忠实复刻（拿到真源码 / 单文件原生站 / WebGL 逐字节还原） | **不用**。真源码就是真相，别让 DNA 把它稀释成"近似" |
| 视觉复刻（还原观感但简化实现） | **用**。DNA 是这条路的主产物 |
| 内容爆改（保留信息架构+节奏+视觉语法，换成 Jane 的内容） | **用**。DNA 定义"要保留什么"，内容随便换 |

一句话：**DNA 是给"做我自己的站"用的，不是给"搬一模一样"用的。**

## 三维结构

DNA JSON 分三层，对应"可量化 / 可感知 / 特殊渲染"：

1. **`design_system`** — 可测量的 token：color / typography / spacing / layout / shape / elevation / iconography / motion / components
2. **`design_style`** — 主观感知：aesthetic（mood/genre/era）/ visual_language / composition / imagery / interaction_feel / brand_voice_in_ui
3. **`visual_effects`** — 超出普通 CSS 的渲染：background / particles / 3d / shader / scroll / text / cursor / image / glass-neu / canvas / svg

`design_system` 直接落成 CSS 变量；`design_style` 指导主观取舍；`visual_effects` 决定要不要上 Canvas/WebGL/GSAP，并和本 skill 的「WebGL 逆向分支」对接。

## 三步工作流

1. **Structure** — 先看 schema（下方 + `dna-scaffold.mjs` 生成的骨架），确认要填哪些维度，可裁掉不相关的。
2. **Analyze** — 从侦察产物里抽：
   - 颜色：`<label>-recon.json` 的 `cssVariables`（`--` 开头的色值）+ `sections[].style` 的 `backgroundColor` / `color`，按面积定 primary、按 CTA 定 accent。
   - 字体：`fonts` 数组 + `sections[].style.fontFamily`，分 heading / body / mono。
   - 间距/布局：截图 + `sections[].rect` 量节奏与最大宽度。
   - 特效：`frameworks.three/gsap/lenis` + `canvases` + `counts.canvas` → 填 `visual_effects.overview.primary_technology` 和各 enabled 标志。
   - 风格/感知：看三档截图（1440/768/390）人工判 mood、genre、composition、whitespace。
   - **每个字段都要填实，不要留空字符串**；填不出的标 `TODO` 并说明缺什么证据。
3. **Generate** — 解析 DNA → 生成 CSS 自定义属性 → 按 `design_style` 做主观决策 → 按 `effect_intensity` 选实现层级（lightweight=CSS/SVG/vanilla；medium=Canvas2D/GSAP/Lottie；heavy=Three.js/GLSL/Pixi）→ 输出页面 → 灌 用户自己的内容。**素材优先从原站取真图（用 `asset-harvest.mjs`），不要 AI 重绘近似。**

## 脚手架

```bash
node scripts/dna-scaffold.mjs \
  --recon RECON/original-recon.json \
  --out   RECON/design-dna.json
```

脚本会输出完整 DNA 骨架，并把侦察到的字体、CSS 色变量、框架/特效信号**best-effort 预填**，
其余字段留 `""`（待人工 Analyze 补全）。没有 `--recon` 也能跑，纯出空骨架。

## DNA JSON 完整字段（改编自 design-dna，MIT）

```json
{
  "meta": { "name": "", "description": "", "source_references": "", "created_at": "" },

  "design_system": {
    "color": {
      "palette_type": "monochromatic | complementary | analogous | triadic | split-complementary",
      "primary":   { "hex": "", "role": "" },
      "secondary": { "hex": "", "role": "" },
      "accent":    { "hex": "", "role": "" },
      "neutral":   { "scale": "", "usage": "" },
      "semantic":  { "success": "", "warning": "", "error": "", "info": "" },
      "surface":   { "background": "", "card": "", "elevated": "" },
      "contrast_strategy": "high contrast | subtle layers | dark-on-light dominant"
    },
    "typography": {
      "type_scale": {
        "display":    { "size": "", "weight": "", "line_height": "", "tracking": "" },
        "heading_1":  { "size": "", "weight": "", "line_height": "", "tracking": "" },
        "heading_2":  { "size": "", "weight": "", "line_height": "", "tracking": "" },
        "heading_3":  { "size": "", "weight": "", "line_height": "", "tracking": "" },
        "body":       { "size": "", "weight": "", "line_height": "", "tracking": "" },
        "body_small": { "size": "", "weight": "", "line_height": "", "tracking": "" },
        "caption":    { "size": "", "weight": "", "line_height": "", "tracking": "" },
        "overline":   { "size": "", "weight": "", "line_height": "", "tracking": "" }
      },
      "font_families": { "heading": "", "body": "", "mono": "" },
      "font_style_notes": ""
    },
    "spacing": { "base_unit": "", "scale": "", "content_density": "compact | comfortable | spacious", "section_rhythm": "" },
    "layout":  { "grid_system": "", "max_content_width": "", "columns": "", "gutter": "", "breakpoints": "", "alignment_tendency": "strict grid | centered | asymmetric | mixed" },
    "shape":   { "border_radius": { "small": "", "medium": "", "large": "", "pill": "" }, "border_usage": "none | subtle 1px | bold borders | only on inputs", "divider_style": "" },
    "elevation": { "shadow_style": "none | soft diffused | hard drop | layered", "levels": { "low": "", "medium": "", "high": "" }, "depth_cues": "shadows | overlapping layers | blur/glass | color intensity" },
    "iconography": { "style": "", "stroke_weight": "", "size_scale": "", "preferred_set": "" },
    "motion": { "easing": "", "duration_scale": { "micro": "", "normal": "", "macro": "" }, "entrance_pattern": "", "exit_pattern": "", "philosophy": "minimal functional | playful bouncy | cinematic | none" },
    "components": { "button_style": "", "input_style": "", "card_style": "", "navigation_pattern": "", "modal_style": "", "list_style": "", "component_notes": "" }
  },

  "design_style": {
    "aesthetic": { "mood": [], "visual_metaphor": "", "era_influence": "", "genre": "", "personality_traits": [], "adjectives": [] },
    "visual_language": { "complexity": "minimal | moderate | rich | maximal", "ornamentation": "none | subtle accents | decorative | heavily ornamented", "whitespace_usage": "", "visual_weight_distribution": "", "focal_strategy": "single hero element | distributed interest | progressive reveal", "contrast_level": "", "texture_usage": "" },
    "composition": { "hierarchy_method": "scale contrast | color weight | spatial isolation | typographic hierarchy", "balance_type": "symmetric | asymmetric | radial | mosaic", "flow_direction": "", "grouping_strategy": "", "negative_space_role": "" },
    "imagery": { "photo_treatment": "", "illustration_style": "", "graphic_elements": "", "pattern_usage": "", "image_shape": "" },
    "interaction_feel": { "feedback_style": "", "hover_behavior": "", "transition_personality": "snappy | smooth glide | bouncy elastic | fade-subtle", "loading_style": "", "microinteraction_density": "" },
    "brand_voice_in_ui": { "tone": "", "formality": "", "cta_style": "direct imperative | friendly invitation | urgent scarcity | subtle suggestion", "empty_state_approach": "", "error_tone": "" }
  },

  "visual_effects": {
    "overview": { "effect_intensity": "none | subtle-accent | moderate | heavy-immersive", "performance_tier": "lightweight | medium | heavy", "fallback_strategy": "", "primary_technology": "CSS only | Canvas 2D | WebGL/Three.js | GSAP | Lottie | SVG SMIL | Pixi.js" },
    "background_effects": { "type": "gradient-animation | noise-field | mesh-gradient | video-bg | generative-art | none", "description": "", "technology": "", "params": { "color_palette": "", "speed": "", "density": "", "opacity": "", "blend_mode": "" } },
    "particle_systems": { "enabled": false, "type": "floating-dots | confetti | snow | fireflies | connected-nodes | custom", "description": "", "technology": "", "params": { "count": "", "shape": "", "size_range": "", "movement_pattern": "", "color_behavior": "", "interaction": "mouse-repel | mouse-attract | click-burst | none", "spawn_area": "" } },
    "3d_elements": { "enabled": false, "type": "hero-model | product-viewer | scene-bg | text-extrusion | abstract-geometry", "description": "", "technology": "", "params": { "renderer": "", "lighting": "", "camera": "", "materials": "", "geometry": "", "post_processing": [], "interaction_model": "" } },
    "shader_effects": { "enabled": false, "type": "noise-distortion | wave | morph | color-shift | custom-GLSL", "description": "", "technology": "", "params": { "uniforms": "", "vertex_manipulation": "", "fragment_output": "", "noise_type": "perlin | simplex | worley | fbm", "distortion": "" } },
    "scroll_effects": { "parallax": { "enabled": false, "layers": "", "depth_range": "", "speed_curve": "" }, "scroll_triggered_animations": { "enabled": false, "trigger_points": "", "animation_type": "fade-up | scale-in | clip-reveal | counter | draw-SVG", "scrub_behavior": "" }, "scroll_morphing": { "enabled": false, "description": "" } },
    "text_effects": { "type": "split-letter-animate | typewriter | glitch | gradient-fill | 3d-extrude | none", "description": "", "technology": "", "params": { "split_strategy": "by-char | by-word | by-line", "animation_per_unit": "", "stagger": "", "effect_style": "" } },
    "cursor_effects": { "enabled": false, "type": "custom-cursor | magnetic-buttons | spotlight | trail | none", "description": "", "params": { "shape": "", "size": "", "blend_mode": "", "trail": "", "interaction_zone": "" } },
    "image_effects": { "type": "hover-distortion | reveal-clip | parallax-tilt | rgb-shift | none", "description": "", "technology": "", "params": { "filter_pipeline": "", "hover_transform": "", "reveal_animation": "", "distortion_type": "barrel | wave | liquid | glitch" } },
    "glassmorphism_neumorphism": { "enabled": false, "style": "glass | neumorphic-light | neumorphic-dark | frosted-layers | none", "params": { "blur_radius": "", "transparency": "", "border_treatment": "", "shadow_type": "", "light_source_angle": "" } },
    "canvas_drawings": { "enabled": false, "type": "generative-lines | interactive-blobs | data-visualization | pattern-fill | none", "description": "", "technology": "", "params": { "draw_method": "", "animation_loop": "", "color_scheme": "", "responsiveness": "", "interaction": "" } },
    "svg_animations": { "enabled": false, "type": "path-draw | morph-shapes | logo-reveal | decorative-loop | none", "description": "", "params": { "animation_method": "", "path_morphing": "", "stroke_animation": "", "filter_effects": "" } },
    "composite_notes": ""
  }
}
```

## 和 WebGL 逆向分支的分工

- `visual_effects` 里标了 `heavy-immersive` / `WebGL/Three.js` / `shader_effects.enabled=true` 的站，**别用 DNA 去"近似"那个特效**——那是 `effect-extraction.md` + `reverse-engineering.md` 的活，要逆向真实现。
- DNA 在这种站里只负责"特效**之外**"的设计层（配色/排版/布局/普通动效），特效本身走逆向或委托 web-shader-extractor。

````

<!-- ===== FILE: references/effect-extraction.md ===== -->
````md
# 特效提取的证据纪律 + Baseline 闸门（WebGL/Canvas 逆向分支强化）

`reverse-engineering.md` 讲"怎么读懂渲染架构"；本篇讲**逆向特效时怎么不骗自己**，
以及找不到真源码时的兜底路线。三件套：**证据分级 → no-compensation → baseline-first 闸门**。

> 纪律范式受 [lixiaolin94/skills · web-shader-extractor](https://github.com/lixiaolin94/skills) 启发（该仓库无 LICENSE，
> 默认保留所有权利——这里**只借方法概念、全部用本 skill 自己的话重写，未复制其代码或原文**）。
> 它和 web-clone 头号铁律「真源码至上」同魂，只是把"标行号"升级成了系统化的证据制度。

## 一、证据分级（每条结论都打标签）

写 TEARDOWN 时，渲染管线的每个关键事实都标一个级别，**默认按最低级算**：

| 标签 | 含义 | 例子 |
|---|---|---|
| `SOURCE` | 直接、绑定到目标的硬证据 | 公开真源码行、source-map 还原的模块、运行时对象 dump、抓到的 shader/WGSL 文本、帧捕获、带 hash 的网络响应体 |
| `PARTIAL` | 下一步探针的把手，还不够定论 | 类/函数/字段名、minified bundle 切片、框架对象、拿到 shader 但缺 uniform/pass/输入状态 |
| `GUESS` | 没有直接证据的重建值 | 视觉拟合、命名推断、套用默认值、手调魔数、任何"看起来对"的行为复原 |

- **未标 = 当 GUESS。** 别让没证据的东西混进"已知"。
- 这是把 marbles 教训（"AI 把解析求交臆造成 ray-marching"）制度化：**凡是 GUESS 级的实现，照抄前必须先升级到 SOURCE。**

## 二、no-compensation（不靠调参掩盖不懂）

> **严禁**为了让画面"看起来对"，去改亮度 / 速度 / 位置 / 噪声值，来掩盖时序、颜色、FBO、资源、坐标系或状态模型上的真错误。

- 拟合出来的某个常数让输出更像了 → **它仍是 GUESS**，并写明"要拿到什么证据才能升级"。
- 接线类事实（pass 顺序、坐标变换、时间单位、输入耦合）**不会因为画面像了就算对**，必须独立追到证据为止。
- 对应 web-clone 老规矩：验证不了的如实写，**别伪造"拖动成功"**。

## 三、baseline-first 闸门（先复现，再重构）

逆向特效时**最容易犯的错**是边抠边重写边美化，最后既不像原站也说不清哪步错了。改成分闸：

```
定位渲染面 → 捕获最小真相 → RAW REPLAY（原样最小复现）→ ✅BASELINE 逐帧比对通过
                                                              ↓ 通过后才允许
                                                        PROJECTIZE（重构成可编辑工程）→ PACKAGE
```

- **RAW REPLAY**：用抓到的真实 draw call / shader / uniform / 顶点数据，做一个**尽量小、尽量原样**的可运行复现，不优化、不换框架、不改参数。
- **BASELINE 闸门**：RAW REPLAY 必须和原站逐帧（或多帧采样）视觉一致，才算过。**没过这道闸，不准进重构。**
- 过闸后再 PROJECTIZE：换成可维护写法（raw WebGL / Three.js TSL / Babylon 等），每处仍标证据级别。
- 收尾三态，如实标注：`DONE_BASELINE_VERIFIED`（复现且验证）/ `DONE_PROJECTIZED`（已工程化）/ `DONE_BASELINE_WITH_GAPS`（复现但有记录在案的缺口）。

## 四、找不到真源码时——运行时捕获兜底

web-clone 第一动作永远是"去 GitHub / source-map 找真源码"。但**特效站经常无源、minified 到底**。
这时不要退回"看着像就照着写"（那是 GUESS），而是去**渲染边界抓运行时真相**：

- 在 WebGL/WebGPU 上下文拦截：实际的 draw call、绑定的 program、编译过的 shader 源、uniform 值、FBO/纹理尺寸、blend/depth 状态。
- 工具方向：spector.js 式的帧捕获、`WebGLRenderingContext` 原型打补丁记录调用、`getShaderSource` 拿编译后的 shader、preload script 在页面脚本前注入钩子。
- 抓到的这些算 `SOURCE` 级——它们就是新的"真源码"，喂给 baseline-first 流程。

## 五、什么时候委托 web-shader-extractor

如果你已经装了 `web-shader-extractor`（`npx skills add lixiaolin94/skills` 里的那个 skill），
**遇到下面情况直接把特效那一段委托给它，web-clone 只当总入口**：

- 站是 WebGL/WebGPU/重 Canvas 特效，且 GitHub + source-map 都找不到真源码；
- 需要运行时帧捕获、逐帧比对、shader/uniform 级别的抠取；
- 想要"先 baseline 复现、再独立工程化"的完整带闸流程。

委托产物（最小可复现的 baseline + 证据包）拿回来后，**再并入 `当前项目目录/`**，
按 web-clone 的产物规范补 NOTES/TEARDOWN，并继续走 Step 5 验证 + Step 6 替换。

没装它也不影响：上面四节的纪律本身就能照着做，web-shader-extractor 只是把第四节的捕获机器做成了现成工具。

## 与既有产物的衔接

- TEARDOWN.md 的"A. 真实技术拆解"每条加证据标签（`SOURCE`/`PARTIAL`/`GUESS`）。
- "B. 二手分析校验表"本来就是在抓 GUESS 冒充 SOURCE，口径一致。
- baseline 复现物建议留在 `<站名>-clone/RECON/baseline/`，和原始截图一起作为"验证过"的铁证。

````

<!-- ===== FILE: references/marbles-case.md ===== -->
````md
# 旗舰案例 · Glass Marbles（真架构 vs AI 臆造）

源站 https://chiuhans111.github.io/marbles/ ·作者 Hans Chiu ·单文件 1067 行 ·许可证 **NONE**。
完整逐行拆解见 `当前项目目录/marbles-clone/TEARDOWN.md`，这里是给 skill 用的精华版。

## 一句话真架构

一个全屏 WebGL 片段着色器，用**解析法（二次方程 `b*b-c`）**求光线与球的交点、做最多 4 次折射/反射迭代，把光学结果编码成一张**位移图 PNG**（RG=像素位移、B=菲涅尔值）；再用一个 SVG `<filter>` 的 `feDisplacementMap(scale=200)` 拿这张图去扭曲**真实的、活的、可交互的网页 DOM**（背景色块 + 标题文字）。

> 你拖动的玻璃球本质是个透镜，透镜后面就是这页 HTML。WebGL 全程不碰 DOM 像素——折射这件事是 SVG filter 干的。物理、音频均为纯手写、零库。

## 三大支柱（真实实现要点）

1. **WebGL 光学**：解析球求交（非 ray-marching）；折射率 N=1.3、迭代 4 次；菲涅尔 `0.05+0.95*pow(1-cosθ,2.0)`（指数 2，非 Schlick 的 5）；内部 2 气泡 + 抛物面彩色核 + Beer-Lambert 体积吸收；**一套 shader 靠 `u_mode`(0折射/1反射/2前景高光/3阴影) 复用**；位移编码 `DISPLACEMENT_SCALE=200` 与 SVG 端严格对齐。
2. **SVG Filter 合成**：4 个 canvas（1 主 + 3 离屏），离屏图每帧 `toDataURL` 喂给 `<feImage>`。真实链：阴影 `feGaussianBlur(8)` → `feBlend multiply` 乘到 DOM → 折射 `feDisplacementMap` → 反射 `feDisplacementMap` → `feGaussianBlur(2)` → 用反射图 B 通道(菲涅尔)经 `feColorMatrix` 做 alpha mask → `feComposite` 两步合成。被折射的 `SourceGraphic` 就是挂了 `filter:url(#marble-filter)` 的 `#container`。
3. **物理**：纯手写，`mass=r³`、重力 0.8、3D 弹性碰撞(恢复 0.8、只在靠近时解算)、地面恢复 0.55 + 微弹跳归零、四元数滚动、拖拽抬升 targetZ=200；`settleFrames` 静止时完全停渲染。
4. **音频**：Web Audio 程序化合成(零文件)，基频 `800+(60-r)*20` + 5 泛音，音量随碰撞速度。

## ⚠️ AI 分析文档错在哪（反面教材，记住这些坑型）

那份 `弹珠网站复刻分析.md` 正文的**概念骨架基本对**（8 步、三支柱方向都对），但**附带的"复刻代码块"几乎全是臆造**：

| 臆造 | 真相 | 坑型（通用警示） |
|---|---|---|
| ray-marching + SDF + `MAX_STEPS=100` + 6 次差分求法线 | 解析求交，法线 `normalize(rp-center)` | **别凭直觉假设折射 demo 用 ray-marching**——球有闭式解，很多 demo 用解析法，又快又准 |
| `sampler2D uBackground` 把 DOM 当纹理采样 | 着色器不读背景；折射靠位移图交给 SVG | **搞反了 GPU↔DOM 的层级**——最核心的架构创意被丢 |
| `feBlend screen` + 单个 displacement + `feComposite over` 合阴影 | 双 displacement + 菲涅尔 mask + multiply 阴影 | **二手分析的 filter 链不可信，以真源码逐节点核对** |
| `MARBLE_COUNT=5`、数组开 10 | 硬编码 2 | 连常量都靠猜 |
| 屏幕中心 NDC 坐标 | 左上角像素 + Y 翻转 | 坐标系约定全凭臆测 |

**教训**：AI 写的"复刻施工图"= 参考其思路骨架，**代码块一行都别直接抄**，必须拿真源码核对。这就是本 skill 头号铁律的来源。

````

<!-- ===== FILE: references/reverse-engineering.md ===== -->
````md
# 逆向拆解 WebGL/Canvas 重前端站

当侦察判定一个站是 WebGL/Canvas/Three.js 重前端（`window.THREE` 存在、或有多个 `<canvas>`、或有 `<script type="x-shader/*">`），走这套。

> 本篇讲**怎么读懂渲染架构**；逆向时的**证据纪律**（SOURCE/PARTIAL/GUESS 分级、no-compensation、baseline-first 闸门）和**找不到源码时的运行时捕获兜底** → `effect-extraction.md`。两篇配合用。

## 通用拆解步骤

1. **先拿单文件源码**。很多 demo 站全自包含在一个 HTML 里（GitHub raw / 浏览器查看源代码），别急着上 Playwright 抓站。
2. **数 canvas、读 SVG defs、grep shader**：几个 `<canvas>`？有没有 `<filter>`？着色器脚本在哪？——这三样决定渲染架构。
3. **判断"WebGL 在算什么"**（关键，决定要不要相信二手分析）：
   - grep `texture2D` / `sampler2D` → 在采样纹理 / 帧缓冲
   - grep `for` 循环里 `+= dS` / `map(` / `MAX_STEPS` → ray-marching（步进式）
   - grep `b*b` / 判别式 / `sqrt(` + 二次方程 → **解析求交**（闭式解，球/平面常用）
   - ⚠️ 别凭直觉假设 ray-marching——折射玻璃 demo 经常是解析球求交。
4. **找 GPU↔DOM 的桥**：若 WebGL canvas 不直接显示，而是 `toDataURL` / 喂 `<feImage>` / `feDisplacementMap`，说明它在生成**数据图**（位移/法线/深度）给别的层用。这是高级前端的标志手法，也是最容易被二手分析搞反的层级。
5. **物理/音频单独读**：通常是与渲染解耦的纯 JS 模块，可单独验证。

## 值得攒着的可迁移高级范式

- **位移图折射 DOM**：离屏 WebGL 算出 RG=位移、B=辅助量的 PNG，SVG `<feDisplacementMap scale=N>` 拿它扭曲真实 HTML。GPU 端与 SVG 端的 `scale` 必须对齐。能做液态玻璃、放大镜、水波等任意"透镜罩在网页上"的效果，且**被折射的是活的可交互 DOM**——这是 Three.js `MeshPhysicalMaterial(transmission)` 做不到的（它只能做"玻璃球外观"，做不出"折射整个网页"）。
- **一套 shader + mode uniform 多用途**：折射/反射/阴影/前景共用同一份 fragment shader，靠 `u_mode` 分支。省代码省编译。
- **辅助数据降分辨率 + 静止跳帧**：位移/反射/阴影图肉眼对分辨率不敏感 → 降到 1/2、1/4。物体静止 → 完全停渲染（settleFrames）。重前端站标配性能套路。
- **全屏大三角替代 quad**：3 顶点 `[-1,-1, 3,-1, -1,3]` 覆盖全屏，省一条对角线。

## 复刻路径决策

- **能 1:1 还原 + 许可允许** → 直接拿真源码改文案/配色/参数（单文件原生站逐字节保留 = 最忠实）。
- **想要近似效果、不在意一致** → 找同类开源模板换内容（如 awesome-threejs）。但注意：**换实现路线常常丢掉原站的灵魂机制**（如本案的"折射真实 DOM"），先确认那个机制是不是用户要的卖点。
- **本站特有的数学（求交公式/魔数）迁移时要重写**：解析"圆球"求交换成别的形状就得换公式（或才真需要 SDF/ray-marching）；折射率、菲涅尔系数、吸收等手调魔数换材质要重调。

## 验证（硬要求）
起本地服务器 → 浏览器打开 → 抓 console（不能有 JS/WebGL 编译错误）→ 截图对照原站。
诚实记录验证不了的部分：例如 Playwright 合成 PointerEvent `isTrusted=false` 触发不了拖拽命中逻辑——**如实写进 NOTES，别伪造"拖动成功"**。物理类站可用"两次加载初始状态不同"间接证明引擎在跑。

````

<!-- ===== FILE: references/static-mirror.md ===== -->
````md
# 静态构建站的 1:1 忠实复刻：全量资产镜像

> 适用：**Astro / Vite SSG / Hugo / Eleventy / 任何把客户端运行时输出成可下载静态资产的站**——哪怕它是 WebGL/Canvas/高斯泼溅重前端。
> 不适用：真·服务端渲染 / 数据驱动 SPA（业务数据在 API 后面）→ 走 `network-capture.mjs` 做 API 替身，不是这条。

## 核心认知（为什么这能做到 1:1）
这类站的"**真源码不在 GitHub**"，但**部署出来的静态资产就是真相**：HTML + 打包 bundle + CSS + 运行时 fetch 的二进制（`.sog`/`.buf`/`.wasm`/`.riv`/字体/图/视频）。把这些**原样**镜像下来、从 web 根目录服务，跑的就是**真代码 + 真资产**，不是重建——所以能逐字节 1:1，连原站的 bug/怪癖都一并还原。

这是"真源码至上"铁律在静态站上的延伸：**对静态站，"拿到真源码" = "镜像部署资产整套"**。

> ⚠️ 决策树坑：别看到 `astro:true` 就甩去"主题市场找源主题"——那只对**用现成开源主题**的站成立。**定制 Astro 站（如 Lusion oryzo.ai）没有可买的主题**，正解是本条的全量镜像。

## 为什么必须"真浏览器全程滚动捕获"，不能只 grep / wget
- `.buf`/`.sog`/`.riv` 等二进制是 **JS 运行时按滚动进度 fetch** 的，URL 常是代码里**动态拼接**的 → grep bundle 抓不全，`wget --mirror` 也发现不了（它只跟 HTML 静态链接）。
- 唯一可靠：**真浏览器加载 + 从头滚到尾**，把每一个**真实发生的网络请求**记下来，再按这份"实际请求清单"镜像。

## 一键脚本
```bash
node scripts/mirror-site.mjs \
  --url https://<站>/ \
  --out 当前项目目录
```
产物：
- `<out>/site/…`：镜像的**同源**资产（保留路径；目录 URL 存 `index.html`）
- `<out>/own-asset-urls.txt`：同源资产清单
- `<out>/third-party.json`：第三方 host + **需自托管的 webfont CSS**（Typekit/Google）提示
- `<out>/mirror-manifest.json`：全部请求 + 状态

脚本用真浏览器全程滚动捕获 + 走浏览器网络栈下载（cookie/TUN/代理与页面一致）。

## 镜像后的手工收尾（让它离线 1:1 跑）
脚本只搬同源资产、不自动改写——**第三方按 `third-party.json` 人工处理**：

1. **自托管锁域名字体（最常见=Adobe Typekit）**
   Typekit kit 锁授权域名，远程 `@import` 换域名后可能不渲染 → 自托管：
   ```bash
   # ① 下 kit CSS（直连，typekit 常被代理挡 → 不要走 proxy）
   curl -sL -A "Mozilla/5.0 …Chrome…" -e "https://<站>/" "https://use.typekit.net/<kit>.css" -o site/typekit/kit.css
   # ② 从 kit.css 的 @font-face src 抠出 use.typekit.net/af/... 字体 URL，逐个下到 site/typekit/fonts/
   #    同一字体 3 个后缀: /l=woff2  /d=woff  /a=otf（以文件魔数 wOF2/wOFF/0x00010000 为准，别信文件名）
   # ③ 写本地 @font-face（相对 url + 保留 format 提示），见下
   ```
   本地 `@font-face`：
   ```css
   @font-face{ font-family:"<同名>"; src:url("./fonts/x.woff2") format("woff2"),
     url("./fonts/x.woff") format("woff"), url("./fonts/x.otf") format("opentype");
     font-display:swap; font-weight:<原范围>; }
   ```
   然后把引用处改成本地——**注意 Typekit 常是主 CSS 第一行 `@import"https://use.typekit.net/<kit>.css"`，不是 HTML `<link>`**：
   ```bash
   perl -0pi -e 's{\@import"https://use\.typekit\.net/<kit>\.css"}{\@import"/typekit/kit-local.css"}g' site/_astro/<主>.css
   ```

2. **删追踪**：cloudflare beacon / GA / 像素——精确切 `<script>`。

3. **公共 CDN（Rive wasm@unpkg / 第三方 player）**：公共 CDN 跨域可在线加载，本地服务+联网时正常 → 可留在线（离线则失效，NOTES 标注）。要彻底离线再镜像它们并改写注入点。

4. **Vimeo/YouTube 嵌入**：iframe 在线播，离线不可用 → 一般非核心首屏，NOTES 标注即可。

## 服务 + 验证
```bash
cd 当前项目目录/site
python3 -m http.server 8124      # 必须从 site/ 作 web 根，根相对路径(/_astro /models …)才解析
```
然后按 SKILL.md Step 5：浏览器 0 console error + `visual-diff.mjs` 像素对照原站。重 WebGL 站记得**滚动到各段截图**对照（静态全页截图抓不到滚动触发的 GL 帧）。

## worked example：oryzo.ai（Lusion，L6）
- 135 个同源资产（HTML+bundle+CSS + 25×`.buf` 几何/相机动画 + 2×`.sog` 高斯泼溅 + 排序 wasm + `.riv` + MSDF + 字体 + 80+ 图）
- 唯一改写：Typekit `@import`→本地自托管 halyard + 删 cloudflare beacon
- 结果：`scrollHeight` 精确一致、**0 console error**、hero 像素 diff **36/1.3M（5/5）**
- 留在线：Vimeo 画廊视频 + unpkg Rive wasm（非核心）
- 完整记录：`当前项目目录/oryzo-clone/`（NOTES.md + TEARDOWN.md）

````

<!-- ===== FILE: scripts/asset-harvest.mjs ===== -->
````mjs
#!/usr/bin/env node
// asset-harvest.mjs — 把目标页真实用到的图片/字体/媒体"想尽一切办法"全部拔到本地。
//
// 为什么用真浏览器而不是裸 fetch:
//   1. 大站的图片/字体几乎都在第三方 CDN(static.nike.com / use.typekit.net /
//      fonts.gstatic.com …)，带防盗链(referer/UA/cookie 校验)。裸 fetch + 机器人
//      UA 会被 403；复用浏览器网络栈(同一 UA/cookie/协议)则和真实用户无差别。
//   2. 懒加载图(loading=lazy / data-src / IntersectionObserver)只有真滚动才发请求。
//   3. CSS background-image、@font-face、srcset/picture 变体只在渲染时按需请求，
//      静态解析 HTML 抓不全；监听 network response 才是"页面真实用到的资产"全集。
//
// 用法(首选, --url 直接捕获):
//   node scripts/asset-harvest.mjs --url <URL> --out assets [--recon RECON/original-recon.json]
//     [--types image,font,media,stylesheet] [--max-bytes 26214400] [--download-timeout 10000]
//     [--navigation-timeout 30000] [--concurrency 8] [--scroll-step 700] [--settle 2500]
// 兼容旧用法(--recon-only, 无浏览器捕获, 仅按 recon JSON 里的 URL 裸下载):
//   node scripts/asset-harvest.mjs --recon original-recon.json --out assets/original --recon-only
//
// 产物:
//   <out>/images/<host>/<name>   全部图片(含第三方 CDN、srcset 变体、CSS 背景图)
//   <out>/fonts/<host>/<name>    全部字体二进制(woff2/woff/ttf/otf)
//   <out>/fonts/fonts.css        自托管 @font-face(从 webfont CSS + @font-face 规则改写为本地路径)
//   <out>/media/<host>/<name>    音视频(受 --max-bytes 限制)
//   <out>/asset-manifest.json    originalUrl → localPath 全映射 + 每项状态
//     构建复刻页时照 manifest 机械替换引用，禁止凭记忆写外链。

import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { loadPlaywright, launchChromium } from "./lib/playwright-loader.mjs";

function usage() {
  console.log(`asset-harvest.mjs — 抓取页面真实用到的图片/字体/媒体(含第三方 CDN)并生成本地映射

  node scripts/asset-harvest.mjs --url <URL> --out assets [--recon RECON/original-recon.json]
    [--types image,font,media,stylesheet] [--max-bytes 26214400] [--download-timeout 10000]
    [--navigation-timeout 30000] [--concurrency 8] [--scroll-step 700] [--settle 2500]

产物: <out>/{images,fonts,media}/<host>/<name> + <out>/fonts/fonts.css(自托管 @font-face)
      + <out>/asset-manifest.json(originalUrl → localPath, 构建时照此机械替换)`);
}

function parseArgs(argv) {
  const out = {
    url: "",
    recon: "",
    outDir: "assets",
    manifest: "",
    types: ["image", "font", "media", "stylesheet"],
    maxBytes: 25 * 1024 * 1024,
    downloadTimeout: 10_000,
    navigationTimeout: 30_000,
    concurrency: 8,
    scrollStep: 700,
    settle: 2500,
    reconOnly: false,
    allExternal: true,
  };
  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    if (arg === "--help" || arg === "-h") out.help = true;
    else if (arg === "--url") out.url = argv[++i] || "";
    else if (arg === "--recon") out.recon = argv[++i] || "";
    else if (arg === "--out") out.outDir = argv[++i] || "assets";
    else if (arg === "--manifest") out.manifest = argv[++i] || "";
    else if (arg === "--types") out.types = (argv[++i] || "").split(",").map((s) => s.trim()).filter(Boolean);
    else if (arg === "--max-bytes") out.maxBytes = Number(argv[++i] || out.maxBytes);
    else if (arg === "--download-timeout") out.downloadTimeout = Number(argv[++i] || "10000");
    else if (arg === "--navigation-timeout") out.navigationTimeout = Number(argv[++i] || "30000");
    else if (arg === "--concurrency") out.concurrency = Math.max(1, Number(argv[++i] || "8"));
    else if (arg === "--scroll-step") out.scrollStep = Number(argv[++i] || "700");
    else if (arg === "--settle") out.settle = Number(argv[++i] || "2500");
    else if (arg === "--recon-only") out.reconOnly = true;
    else if (arg === "--all-external") out.allExternal = true;
    else throw new Error(`Unexpected argument: ${arg}`);
  }
  return out;
}

const FONT_EXT = /\.(woff2?|ttf|otf|eot)(?:$|[?#])/i;
const IMAGE_EXT = /\.(png|jpe?g|gif|webp|avif|svg|ico|bmp)(?:$|[?#])/i;
const MEDIA_EXT = /\.(mp4|webm|m4v|mov|mp3|ogg|wav)(?:$|[?#])/i;
const WEBFONT_CSS = /use\.typekit\.net\/[a-z0-9]+\.css|fonts\.googleapis\.com\/css/i;

function classify(url, resourceType, contentType) {
  const ct = (contentType || "").toLowerCase();
  if (ct.startsWith("font/") || ct.includes("font-woff") || FONT_EXT.test(url)) return "font";
  if (ct.startsWith("image/") || resourceType === "image" || IMAGE_EXT.test(url)) return "image";
  if (ct.startsWith("video/") || ct.startsWith("audio/") || resourceType === "media" || MEDIA_EXT.test(url)) return "media";
  if (ct.includes("text/css") || resourceType === "stylesheet") return "stylesheet";
  return null;
}

function safeName(url) {
  const parsed = new URL(url);
  const ext = path.extname(parsed.pathname).slice(0, 12);
  const base = path.basename(parsed.pathname, ext).replace(/[^a-z0-9._-]+/gi, "-").slice(0, 80) || "asset";
  const hash = crypto.createHash("sha1").update(url).digest("hex").slice(0, 10);
  return `${base}-${hash}${ext || ".bin"}`;
}

function localPathFor(kind, url) {
  const host = new URL(url).hostname.replace(/[^a-z0-9.-]+/gi, "-");
  const dir = kind === "image" ? "images" : kind === "font" ? "fonts" : kind === "media" ? "media" : "css";
  return path.join(dir, host, safeName(url));
}

// recon JSON 里能静态看出来的 URL(img src/srcset、@font-face src、stylesheet)——
// 补充给 network 捕获兜底(比如首屏截图后才出现的资源)。
function urlsFromRecon(recon) {
  const urls = new Map(); // url -> hinted kind
  const add = (raw, kind, base) => {
    if (!raw) return;
    try {
      const abs = new URL(raw, base || recon.url).href;
      if (/^https?:/i.test(abs) && !urls.has(abs)) urls.set(abs, kind);
    } catch {}
  };
  for (const capture of recon.captures || []) {
    const signals = capture.signals || {};
    for (const image of signals.images || []) {
      add(image.src, "image");
      for (const candidate of String(image.srcset || "").split(",")) {
        add(candidate.trim().split(/\s+/)[0], "image");
      }
    }
    for (const face of signals.fontFaces || []) {
      for (const src of face.srcUrls || []) add(src, "font", face.sheetHref);
    }
    for (const href of signals.stylesheets || []) add(href, "stylesheet");
    for (const url of signals.resources?.images || []) add(url, "image");
    for (const url of signals.resources?.fonts || []) add(url, "font");
    for (const url of signals.resources?.media || []) add(url, "media");
  }
  return urls;
}

// 把 webfont CSS / @font-face 源 CSS 里的 url(...) 改写为本地字体路径，
// 汇总成一份可直接 <link> 的 fonts.css。
function rewriteFontCss(cssText, cssUrl, urlToLocal) {
  return cssText.replace(/url\(\s*(['"]?)([^'")]+)\1\s*\)/gi, (match, quote, ref) => {
    try {
      const abs = new URL(ref, cssUrl).href;
      const local = urlToLocal.get(abs);
      if (!local) return match;
      // fonts.css 落在 <out>/fonts/ 下，字体在 <out>/fonts/<host>/,
      // 所以相对引用去掉前导 "fonts/"。
      const rel = path.relative("fonts", local).split(path.sep).join("/");
      return `url(${quote}${rel}${quote})`;
    } catch {
      return match;
    }
  });
}

async function downloadAll(entries, ctx, args, refererUrl) {
  const results = new Array(entries.length);
  const outDir = path.resolve(args.outDir);
  let nextIndex = 0;
  let completed = 0;
  const downloadOne = async (entry) => {
    const rel = localPathFor(entry.kind, entry.url);
    const dest = path.join(outDir, rel);
    try {
      const fetchAsset = async () => {
        const resp = ctx
          ? await ctx.request.get(entry.url, {
              headers: { referer: refererUrl },
              maxRedirects: 5,
              timeout: args.downloadTimeout,
            })
          : await fetch(entry.url, {
              headers: { referer: refererUrl, accept: "*/*" },
              signal: AbortSignal.timeout(args.downloadTimeout),
            });
        const ok = ctx ? resp.ok() : resp.ok;
        const status = ctx ? resp.status() : resp.status;
        if (!ok) throw new Error(`HTTP ${status}`);
        return ctx ? resp.body() : Buffer.from(await resp.arrayBuffer());
      };
      let timeoutId;
      const buffer = await Promise.race([
        fetchAsset(),
        new Promise((_, reject) => {
          timeoutId = setTimeout(
            () => reject(new Error(`download timed out after ${args.downloadTimeout}ms`)),
            args.downloadTimeout,
          );
        }),
      ]).finally(() => clearTimeout(timeoutId));
      if (buffer.length > args.maxBytes) throw new Error(`exceeds --max-bytes (${buffer.length})`);
      fs.mkdirSync(path.dirname(dest), { recursive: true });
      fs.writeFileSync(dest, buffer);
      return { ...entry, status: "ok", bytes: buffer.length, localPath: rel.split(path.sep).join("/") };
    } catch (error) {
      return { ...entry, status: "error", error: error.message };
    }
  };
  const worker = async () => {
    while (nextIndex < entries.length) {
      const index = nextIndex++;
      results[index] = await downloadOne(entries[index]);
      completed += 1;
      if (completed % 10 === 0 || completed === entries.length) {
        console.log(`  下载进度 ${completed}/${entries.length}`);
      }
    }
  };
  await Promise.all(Array.from({ length: Math.min(args.concurrency, entries.length) }, worker));
  return results;
}

try {
  const args = parseArgs(process.argv.slice(2));
  if (args.help || (!args.url && !args.recon)) {
    usage();
    process.exit(args.help ? 0 : 1);
  }

  const recon = args.recon ? JSON.parse(fs.readFileSync(args.recon, "utf8")) : null;
  const pageUrl = args.url || recon?.url || "";
  if (!pageUrl) throw new Error("need --url or a recon JSON with a url");

  // 候选资产: network 捕获(权威) + recon 静态清单(兜底)。
  const candidates = new Map(); // url -> {kind, via}
  const addCandidate = (url, kind, via) => {
    if (!kind || !args.types.includes(kind)) return;
    if (!candidates.has(url)) candidates.set(url, { url, kind, via });
  };

  let ctx = null;
  let browser = null;
  if (!args.reconOnly) {
    const pw = loadPlaywright();
    browser = await launchChromium(pw.chromium);
    ctx = await browser.newContext({ viewport: { width: 1440, height: 900 }, deviceScaleFactor: 2 });
    const page = await ctx.newPage();
    page.on("response", (resp) => {
      try {
        const kind = classify(resp.url(), resp.request().resourceType(), resp.headers()["content-type"]);
        if (kind) addCandidate(resp.url(), kind, "network");
      } catch {}
    });
    console.log(`▸ 加载 + 全程滚动捕获资产请求: ${pageUrl}`);
    await page.goto(pageUrl, {
      waitUntil: "domcontentloaded",
      timeout: args.navigationTimeout,
    }).catch((e) => console.warn("  goto:", e.message));
    await page.waitForLoadState("networkidle", {
      timeout: Math.min(args.navigationTimeout, 5_000),
    }).catch(() => {});
    const total = await page.evaluate(() => document.documentElement.scrollHeight);
    for (let y = 0; y <= total; y += args.scrollStep) {
      await page.evaluate((yy) => window.scrollTo(0, yy), y);
      await page.waitForTimeout(180);
    }
    await page.waitForTimeout(args.settle);
    await page.evaluate(() => window.scrollTo(0, 0));
    await page.waitForTimeout(800);
  }

  if (recon) {
    for (const [url, kind] of urlsFromRecon(recon)) addCandidate(url, kind, "recon");
  }

  const entries = Array.from(candidates.values());
  const fontCount = entries.filter((e) => e.kind === "font").length;
  const imageCount = entries.filter((e) => e.kind === "image").length;
  console.log(`▸ 候选资产 ${entries.length} 个(图片 ${imageCount} / 字体 ${fontCount})，开始下载…`);

  const results = await downloadAll(entries, ctx, args, pageUrl);

  // 自托管 @font-face: 抓 webfont CSS(typekit/google fonts) + recon 里的 @font-face
  // 规则，把 url() 改写成本地字体路径，汇成一份 fonts.css。
  const urlToLocal = new Map(
    results.filter((r) => r.status === "ok").map((r) => [r.url, r.localPath]),
  );
  const fontCssBlocks = [];
  const webfontCssUrls = results.filter((r) => r.kind === "stylesheet" && WEBFONT_CSS.test(r.url));
  for (const cssAsset of webfontCssUrls) {
    try {
      const cssText = fs.readFileSync(path.join(path.resolve(args.outDir), cssAsset.localPath), "utf8");
      fontCssBlocks.push(`/* self-hosted from ${cssAsset.url} */\n${rewriteFontCss(cssText, cssAsset.url, urlToLocal)}`);
    } catch {}
  }
  for (const capture of recon?.captures || []) {
    for (const face of capture.signals?.fontFaces || []) {
      if (!face.cssText) continue;
      fontCssBlocks.push(rewriteFontCss(face.cssText, face.sheetHref || pageUrl, urlToLocal));
    }
  }
  if (fontCssBlocks.length) {
    const fontsDir = path.join(path.resolve(args.outDir), "fonts");
    fs.mkdirSync(fontsDir, { recursive: true });
    fs.writeFileSync(path.join(fontsDir, "fonts.css"), `${Array.from(new Set(fontCssBlocks)).join("\n\n")}\n`);
  }

  const manifestFile = path.resolve(args.manifest || path.join(args.outDir, "asset-manifest.json"));
  fs.mkdirSync(path.dirname(manifestFile), { recursive: true });
  const okCount = results.filter((r) => r.status === "ok").length;
  const errCount = results.length - okCount;
  fs.writeFileSync(manifestFile, `${JSON.stringify({
    url: pageUrl,
    capturedVia: args.reconOnly ? "recon-only" : "browser-network+recon",
    total: results.length,
    ok: okCount,
    error: errCount,
    fontsCss: fontCssBlocks.length ? "fonts/fonts.css" : null,
    assets: results,
  }, null, 2)}\n`);

  if (browser) await browser.close();
  console.log(`✅ 下载 ${okCount} 成功 / ${errCount} 失败 → ${path.resolve(args.outDir)}`);
  if (fontCssBlocks.length) console.log(`▸ 自托管字体样式: ${path.join(args.outDir, "fonts/fonts.css")} (页面 <link> 引入即可)`);
  const failedFonts = results.filter((r) => r.kind === "font" && r.status === "error");
  if (failedFonts.length) console.log(`⚠️ ${failedFonts.length} 个字体下载失败——不许用系统字体糊弄，逐个排查:\n   ${failedFonts.map((f) => `${f.error} ${f.url}`).slice(0, 10).join("\n   ")}`);
  console.log(manifestFile);
} catch (error) {
  console.error(`asset-harvest failed: ${error.message}`);
  process.exit(1);
}

````

<!-- ===== FILE: scripts/audit-clone.mjs ===== -->
````mjs
#!/usr/bin/env node
import fs from "node:fs";
import path from "node:path";

function usage() {
  console.log(`Usage:
  node scripts/audit-clone.mjs --project <clone-dir> [--brand "KOKUYO,Original Brand"] [--out CLONE_AUDIT.md]
    [--recon RECON/original-recon.json] [--strict]

Scans clone source files for tracking scripts, original-brand residue, Japanese residue, TODOs, and risky external dependencies.
With --recon, additionally runs fidelity gates against the original recon (fonts self-hosted?
images actually downloaded? key section colors exact?). --strict exits 2 on fidelity findings
so the clone workflow can hard-gate on it.
`);
}

function parseArgs(argv) {
  const out = { project: process.cwd(), brand: [], out: "CLONE_AUDIT.md", recon: "", strict: false };
  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    if (arg === "--help" || arg === "-h") out.help = true;
    else if (arg === "--project") out.project = argv[++i] || process.cwd();
    else if (arg === "--brand") out.brand = (argv[++i] || "").split(",").map((s) => s.trim()).filter(Boolean);
    else if (arg === "--out") out.out = argv[++i] || "CLONE_AUDIT.md";
    else if (arg === "--recon") out.recon = argv[++i] || "";
    else if (arg === "--strict") out.strict = true;
    else throw new Error(`Unexpected argument: ${arg}`);
  }
  return out;
}

// ---- Fidelity gates (fonts / images / palette vs. the original recon) ------

const GENERIC_FONT_FAMILIES = new Set([
  "serif", "sans-serif", "monospace", "cursive", "fantasy", "system-ui",
  "-apple-system", "blinkmacsystemfont", "segoe ui", "roboto", "helvetica",
  "helvetica neue", "arial", "pingfang sc", "microsoft yahei", "ui-sans-serif",
  "ui-serif", "ui-monospace", "times new roman", "georgia", "courier new",
]);

function customFontFamilies(recon) {
  const first = recon?.captures?.[0]?.signals || {};
  const families = new Set();
  for (const face of first.fontFaces || []) {
    if (face.family) families.add(face.family.trim());
  }
  for (const family of first.fonts || []) {
    const clean = String(family).replace(/['"]/g, "").trim();
    if (clean && !GENERIC_FONT_FAMILIES.has(clean.toLowerCase())) families.add(clean);
  }
  return Array.from(families);
}

// rgb()/rgba()/#hex → "r,g,b"; null for transparent (alpha 0) / unparseable —
// a transparent original color enforces nothing on the clone.
function normalizeColor(value) {
  const v = String(value || "").trim().toLowerCase();
  let m = v.match(/^rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)(?:\s*,\s*([0-9.]+))?\s*\)/);
  if (m) {
    if (m[4] !== undefined && Number(m[4]) === 0) return null;
    return `${m[1]},${m[2]},${m[3]}`;
  }
  m = v.match(/^#([0-9a-f]{3})$/);
  if (m) return m[1].split("").map((c) => parseInt(c + c, 16)).join(",");
  m = v.match(/^#([0-9a-f]{6})/);
  if (m) return [m[1].slice(0, 2), m[1].slice(2, 4), m[1].slice(4, 6)].map((h) => parseInt(h, 16)).join(",");
  return null;
}

function collectCloneColors(files) {
  const colors = new Set();
  for (const file of files) {
    if (![".html", ".css"].includes(path.extname(file).toLowerCase())) continue;
    const text = fs.readFileSync(file, "utf8");
    for (const m of text.matchAll(/#[0-9a-f]{3}\b|#[0-9a-f]{6}\b|rgba?\([^)]*\)/gi)) {
      const norm = normalizeColor(m[0]);
      if (norm) colors.add(norm);
    }
  }
  return colors;
}

function fidelityFindings(recon, project, files) {
  const findings = [];
  const first = recon?.captures?.[0]?.signals || {};
  const add = (label, detail) => findings.push({ type: "fidelity", label, file: project, line: 0, match: detail });

  // 字体: 原站有自定义字体 → 复刻必须有本地字体文件 + @font-face。
  const wantedFamilies = customFontFamilies(recon);
  if (wantedFamilies.length) {
    const fontFiles = files.filter((f) => /\.(woff2?|ttf|otf)$/i.test(f));
    const hasFontFace = files.some((f) => {
      if (![".html", ".css"].includes(path.extname(f).toLowerCase())) return false;
      return /@font-face/i.test(fs.readFileSync(f, "utf8"));
    });
    if (!fontFiles.length) {
      add("fonts not self-hosted", `original uses custom fonts (${wantedFamilies.join(", ")}) but the clone ships no local font files — run asset-harvest and link fonts/fonts.css`);
    } else if (!hasFontFace) {
      add("fonts downloaded but unused", `local font files exist but no @font-face references them (${wantedFamilies.join(", ")})`);
    }
  }

  // 图片: 原站真实加载过图片 → 复刻必须落地本地图片文件，不许全靠占位。
  const originalImageCount = (first.resources?.images || first.images || []).length;
  if (originalImageCount >= 3) {
    const imageFiles = files.filter((f) => /\.(png|jpe?g|gif|webp|avif)$/i.test(f));
    if (!imageFiles.length) {
      add("images not harvested", `original loaded ${originalImageCount} images but the clone ships zero local image files — placeholders/gradients are not a clone`);
    }
  }

  // 颜色: 关键区块(body/header/footer)的计算色必须在复刻源码里逐字出现。
  const cloneColors = collectCloneColors(files);
  for (const key of ["body", "header", "footer"]) {
    const section = first.palette?.[key];
    if (!section) continue;
    for (const prop of ["backgroundColor", "color"]) {
      const norm = normalizeColor(section[prop]);
      if (!norm) continue; // transparent / unparseable — nothing to enforce
      if (!cloneColors.has(norm)) {
        add(`palette mismatch: ${key} ${prop}`, `original computed ${section[prop]} (rgb ${norm}) not found anywhere in clone css/html — copy the exact value from recon, do not eyeball`);
      }
    }
  }
  return findings;
}

const includeExt = new Set([".html", ".css", ".js", ".jsx", ".ts", ".tsx", ".json", ".md", ".txt", ".svg"]);
const skipDirs = new Set([".git", "node_modules", "dist", "build", ".next", ".nuxt", "coverage", "RECON"]);
const skipFiles = new Set(["NOTES.md", "TEARDOWN.md", "CLONE_REPORT.md", "CLONE_AUDIT.md", "REPLACE_GUIDE.md"]);

function walk(dir, files = []) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (skipDirs.has(entry.name)) continue;
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      if (entry.name === "screenshots") continue;
      walk(full, files);
    } else if (!skipFiles.has(entry.name) && includeExt.has(path.extname(entry.name).toLowerCase())) {
      files.push(full);
    }
  }
  return files;
}

function lineNumber(text, index) {
  return text.slice(0, index).split("\n").length;
}

function collectMatches(file, text, checks) {
  const findings = [];
  for (const check of checks) {
    const regex = new RegExp(check.pattern, check.flags || "gi");
    for (const match of text.matchAll(regex)) {
      const matchedText = String(match[0]);
      if (check.type === "external" && /^https?:\/\/(www\.)?w3\.org\//i.test(matchedText)) continue;
      findings.push({
        type: check.type,
        label: check.label,
        file,
        line: lineNumber(text, match.index || 0),
        match: matchedText.slice(0, 160),
      });
    }
  }
  return findings;
}

function markdown(findings, project, scannedFiles) {
  const byType = new Map();
  for (const finding of findings) {
    if (!byType.has(finding.type)) byType.set(finding.type, []);
    byType.get(finding.type).push(finding);
  }
  const types = [
    ["fidelity", "保真度硬伤（字体 / 图片 / 颜色）"],
    ["tracking", "追踪脚本 / 统计像素"],
    ["brand", "原站品牌残留"],
    ["japanese", "日文残留"],
    ["todo", "TODO / 占位内容"],
    ["external", "外部依赖 / 外链风险"],
  ];
  const lines = [
    `# Clone Audit`,
    "",
    `- Project: ${project}`,
    `- Scanned files: ${scannedFiles}`,
    `- Findings: ${findings.length}`,
    "",
  ];

  for (const [type, title] of types) {
    const items = byType.get(type) || [];
    lines.push(`## ${title}`);
    if (!items.length) {
      lines.push("- 未发现");
      lines.push("");
      continue;
    }
    for (const item of items.slice(0, 200)) {
      lines.push(`- ${path.relative(project, item.file)}:${item.line} · ${item.label} · \`${item.match.replaceAll("`", "'")}\``);
    }
    if (items.length > 200) lines.push(`- 还有 ${items.length - 200} 条未展开`);
    lines.push("");
  }

  lines.push("## 结论");
  lines.push(findings.length ? "- 需要处理上面的残留项后再声明可部署。" : "- 未发现明显残留项；仍需人工核查素材授权和视觉截图。");
  return `${lines.join("\n")}\n`;
}

try {
  const args = parseArgs(process.argv.slice(2));
  if (args.help) {
    usage();
    process.exit(0);
  }

  const project = path.resolve(args.project);
  if (!fs.existsSync(project)) throw new Error(`Project not found: ${project}`);

  const brandPatterns = args.brand.map((brand) => ({
    type: "brand",
    label: `brand residue: ${brand}`,
    pattern: brand.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"),
    flags: "gi",
  }));

  const checks = [
    { type: "tracking", label: "Google Tag Manager", pattern: "googletagmanager|GTM-[A-Z0-9]+", flags: "gi" },
    { type: "tracking", label: "Google Analytics / gtag", pattern: "google-analytics|gtag\\s*\\(|ga\\s*\\(", flags: "gi" },
    { type: "tracking", label: "Meta Pixel / fbq", pattern: "connect\\.facebook\\.net|fbq\\s*\\(", flags: "gi" },
    { type: "tracking", label: "Hotjar / Clarity", pattern: "hotjar|clarity\\.ms|hj\\s*\\(", flags: "gi" },
    { type: "japanese", label: "Japanese kana residue", pattern: "[\\u3040-\\u30ff]{2,}", flags: "g" },
    { type: "todo", label: "TODO / placeholder content", pattern: "TODO|FIXME|lorem ipsum|待补|这里填写", flags: "gi" },
    { type: "external", label: "external URL", pattern: "https?://[^\\s\"')<>]+", flags: "gi" },
    ...brandPatterns,
  ];

  const files = walk(project);
  const findings = [];
  for (const file of files) {
    const text = fs.readFileSync(file, "utf8");
    findings.push(...collectMatches(file, text, checks));
  }

  // 字体/图片/颜色保真门槛——只在提供 --recon 时启用；walk() 跳过了字体/图片
  // 二进制，这里需要一份含它们的完整清单。
  let fidelity = [];
  if (args.recon) {
    const recon = JSON.parse(fs.readFileSync(args.recon, "utf8"));
    const allFiles = [];
    (function walkAll(dir) {
      for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
        if (skipDirs.has(entry.name)) continue;
        const full = path.join(dir, entry.name);
        if (entry.isDirectory()) walkAll(full);
        else allFiles.push(full);
      }
    })(project);
    fidelity = fidelityFindings(recon, project, allFiles);
    findings.unshift(...fidelity);
  }

  const output = path.resolve(args.out);
  fs.mkdirSync(path.dirname(output), { recursive: true });
  fs.writeFileSync(output, markdown(findings, project, files.length));
  console.log(output);
  if (fidelity.length) {
    console.error(`⚠️ ${fidelity.length} 个保真度硬伤（详见 ${path.relative(process.cwd(), output)}）：`);
    for (const item of fidelity) console.error(`   - ${item.label}: ${item.match}`);
    if (args.strict) process.exit(2);
  }
} catch (error) {
  console.error(`audit-clone failed: ${error.message}`);
  process.exit(1);
}

````

<!-- ===== FILE: scripts/compare-recon.mjs ===== -->
````mjs
#!/usr/bin/env node
import fs from "node:fs";
import path from "node:path";

function usage() {
  console.log(`Usage:
  node scripts/compare-recon.mjs --original <original-recon.json> --clone <clone-recon.json> [--visual-diff visual-diff.json] [--original-routes route-map.json] [--clone-routes route-map.json] [--original-interactions interactions.json] [--clone-interactions interactions.json] [--out CLONE_REPORT.md]
`);
}

function parseArgs(argv) {
  const out = {
    original: "",
    clone: "",
    visualDiff: "",
    originalRoutes: "",
    cloneRoutes: "",
    originalInteractions: "",
    cloneInteractions: "",
    out: "CLONE_REPORT.md",
  };
  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    if (arg === "--help" || arg === "-h") out.help = true;
    else if (arg === "--original") out.original = argv[++i] || "";
    else if (arg === "--clone") out.clone = argv[++i] || "";
    else if (arg === "--visual-diff") out.visualDiff = argv[++i] || "";
    else if (arg === "--original-routes") out.originalRoutes = argv[++i] || "";
    else if (arg === "--clone-routes") out.cloneRoutes = argv[++i] || "";
    else if (arg === "--original-interactions") out.originalInteractions = argv[++i] || "";
    else if (arg === "--clone-interactions") out.cloneInteractions = argv[++i] || "";
    else if (arg === "--out") out.out = argv[++i] || "CLONE_REPORT.md";
    else throw new Error(`Unexpected argument: ${arg}`);
  }
  return out;
}

function readJson(file) {
  return JSON.parse(fs.readFileSync(file, "utf8"));
}

function firstSignals(recon) {
  return recon.captures?.[0]?.signals || {};
}

function boolList(flags = {}) {
  return Object.entries(flags).filter(([, value]) => value).map(([key]) => key);
}

function ratioScore(a, b) {
  if (a === 0 && b === 0) return 5;
  if (a === 0 || b === 0) return 1;
  const ratio = Math.min(a, b) / Math.max(a, b);
  if (ratio > 0.9) return 5;
  if (ratio > 0.75) return 4;
  if (ratio > 0.55) return 3;
  if (ratio > 0.3) return 2;
  return 1;
}

function sequenceSimilarity(a, b) {
  const left = a.map((item) => `${item.tag}:${item.text}`).filter(Boolean);
  const right = b.map((item) => `${item.tag}:${item.text}`).filter(Boolean);
  if (!left.length && !right.length) return 1;
  if (!left.length || !right.length) return 0;
  const rightSet = new Set(right);
  const hits = left.filter((item) => rightSet.has(item)).length;
  return hits / Math.max(left.length, right.length);
}

function inferComplexity(signals) {
  const frameworks = boolList(signals.frameworks);
  const counts = signals.counts || {};
  if ((counts.forms || 0) > 2 && (counts.inputs || 0) > 10) return "L6";
  if ((counts.canvas || 0) > 0 || signals.frameworks?.three) return "L5";
  if (signals.frameworks?.gsap || signals.frameworks?.lenis || (counts.video || 0) > 2) return "L4";
  if (frameworks.some((name) => ["react", "next", "vue", "nuxt", "svelte", "astro"].includes(name))) return "L3";
  if ((counts.links || 0) > 80 || (counts.images || 0) > 40) return "L2";
  return "L1";
}

function score(original, clone, visualDiff) {
  const o = firstSignals(original);
  const c = firstSignals(clone);
  const structureSimilarity = sequenceSimilarity(o.headings || [], c.headings || []);
  const structure = Math.max(1, Math.round(structureSimilarity * 5));
  const responsive = original.captures?.length === clone.captures?.length ? 4 : 2;
  const functionCounts = ["links", "forms", "buttons", "inputs"].map((key) => ratioScore(o.counts?.[key] || 0, c.counts?.[key] || 0));
  const functional = Math.round(functionCounts.reduce((sum, value) => sum + value, 0) / functionCounts.length);
  const motionCounts = ["canvas", "video"].map((key) => ratioScore(o.counts?.[key] || 0, c.counts?.[key] || 0));
  const interaction = Math.round(motionCounts.reduce((sum, value) => sum + value, 0) / motionCounts.length);
  return {
    sourceEvidence: 3,
    structure,
    visual: visualDiff ? `${visualDiff.visualScore}/5` : "需人工看截图或传 --visual-diff",
    interaction,
    responsive,
    functional,
    contentReplacement: "需人工看文案残留",
    legalRisk: "需人工核查 license / 素材",
  };
}

function line(value) {
  if (Array.isArray(value)) return value.join(", ") || "none";
  return value ?? "";
}

function routePath(url) {
  try {
    const parsed = new URL(url);
    return `${parsed.pathname}${parsed.search}` || "/";
  } catch {
    return url;
  }
}

function routesSection(files, evidence) {
  if (!evidence.originalRoutes || !evidence.cloneRoutes) {
    return `## 路由覆盖
- 未提供 route-crawl 结果。多页面站需要传 --original-routes / --clone-routes。
`;
  }
  const originalSet = new Set((evidence.originalRoutes.routes || []).map((route) => routePath(route.url)));
  const cloneSet = new Set((evidence.cloneRoutes.routes || []).map((route) => routePath(route.url)));
  const matched = Array.from(originalSet).filter((item) => cloneSet.has(item));
  const missing = Array.from(originalSet).filter((item) => !cloneSet.has(item));
  const extra = Array.from(cloneSet).filter((item) => !originalSet.has(item));
  const coverage = originalSet.size ? Math.round((matched.length / originalSet.size) * 100) : 100;
  return `## 路由覆盖
- 原站路由: ${originalSet.size}
- 克隆路由: ${cloneSet.size}
- 覆盖率: ${coverage}%
- 原站 route map: ${files.originalRoutes}
- 克隆 route map: ${files.cloneRoutes}
- 缺失路由: ${missing.join(", ") || "无"}
- 额外路由: ${extra.join(", ") || "无"}
`;
}

function changedActionCount(interactions) {
  return (interactions?.actions || []).filter((action) => action.changed).length;
}

function interactionSection(files, evidence) {
  if (!evidence.originalInteractions || !evidence.cloneInteractions) {
    return `## 交互覆盖
- 未提供 interaction-probe 结果。交互站需要传 --original-interactions / --clone-interactions。
`;
  }
  const originalActions = evidence.originalInteractions.actions || [];
  const cloneActions = evidence.cloneInteractions.actions || [];
  const originalChanged = changedActionCount(evidence.originalInteractions);
  const cloneChanged = changedActionCount(evidence.cloneInteractions);
  const originalCanvas = evidence.originalInteractions.discovered?.canvases?.length || 0;
  const cloneCanvas = evidence.cloneInteractions.discovered?.canvases?.length || 0;
  const originalInteractive = evidence.originalInteractions.discovered?.interactive?.length || 0;
  const cloneInteractive = evidence.cloneInteractions.discovered?.interactive?.length || 0;
  return `## 交互覆盖
- 原站可见交互目标: ${originalInteractive}
- 克隆可见交互目标: ${cloneInteractive}
- 原站 canvas 目标: ${originalCanvas}
- 克隆 canvas 目标: ${cloneCanvas}
- 原站 changed actions: ${originalChanged}/${originalActions.length}
- 克隆 changed actions: ${cloneChanged}/${cloneActions.length}
- 原站 interaction probe: ${files.originalInteractions}
- 克隆 interaction probe: ${files.cloneInteractions}
- 判断: ${originalChanged === cloneChanged && originalCanvas === cloneCanvas ? "交互数量信号接近，仍需看截图确认状态质量。" : "交互数量信号不一致，需要检查缺失状态或过度实现。"}
`;
}

function report(files, original, clone, evidence) {
  const o = firstSignals(original);
  const c = firstSignals(clone);
  const scores = score(original, clone, evidence.visualDiff);
  const complexity = inferComplexity(o);
  const originalFlags = boolList(o.frameworks);
  const cloneFlags = boolList(c.frameworks);
  const counts = ["sections", "links", "images", "video", "canvas", "forms", "buttons", "inputs", "interactive", "scripts"];

  return `# ${original.label || "original"} vs ${clone.label || "clone"} · 克隆评估报告

## 结论
- 原站 URL: ${original.url}
- 克隆 URL: ${clone.url}
- 自动推断复杂度: ${complexity}
- 复刻模式建议: ${complexity === "L5" ? "技术拆解 / 忠实复刻优先" : complexity === "L6" ? "展示层视觉复刻" : "视觉复刻 / 内容爆改"}
- 自动报告边界: 结构、数量、框架、console 可自动比；传入 visual-diff 后可纳入像素差异分。内容残留和法务仍需审计。

## 技术信号
| 项目 | 原站 | 克隆站 |
|---|---|---|
| title | ${o.title || ""} | ${c.title || ""} |
| lang | ${o.lang || ""} | ${c.lang || ""} |
| frameworks | ${line(originalFlags)} | ${line(cloneFlags)} |
| scrollHeight | ${o.scrollHeight || 0} | ${c.scrollHeight || 0} |
| h1 | ${line(o.h1)} | ${line(c.h1)} |

## 数量对比
| 指标 | 原站 | 克隆站 | 自动评分 |
|---|---:|---:|---:|
${counts.map((key) => `| ${key} | ${o.counts?.[key] || 0} | ${c.counts?.[key] || 0} | ${ratioScore(o.counts?.[key] || 0, c.counts?.[key] || 0)}/5 |`).join("\n")}

## 复刻评分
- 源证据: ${scores.sourceEvidence}/5
- 结构保真: ${scores.structure}/5
- 视觉保真: ${scores.visual}
- 动效/交互: ${scores.interaction}/5
- 响应式: ${scores.responsive}/5
- 功能完整: ${scores.functional}/5
- 内容替换: ${scores.contentReplacement}
- 法务/部署风险: ${scores.legalRisk}

## Console
- 原站 console errors: ${original.console?.errors?.length || 0}
- 克隆 console errors: ${clone.console?.errors?.length || 0}
- 原站 page errors: ${original.console?.pageErrors?.length || 0}
- 克隆 page errors: ${clone.console?.pageErrors?.length || 0}

${routesSection(files, evidence)}

${interactionSection(files, evidence)}

## 截图证据
- 原站侦察: ${files.original}
- 克隆侦察: ${files.clone}
- 像素差异: ${files.visualDiff || "未提供"}
- 像素差异率: ${evidence.visualDiff ? evidence.visualDiff.diffPixelRatio : "未提供"}
- 原站截图: ${(original.captures || []).map((capture) => capture.screenshot).join(", ")}
- 克隆截图: ${(clone.captures || []).map((capture) => capture.screenshot).join(", ")}

## 已知缺口
- 未传入 visual-diff 时，视觉保真需要打开截图人工确认。
- 法务、素材授权、品牌替换完整度需要人工核查。
`;
}

try {
  const args = parseArgs(process.argv.slice(2));
  if (args.help || !args.original || !args.clone) {
    usage();
    process.exit(args.help ? 0 : 1);
  }

  const original = readJson(args.original);
  const clone = readJson(args.clone);
  const visualDiff = args.visualDiff ? readJson(args.visualDiff) : null;
  const originalRoutes = args.originalRoutes ? readJson(args.originalRoutes) : null;
  const cloneRoutes = args.cloneRoutes ? readJson(args.cloneRoutes) : null;
  const originalInteractions = args.originalInteractions ? readJson(args.originalInteractions) : null;
  const cloneInteractions = args.cloneInteractions ? readJson(args.cloneInteractions) : null;
  const output = path.resolve(args.out);
  fs.mkdirSync(path.dirname(output), { recursive: true });
  fs.writeFileSync(output, report(args, original, clone, {
    visualDiff,
    originalRoutes,
    cloneRoutes,
    originalInteractions,
    cloneInteractions,
  }));
  console.log(output);
} catch (error) {
  console.error(`compare-recon failed: ${error.message}`);
  process.exit(1);
}

````

<!-- ===== FILE: scripts/dna-scaffold.mjs ===== -->
````mjs
#!/usr/bin/env node
// dna-scaffold.mjs — 生成 design-dna.json 骨架，best-effort 从 recon-site.mjs 的输出预填。
// 用法:
//   node scripts/dna-scaffold.mjs --out <design-dna.json> [--recon <label-recon.json>] [--name <站名>]
// 产物:
//   <out>  完整 DNA 骨架；有 --recon 时预填字体/色候选/框架特效信号，其余留 "" 待人工 Analyze。
// 纪律: 只搬侦察里"真实抓到"的信号，绝不编造。拿不准角色(primary/accent)的色值统一丢进 _recon_signals 供人工指派。

import fs from "node:fs";
import path from "node:path";

function parseArgs(argv) {
  const out = { recon: "", out: "", name: "", help: false };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "--help" || a === "-h") out.help = true;
    else if (a === "--recon") out.recon = argv[++i] || "";
    else if (a === "--out") out.out = argv[++i] || "";
    else if (a === "--name") out.name = argv[++i] || "";
  }
  return out;
}

function usage() {
  console.log(`dna-scaffold.mjs — 生成 design-dna.json 骨架并 best-effort 预填

  node scripts/dna-scaffold.mjs --out <design-dna.json> [--recon <label-recon.json>] [--name <站名>]

只用在「视觉复刻 / 内容爆改」模式。忠实复刻分支不需要 DNA（真源码即真相）。
schema 与字段含义见 references/design-dna.md。`);
}

// 完整 DNA 骨架（与 references/design-dna.md 对齐）
function skeleton(name) {
  const ts = () => ({ size: "", weight: "", line_height: "", tracking: "" });
  return {
    meta: { name: name || "", description: "", source_references: "", created_at: "" },
    design_system: {
      color: {
        palette_type: "",
        primary: { hex: "", role: "" },
        secondary: { hex: "", role: "" },
        accent: { hex: "", role: "" },
        neutral: { scale: "", usage: "" },
        semantic: { success: "", warning: "", error: "", info: "" },
        surface: { background: "", card: "", elevated: "" },
        contrast_strategy: "",
      },
      typography: {
        type_scale: {
          display: ts(), heading_1: ts(), heading_2: ts(), heading_3: ts(),
          body: ts(), body_small: ts(), caption: ts(), overline: ts(),
        },
        font_families: { heading: "", body: "", mono: "" },
        font_style_notes: "",
      },
      spacing: { base_unit: "", scale: "", content_density: "", section_rhythm: "" },
      layout: { grid_system: "", max_content_width: "", columns: "", gutter: "", breakpoints: "", alignment_tendency: "" },
      shape: { border_radius: { small: "", medium: "", large: "", pill: "" }, border_usage: "", divider_style: "" },
      elevation: { shadow_style: "", levels: { low: "", medium: "", high: "" }, depth_cues: "" },
      iconography: { style: "", stroke_weight: "", size_scale: "", preferred_set: "" },
      motion: { easing: "", duration_scale: { micro: "", normal: "", macro: "" }, entrance_pattern: "", exit_pattern: "", philosophy: "" },
      components: { button_style: "", input_style: "", card_style: "", navigation_pattern: "", modal_style: "", list_style: "", component_notes: "" },
    },
    design_style: {
      aesthetic: { mood: [], visual_metaphor: "", era_influence: "", genre: "", personality_traits: [], adjectives: [] },
      visual_language: { complexity: "", ornamentation: "", whitespace_usage: "", visual_weight_distribution: "", focal_strategy: "", contrast_level: "", texture_usage: "" },
      composition: { hierarchy_method: "", balance_type: "", flow_direction: "", grouping_strategy: "", negative_space_role: "" },
      imagery: { photo_treatment: "", illustration_style: "", graphic_elements: "", pattern_usage: "", image_shape: "" },
      interaction_feel: { feedback_style: "", hover_behavior: "", transition_personality: "", loading_style: "", microinteraction_density: "" },
      brand_voice_in_ui: { tone: "", formality: "", cta_style: "", empty_state_approach: "", error_tone: "" },
    },
    visual_effects: {
      overview: { effect_intensity: "", performance_tier: "", fallback_strategy: "", primary_technology: "" },
      background_effects: { type: "", description: "", technology: "", params: { color_palette: "", speed: "", density: "", opacity: "", blend_mode: "" } },
      particle_systems: { enabled: false, type: "", description: "", technology: "", params: { count: "", shape: "", size_range: "", movement_pattern: "", color_behavior: "", interaction: "", spawn_area: "" } },
      "3d_elements": { enabled: false, type: "", description: "", technology: "", params: { renderer: "", lighting: "", camera: "", materials: "", geometry: "", post_processing: [], interaction_model: "" } },
      shader_effects: { enabled: false, type: "", description: "", technology: "", params: { uniforms: "", vertex_manipulation: "", fragment_output: "", noise_type: "", distortion: "" } },
      scroll_effects: { parallax: { enabled: false, layers: "", depth_range: "", speed_curve: "" }, scroll_triggered_animations: { enabled: false, trigger_points: "", animation_type: "", scrub_behavior: "" }, scroll_morphing: { enabled: false, description: "" } },
      text_effects: { type: "", description: "", technology: "", params: { split_strategy: "", animation_per_unit: "", stagger: "", effect_style: "" } },
      cursor_effects: { enabled: false, type: "", description: "", params: { shape: "", size: "", blend_mode: "", trail: "", interaction_zone: "" } },
      image_effects: { type: "", description: "", technology: "", params: { filter_pipeline: "", hover_transform: "", reveal_animation: "", distortion_type: "" } },
      glassmorphism_neumorphism: { enabled: false, style: "", params: { blur_radius: "", transparency: "", border_treatment: "", shadow_type: "", light_source_angle: "" } },
      canvas_drawings: { enabled: false, type: "", description: "", technology: "", params: { draw_method: "", animation_loop: "", color_scheme: "", responsiveness: "", interaction: "" } },
      svg_animations: { enabled: false, type: "", description: "", params: { animation_method: "", path_morphing: "", stroke_animation: "", filter_effects: "" } },
      composite_notes: "",
    },
  };
}

const COLOR_RE = /(#[0-9a-fA-F]{3,8}\b|\brgba?\([^)]*\)|\bhsla?\([^)]*\))/;

// recon-site.mjs 把信号按视口嵌在 captures[].signals 下；取最宽视口的 signals 摊平，
// 兼容已是扁平结构的 recon 输入。摊平失败则原样返回(enrich 对缺字段已容错)。
function flattenRecon(recon) {
  if (recon && Array.isArray(recon.captures) && recon.captures.length) {
    const widest = recon.captures
      .filter((c) => c && c.signals)
      .sort((a, b) => (b?.viewport?.width || 0) - (a?.viewport?.width || 0))[0];
    if (widest && widest.signals) {
      // 顶层 url 兜底进 href，便于 meta.source_references 预填
      return { href: recon.url, ...widest.signals };
    }
  }
  return recon;
}

function uniq(arr) {
  return Array.from(new Set(arr.filter(Boolean)));
}

// 从 recon JSON best-effort 抽信号，并预填 skeleton 的明确字段
function enrich(dna, recon) {
  const signals = { fonts: [], color_candidates: [], frameworks: {}, canvas_count: 0, css_color_vars: [] };

  // 字体: fonts[] + sections[].style.fontFamily
  const fontList = uniq([
    ...(Array.isArray(recon.fonts) ? recon.fonts : []),
    ...((recon.sections || []).map((s) => s?.style?.fontFamily).filter(Boolean)),
  ]).map((f) => String(f).replace(/^["']|["']$/g, "").split(",")[0].trim()).filter(Boolean);
  signals.fonts = uniq(fontList);
  if (signals.fonts.length) {
    const mono = signals.fonts.find((f) => /mono|code|consol|courier/i.test(f)) || "";
    const nonMono = signals.fonts.filter((f) => f !== mono);
    dna.design_system.typography.font_families.heading = nonMono[0] || "";
    dna.design_system.typography.font_families.body = nonMono[1] || nonMono[0] || "";
    dna.design_system.typography.font_families.mono = mono;
  }

  // 颜色: CSS 变量里像颜色的 + sections 的 bg/color
  const cssVars = Array.isArray(recon.cssVariables) ? recon.cssVariables : [];
  for (const pair of cssVars) {
    const [name, val] = Array.isArray(pair) ? pair : [pair?.name, pair?.value];
    if (val && COLOR_RE.test(String(val))) signals.css_color_vars.push(`${name}: ${String(val).trim()}`);
  }
  const sectionColors = [];
  for (const s of recon.sections || []) {
    const bg = s?.style?.backgroundColor;
    const fg = s?.style?.color;
    if (bg && !/rgba?\(0, 0, 0, 0\)|transparent/i.test(bg)) sectionColors.push(bg);
    if (fg) sectionColors.push(fg);
  }
  signals.color_candidates = uniq([
    ...signals.css_color_vars.map((v) => v.split(":").slice(1).join(":").trim()),
    ...sectionColors,
  ]).slice(0, 24);
  // body/header 背景作为 surface.background 候选(第一个非透明的 section bg)
  const firstBg = (recon.sections || []).map((s) => s?.style?.backgroundColor)
    .find((c) => c && !/rgba?\(0, 0, 0, 0\)|transparent/i.test(c));
  if (firstBg) dna.design_system.color.surface.background = firstBg;

  // 框架/特效信号
  const fw = recon.frameworks || {};
  signals.frameworks = fw;
  signals.canvas_count = (recon.canvases && recon.canvases.length) || recon?.counts?.canvas || 0;

  if (fw.three) {
    dna.visual_effects.overview.primary_technology = "WebGL/Three.js";
    dna.visual_effects.overview.performance_tier = "heavy";
    dna.visual_effects["3d_elements"].enabled = true;
    dna.visual_effects["3d_elements"].technology = "Three.js";
  } else if (signals.canvas_count > 0) {
    dna.visual_effects.overview.primary_technology = "Canvas 2D";
    dna.visual_effects.canvas_drawings.enabled = true;
  } else if (fw.gsap) {
    dna.visual_effects.overview.primary_technology = "GSAP";
  }
  if (fw.gsap || fw.lenis) {
    dna.visual_effects.scroll_effects.scroll_triggered_animations.enabled = true;
    dna.visual_effects.scroll_effects.scroll_triggered_animations.scrub_behavior =
      fw.lenis ? "lenis smooth-scroll detected" : "gsap detected";
  }

  // meta 预填
  if (recon.href) dna.meta.source_references = recon.href;
  if (!dna.meta.name && recon.title) dna.meta.name = recon.title;

  // 把原始信号留在顶层供人工指派角色(不编造 primary/accent)
  dna._recon_signals = signals;
  dna._scaffold_note =
    "best-effort 预填来自 recon。font_families/surface.background/visual_effects 已据真实信号填写；" +
    "color 的 primary/secondary/accent 角色需人工从 _recon_signals.color_candidates 指派；" +
    "所有 \"\" 字段需人工 Analyze 补全(见 references/design-dna.md)。确认无误后可删除 _recon_signals 与本说明。";
  return dna;
}

try {
  const args = parseArgs(process.argv.slice(2));
  if (args.help || !args.out) {
    usage();
    process.exit(args.help ? 0 : 1);
  }
  let dna = skeleton(args.name);
  if (args.recon) {
    try {
      const recon = JSON.parse(fs.readFileSync(path.resolve(args.recon), "utf8"));
      dna = enrich(dna, flattenRecon(recon));
    } catch (e) {
      console.warn(`⚠️ 读 recon 失败(${e.message})，只输出空骨架。`);
    }
  }
  const outPath = path.resolve(args.out);
  fs.mkdirSync(path.dirname(outPath), { recursive: true });
  fs.writeFileSync(outPath, `${JSON.stringify(dna, null, 2)}\n`);
  console.log(`✅ design-dna 骨架已写入: ${outPath}`);
  if (dna._recon_signals) {
    const s = dna._recon_signals;
    console.log(`   预填: 字体 ${s.fonts.length} 个 / 色候选 ${s.color_candidates.length} 个 / canvas ${s.canvas_count} / three=${!!s.frameworks.three} gsap=${!!s.frameworks.gsap} lenis=${!!s.frameworks.lenis}`);
  }
  console.log(`   下一步: 人工 Analyze 补全 ""，并从 _recon_signals 指派颜色角色。schema → references/design-dna.md`);
} catch (e) {
  console.error(`dna-scaffold 失败: ${e.message}`);
  process.exit(1);
}

````

<!-- ===== FILE: scripts/init-clone.mjs ===== -->
````mjs
#!/usr/bin/env node
import fs from "node:fs";
import path from "node:path";

function usage() {
  console.log(`Usage:
  node scripts/init-clone.mjs <slug> [--url <url>] [--mode <mode>] [--level <L1-L6>] [--root <dir>] [--in-place]

Creates:
  <root>/<slug>-clone/
  <root>/<slug>-clone/NOTES.md
  <root>/<slug>-clone/RECON/screenshots/

With --in-place, creates NOTES.md and RECON/screenshots/ in <root> itself.
`);
}

function parseArgs(argv) {
  const out = { slug: null, url: "", mode: "", level: "", root: process.cwd(), inPlace: false };
  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    if (arg === "--help" || arg === "-h") out.help = true;
    else if (arg === "--url") out.url = argv[++i] || "";
    else if (arg === "--mode") out.mode = argv[++i] || "";
    else if (arg === "--level") out.level = argv[++i] || "";
    else if (arg === "--root") out.root = argv[++i] || process.cwd();
    else if (arg === "--in-place") out.inPlace = true;
    else if (!out.slug) out.slug = arg;
    else throw new Error(`Unexpected argument: ${arg}`);
  }
  return out;
}

function cleanSlug(input) {
  return input
    .trim()
    .toLowerCase()
    .replace(/https?:\/\//g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

function notesTemplate({ name, url, mode, level }) {
  return `# ${name} · 克隆笔记

## 源信息
- 原站 URL: ${url}
- 源码仓库:
- 原作者:
- 许可证:
- 致谢要求:

## 技术栈
- 框架 / 关键库 / Node 版本:

## 复刻前预判
- 复杂度等级: ${level}
- 推荐模式: ${mode}
- 可高保真的部分:
- 需要近似或替代的部分:
- 不克隆的部分:
- 主要风险:

## 跑起来
\`\`\`bash
python3 -m http.server 8123
\`\`\`

## 改了什么（对照原版）
-

## 原站 vs 克隆站
| 模块 | 原站表现 | 克隆实现 | 差异 / 取舍 | 证据 |
|---|---|---|---|---|
| 首屏 |  |  |  |  |
| 导航 |  |  |  |  |
| 核心动效 |  |  |  |  |
| 内容区块 |  |  |  |  |
| 移动端 |  |  |  |  |

## 复刻评分
- 源证据: /5
- 结构保真: /5
- 视觉保真: /5
- 动效/交互: /5
- 响应式: /5
- 功能完整: /5
- 内容替换: /5
- 法务/部署风险: /5
- 总评:

## 替换地图（要换什么改哪）
- 文字 -> 文件 行
- 图片/媒体 -> 目录
- 配色 -> CSS 变量 / theme
- 3D 模型 / 字体 ->

## 验证
- [ ] 本地跑通、console 0 error
- [ ] 截图对照原站（RECON/screenshots/）
- 验证不了的点（如实记，别伪造）:
`;
}

try {
  const args = parseArgs(process.argv.slice(2));
  if (args.help || !args.slug) {
    usage();
    process.exit(args.help ? 0 : 1);
  }

  const slug = cleanSlug(args.slug);
  if (!slug) throw new Error("Slug is empty after normalization.");
  const name = slug.endsWith("-clone") ? slug : `${slug}-clone`;
  const root = path.resolve(args.root || process.cwd());
  const project = args.inPlace ? root : path.join(root, name);

  if (!args.inPlace && fs.existsSync(project)) {
    throw new Error(`Project already exists: ${project}`);
  }

  fs.mkdirSync(path.join(project, "RECON", "screenshots"), { recursive: true });
  fs.writeFileSync(
    path.join(project, "NOTES.md"),
    notesTemplate({
      name,
      url: args.url,
      mode: args.mode,
      level: args.level,
    })
  );
  fs.writeFileSync(path.join(project, ".gitignore"), "node_modules/\n.DS_Store\n");

  console.log(project);
} catch (error) {
  console.error(`init-clone failed: ${error.message}`);
  process.exit(1);
}

````

<!-- ===== FILE: scripts/interaction-probe.mjs ===== -->
````mjs
#!/usr/bin/env node
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { loadPlaywright, launchChromium } from "./lib/playwright-loader.mjs";

function usage() {
  console.log(`Usage:
  node scripts/interaction-probe.mjs --url <url> --out RECON/interactions [--label original] [--max-clicks 12] [--max-hovers 8] [--wait 800] [--width 1440]

Exercises scroll, hover, safe clicks, and canvas drag gestures, then saves screenshots plus state/network evidence.
`);
}

function parseArgs(argv) {
  const out = {
    url: "",
    outDir: "RECON/interactions",
    label: "site",
    maxClicks: 12,
    maxHovers: 8,
    waitMs: 800,
    width: 1440,
  };
  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    if (arg === "--help" || arg === "-h") out.help = true;
    else if (arg === "--url") out.url = argv[++i] || "";
    else if (arg === "--out") out.outDir = argv[++i] || "RECON/interactions";
    else if (arg === "--label") out.label = argv[++i] || "site";
    else if (arg === "--max-clicks") out.maxClicks = Number(argv[++i] || "12");
    else if (arg === "--max-hovers") out.maxHovers = Number(argv[++i] || "8");
    else if (arg === "--wait") out.waitMs = Number(argv[++i] || "800");
    else if (arg === "--width") out.width = Number(argv[++i] || "1440");
    else throw new Error(`Unexpected argument: ${arg}`);
  }
  return out;
}

function shortHash(value) {
  return crypto.createHash("sha1").update(value).digest("hex").slice(0, 10);
}

function safeFileName(label) {
  return label.replace(/[^a-z0-9._-]+/gi, "-").replace(/^-+|-+$/g, "").slice(0, 90) || "step";
}

function markdown(result) {
  const lines = [
    `# ${result.label} interaction probe`,
    "",
    `- URL: ${result.url}`,
    `- Actions: ${result.actions.length}`,
    `- Console errors: ${result.consoleErrors.length}`,
    `- Network events: ${result.network.length}`,
    "",
    "## Actions",
    "| # | Type | Target | Changed | URL after | Screenshot |",
    "|---:|---|---|---:|---|---|",
  ];
  result.actions.forEach((action, index) => {
    lines.push(`| ${index + 1} | ${action.type} | ${String(action.target || "").replaceAll("|", "\\|")} | ${action.changed ? "yes" : "no"} | ${action.after.url.replaceAll("|", "\\|")} | ${action.screenshot || ""} |`);
  });
  if (result.findings.length) {
    lines.push("");
    lines.push("## Findings");
    for (const finding of result.findings) lines.push(`- ${finding}`);
  }
  return `${lines.join("\n")}\n`;
}

async function snapshot(page) {
  return page.evaluate(() => {
    const text = (node) => (node?.textContent || "").trim().replace(/\s+/g, " ");
    const visible = (selector) => Array.from(document.querySelectorAll(selector)).filter((node) => {
      const rect = node.getBoundingClientRect();
      const style = getComputedStyle(node);
      return rect.width > 0 && rect.height > 0 && style.visibility !== "hidden" && style.display !== "none";
    }).length;
    const bodyText = document.body?.innerText || "";
    const html = document.documentElement.outerHTML;
    return {
      url: location.href,
      title: document.title || "",
      activeElement: document.activeElement?.tagName?.toLowerCase() || "",
      scrollY: Math.round(window.scrollY),
      bodyTextChars: bodyText.length,
      bodyTextStart: bodyText.trim().replace(/\s+/g, " ").slice(0, 500),
      counts: {
        dialogs: visible("dialog,[role='dialog'],[aria-modal='true']"),
        popovers: visible("[popover],.popover,.modal,.drawer,.menu,[role='menu']"),
        canvases: document.querySelectorAll("canvas").length,
        videos: document.querySelectorAll("video").length,
        buttons: document.querySelectorAll("button,[role='button']").length,
        forms: document.forms.length,
      },
      htmlHash: "__HASH_PLACEHOLDER__",
      htmlLength: html.length,
    };
  });
}

async function hashSnapshot(page, state) {
  const htmlHash = await page.evaluate(() => {
    const html = document.documentElement.outerHTML;
    let hash = 0;
    for (let i = 0; i < html.length; i += 1) {
      hash = ((hash << 5) - hash + html.charCodeAt(i)) | 0;
    }
    return String(hash);
  });
  return { ...state, htmlHash };
}

async function candidates(page) {
  return page.evaluate(() => {
    function selectorFor(node) {
      if (node.id && !/\s/.test(node.id)) return `#${CSS.escape(node.id)}`;
      const parts = [];
      let current = node;
      while (current && current.nodeType === Node.ELEMENT_NODE && parts.length < 6) {
        const tag = current.tagName.toLowerCase();
        const parent = current.parentElement;
        if (!parent) {
          parts.unshift(tag);
          break;
        }
        const sameTag = Array.from(parent.children).filter((child) => child.tagName === current.tagName);
        const index = sameTag.indexOf(current) + 1;
        parts.unshift(`${tag}:nth-of-type(${index})`);
        current = parent;
      }
      return parts.join(" > ");
    }
    const text = (node) => (node.innerText || node.textContent || node.getAttribute("aria-label") || "").trim().replace(/\s+/g, " ");
    const visible = (node) => {
      const rect = node.getBoundingClientRect();
      const style = getComputedStyle(node);
      return rect.width >= 8 && rect.height >= 8 && style.visibility !== "hidden" && style.display !== "none";
    };
    const interactive = Array.from(document.querySelectorAll("button,a[href],summary,input,textarea,select,[role='button'],[tabindex]"))
      .filter(visible)
      .slice(0, 80)
      .map((node) => {
        const rect = node.getBoundingClientRect();
        const tag = node.tagName.toLowerCase();
        const href = node.href || node.getAttribute("href") || "";
        const safeClick = tag === "button" || tag === "summary" || node.getAttribute("role") === "button" || href.startsWith("#") || href.startsWith(location.origin);
        return {
          selector: selectorFor(node),
          tag,
          type: node.getAttribute("type") || "",
          role: node.getAttribute("role") || "",
          href,
          text: text(node).slice(0, 120),
          ariaLabel: node.getAttribute("aria-label") || "",
          safeClick,
          rect: {
            x: Math.round(rect.x),
            y: Math.round(rect.y),
            width: Math.round(rect.width),
            height: Math.round(rect.height),
          },
        };
      });
    const canvases = Array.from(document.querySelectorAll("canvas")).filter(visible).slice(0, 4).map((node) => {
      const rect = node.getBoundingClientRect();
      return {
        selector: selectorFor(node),
        rect: {
          x: Math.round(rect.x),
          y: Math.round(rect.y),
          width: Math.round(rect.width),
          height: Math.round(rect.height),
        },
      };
    });
    return { interactive, canvases };
  });
}

function hasChanged(before, after) {
  if (before.url !== after.url) return true;
  if (before.htmlHash !== after.htmlHash) return true;
  if (before.scrollY !== after.scrollY) return true;
  return JSON.stringify(before.counts) !== JSON.stringify(after.counts);
}

async function freshPage(browser, args, network, consoleErrors) {
  const page = await browser.newPage({ viewport: { width: args.width, height: 900 }, deviceScaleFactor: 1 });
  page.on("console", (message) => {
    if (message.type() === "error") consoleErrors.push(message.text());
  });
  page.on("response", (response) => {
    const request = response.request();
    if (["xhr", "fetch"].includes(request.resourceType())) {
      network.push({ url: response.url(), status: response.status(), method: request.method(), resourceType: request.resourceType() });
    }
  });
  await page.goto(args.url, { waitUntil: "domcontentloaded", timeout: 45000 });
  await page.waitForLoadState("networkidle", { timeout: 6000 }).catch(() => {});
  if (args.waitMs > 0) await page.waitForTimeout(args.waitMs);
  return page;
}

async function captureAction(page, outDir, index, action, before) {
  if (action.type === "scroll") {
    await page.evaluate((ratio) => window.scrollTo({ top: Math.round((document.documentElement.scrollHeight - window.innerHeight) * ratio), behavior: "instant" }), action.ratio);
  } else if (action.type === "hover") {
    await page.locator(action.selector).first().hover({ timeout: 3000 });
  } else if (action.type === "click") {
    await page.locator(action.selector).first().click({ timeout: 4000 });
  } else if (action.type === "canvas-drag") {
    const rect = action.rect;
    const x = rect.x + rect.width / 2;
    const y = rect.y + rect.height / 2;
    await page.mouse.move(x, y);
    await page.mouse.down();
    await page.mouse.move(x + Math.min(180, rect.width * 0.25), y + Math.min(120, rect.height * 0.2), { steps: 8 });
    await page.mouse.up();
  }
  await page.waitForTimeout(450);
  const after = await hashSnapshot(page, await snapshot(page));
  const screenshotName = `${String(index + 1).padStart(2, "0")}-${safeFileName(`${action.type}-${action.target || action.selector || "page"}`)}-${shortHash(JSON.stringify(action))}.png`;
  const screenshotPath = path.join(outDir, "screenshots", screenshotName);
  await page.screenshot({ path: screenshotPath, fullPage: true });
  return {
    ...action,
    before,
    after,
    changed: hasChanged(before, after),
    screenshot: path.relative(outDir, screenshotPath),
  };
}

try {
  const args = parseArgs(process.argv.slice(2));
  if (args.help || !args.url) {
    usage();
    process.exit(args.help ? 0 : 1);
  }

  const outDir = path.resolve(args.outDir);
  fs.mkdirSync(path.join(outDir, "screenshots"), { recursive: true });

  const { chromium } = loadPlaywright();
  const browser = await launchChromium(chromium);
  const network = [];
  const consoleErrors = [];

  const seedPage = await freshPage(browser, args, network, consoleErrors);
  const initial = await hashSnapshot(seedPage, await snapshot(seedPage));
  const discovered = await candidates(seedPage);
  await seedPage.screenshot({ path: path.join(outDir, "screenshots", "00-initial.png"), fullPage: true });
  await seedPage.close();

  const actions = [
    { type: "scroll", target: "middle", ratio: 0.5 },
    { type: "scroll", target: "bottom", ratio: 1 },
    ...discovered.interactive.slice(0, args.maxHovers).map((item) => ({ type: "hover", target: item.text || item.ariaLabel || item.selector, selector: item.selector, meta: item })),
    ...discovered.interactive.filter((item) => item.safeClick).slice(0, args.maxClicks).map((item) => ({ type: "click", target: item.text || item.ariaLabel || item.selector, selector: item.selector, meta: item })),
    ...discovered.canvases.map((item) => ({ type: "canvas-drag", target: item.selector, selector: item.selector, rect: item.rect })),
  ];

  const results = [];
  for (let index = 0; index < actions.length; index += 1) {
    const page = await freshPage(browser, args, network, consoleErrors);
    const before = await hashSnapshot(page, await snapshot(page));
    try {
      results.push(await captureAction(page, outDir, index, actions[index], before));
    } catch (error) {
      results.push({
        ...actions[index],
        before,
        after: before,
        changed: false,
        screenshot: "",
        error: error.message,
      });
    } finally {
      await page.close();
    }
  }

  await browser.close();

  const changedCount = results.filter((action) => action.changed).length;
  const findings = [
    `${discovered.interactive.length} visible interactive candidates discovered`,
    `${discovered.canvases.length} visible canvas targets discovered`,
    `${changedCount}/${results.length} actions changed DOM, URL, scroll, or visible overlay counts`,
  ];
  if (discovered.canvases.length) findings.push("Canvas drag evidence exists; inspect screenshots before simplifying WebGL/Canvas behavior.");

  const result = {
    label: args.label,
    url: args.url,
    capturedAt: new Date().toISOString(),
    initial,
    discovered,
    actions: results,
    network,
    consoleErrors,
    findings,
  };
  const jsonFile = path.join(outDir, `${args.label}-interactions.json`);
  const mdFile = path.join(outDir, `${args.label}-interactions.md`);
  fs.writeFileSync(jsonFile, `${JSON.stringify(result, null, 2)}\n`);
  fs.writeFileSync(mdFile, markdown(result));
  console.log(jsonFile);
} catch (error) {
  console.error(`interaction-probe failed: ${error.message}`);
  process.exit(1);
}

````

<!-- ===== FILE: scripts/lib/playwright-loader.mjs ===== -->
````mjs
import path from "node:path";
import { createRequire } from "node:module";
import fs from "node:fs";
import os from "node:os";
import { systemChromium } from "./system-browser.mjs";

// Reuse an already-provided Playwright runtime when one is available: explicit
// package paths first, then dependencies visible from the script or process
// cwd. Product runs otherwise fall back to the zero-dependency CDP adapter, so
// a web-clone task never mutates the user's project or downloads a browser.
export function loadPlaywright() {
  const requireFromScript = createRequire(import.meta.url);
  const requireFromCwd = createRequire(path.join(process.cwd(), "noop.js"));
  const attempts = [
    () => {
      const p = process.env.OD_PLAYWRIGHT_PACKAGE;
      if (!p) throw new Error("OD_PLAYWRIGHT_PACKAGE unset");
      return requireFromScript(p);
    },
    () => {
      const p = process.env.OD_PLAYWRIGHT_PATH;
      if (!p) throw new Error("OD_PLAYWRIGHT_PATH unset");
      return requireFromScript(p);
    },
    () => requireFromScript("playwright"),
    () => requireFromScript("playwright-core"),
    () => requireFromCwd("playwright"),
    () => requireFromCwd("playwright-core"),
  ];
  for (const attempt of attempts) {
    try {
      return attempt();
    } catch {
      // Try next candidate.
    }
  }
  return { chromium: systemChromium };
}

function firstExisting(candidates) {
  return candidates.find((candidate) => candidate && fs.existsSync(candidate)) || null;
}

function executableFromPath(names, env = process.env, platform = process.platform) {
  const pathValue = env.PATH || env.Path || "";
  const extensions = platform === "win32"
    ? (env.PATHEXT || ".EXE;.CMD;.BAT").split(";")
    : [""];
  for (const directory of pathValue.split(path.delimiter).filter(Boolean)) {
    for (const name of names) {
      for (const extension of extensions) {
        const candidate = path.join(directory, `${name}${extension}`);
        if (fs.existsSync(candidate)) return candidate;
      }
    }
  }
  return null;
}

export function findSystemChromiumExecutable({
  platform = process.platform,
  env = process.env,
  homeDir = os.homedir(),
} = {}) {
  const configured = env.OD_BROWSER_EXECUTABLE_PATH;
  if (configured) {
    if (fs.existsSync(configured)) return configured;
    throw new Error(`OD_BROWSER_EXECUTABLE_PATH does not exist: ${configured}`);
  }

  if (platform === "darwin") {
    return firstExisting([
      "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
      "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
      "/Applications/Chromium.app/Contents/MacOS/Chromium",
      path.join(homeDir, "Applications/Google Chrome.app/Contents/MacOS/Google Chrome"),
      path.join(homeDir, "Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge"),
    ]);
  }

  if (platform === "win32") {
    const roots = [env.PROGRAMFILES, env["PROGRAMFILES(X86)"], env.LOCALAPPDATA].filter(Boolean);
    return firstExisting(roots.flatMap((root) => [
      path.join(root, "Google/Chrome/Application/chrome.exe"),
      path.join(root, "Microsoft/Edge/Application/msedge.exe"),
      path.join(root, "Chromium/Application/chrome.exe"),
    ]));
  }

  return executableFromPath([
    "google-chrome-stable",
    "google-chrome",
    "microsoft-edge-stable",
    "microsoft-edge",
    "chromium",
    "chromium-browser",
  ], env, platform);
}

export async function launchChromium(chromium, options = {}) {
  // A staged skill can still see Playwright from a source checkout (notably in
  // CI). That must not bypass the product path: agent sandboxes frequently
  // cannot spawn Chrome, while the daemon owns a trusted browser process. Use
  // the zero-dependency adapter for daemon brokering even when the caller's
  // chromium object came from an already-installed Playwright package.
  const daemonChromium = typeof chromium.connectOverDaemon === "function"
    ? chromium
    : systemChromium;
  if (
    typeof daemonChromium.connectOverDaemon === "function"
    && process.env.OD_DAEMON_URL
    && process.env.OD_PROJECT_ID
  ) {
    try {
      return await daemonChromium.connectOverDaemon({
        daemonUrl: process.env.OD_DAEMON_URL,
        projectId: process.env.OD_PROJECT_ID,
      });
    } catch {
      // Older daemons may not expose the broker. Fall back to direct launch.
    }
  }
  const executablePath = findSystemChromiumExecutable(options.discovery);
  let systemBrowserError = null;
  if (executablePath) {
    try {
      return await chromium.launch({ headless: true, executablePath });
    } catch (error) {
      systemBrowserError = error;
    }
  }

  // Source checkouts may already have a Playwright-managed browser. Trying it
  // is safe: launch never downloads a browser; it only uses an existing one.
  try {
    return await chromium.launch({ headless: true });
  } catch (error) {
    throw new Error(
      "No compatible Chrome, Edge, or Chromium executable is available. " +
        "Open Design does not download a browser during web-clone tasks. " +
        "Install a system browser or set OD_BROWSER_EXECUTABLE_PATH to its executable. " +
        `Browser launch detail: ${systemBrowserError?.message || error.message}`,
    );
  }
}

````

<!-- ===== FILE: scripts/lib/system-browser.mjs ===== -->
````mjs
import { spawn } from "node:child_process";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";

const COMMAND_TIMEOUT_MS = 30_000;

function withTimeout(promise, timeoutMs, label) {
  let timer;
  return Promise.race([
    promise,
    new Promise((_, reject) => {
      timer = setTimeout(() => reject(new Error(`${label} timed out after ${timeoutMs}ms`)), timeoutMs);
      timer.unref?.();
    }),
  ]).finally(() => clearTimeout(timer));
}

class CdpConnection {
  constructor(url) {
    this.url = url;
    this.nextId = 1;
    this.pending = new Map();
    this.listeners = new Map();
    this.closed = false;
    this.socket = new WebSocket(url);
    this.ready = new Promise((resolve, reject) => {
      this.socket.addEventListener("open", resolve, { once: true });
      this.socket.addEventListener("error", () => reject(new Error(`CDP WebSocket failed: ${url}`)), { once: true });
    });
    this.socket.addEventListener("message", (event) => this.#handleMessage(event.data));
    this.socket.addEventListener("close", () => {
      this.closed = true;
      for (const { reject } of this.pending.values()) reject(new Error("CDP connection closed"));
      this.pending.clear();
    });
  }

  #handleMessage(raw) {
    let message;
    try {
      message = JSON.parse(String(raw));
    } catch {
      return;
    }
    if (message.id) {
      const pending = this.pending.get(message.id);
      if (!pending) return;
      this.pending.delete(message.id);
      if (message.error) pending.reject(new Error(message.error.message || JSON.stringify(message.error)));
      else pending.resolve(message.result || {});
      return;
    }
    if (!message.method) return;
    for (const listener of this.listeners.get(message.method) || []) {
      try {
        listener(message.params || {});
      } catch {
        // A consumer event handler must not break the CDP stream.
      }
    }
  }

  async send(method, params = {}, timeoutMs = COMMAND_TIMEOUT_MS) {
    await this.ready;
    if (this.closed || this.socket.readyState !== WebSocket.OPEN) {
      throw new Error("CDP connection closed");
    }
    const id = this.nextId++;
    const result = new Promise((resolve, reject) => this.pending.set(id, { resolve, reject }));
    this.socket.send(JSON.stringify({ id, method, params }));
    return withTimeout(result, timeoutMs, method);
  }

  on(method, listener) {
    const listeners = this.listeners.get(method) || new Set();
    listeners.add(listener);
    this.listeners.set(method, listeners);
    return () => listeners.delete(listener);
  }

  close() {
    this.closed = true;
    this.socket.close();
  }
}

function normalizeResourceType(value = "other") {
  const lower = String(value).toLowerCase();
  return lower === "xhr" || lower === "fetch" ? lower : lower;
}

function requestView(entry) {
  return {
    url: () => entry.url,
    method: () => entry.method,
    resourceType: () => normalizeResourceType(entry.resourceType),
    headers: () => entry.headers,
    postData: () => entry.postData || null,
  };
}

function responseView(page, entry) {
  return {
    url: () => entry.url,
    status: () => entry.status,
    ok: () => entry.status >= 200 && entry.status < 400,
    headers: () => entry.headers,
    request: () => requestView(entry.request),
    body: async () => page.responseBody(entry.requestId),
  };
}

export function fullPageScreenshotClip(metrics, viewport) {
  const content = metrics.cssContentSize || metrics.contentSize || {};
  return {
    x: 0,
    y: 0,
    // On Linux, a non-overlay vertical scrollbar reduces cssContentSize.width
    // even though the requested browser viewport is unchanged. Preserve the
    // requested viewport while still capturing genuine horizontal overflow.
    width: Math.max(1, viewport.width, content.width || 0),
    height: Math.max(1, viewport.height, content.height || 0),
    scale: 1,
  };
}

class CdpPage {
  static async create(browser, target, options = {}) {
    const page = new CdpPage(browser, target, options);
    await page.initialize();
    return page;
  }

  constructor(browser, target, options) {
    this.browser = browser;
    this.target = target;
    this.connection = new CdpConnection(target.webSocketDebuggerUrl);
    this.listeners = new Map();
    this.requests = new Map();
    this.finishedRequests = new Map();
    this.inflight = new Set();
    this.lastNetworkActivity = Date.now();
    this.navigationEpoch = 0;
    this.domContentEpoch = 0;
    this.loadEpoch = 0;
    this.mainFrameId = null;
    this.mainResponse = null;
    this.currentUrl = target.url || "about:blank";
    this.mousePosition = { x: 0, y: 0 };
    this.viewport = options.viewport || { width: 1280, height: 720 };
    this.deviceScaleFactor = options.deviceScaleFactor || 1;
  }

  async initialize() {
    await this.connection.ready;
    this.connection.on("Runtime.consoleAPICalled", ({ type, args = [] }) => {
      const text = args.map((arg) => arg.value ?? arg.description ?? "").join(" ");
      this.emit("console", { type: () => type, text: () => text });
    });
    this.connection.on("Runtime.exceptionThrown", ({ exceptionDetails }) => {
      this.emit("pageerror", new Error(exceptionDetails?.exception?.description || exceptionDetails?.text || "Page error"));
    });
    this.connection.on("Page.domContentEventFired", () => {
      this.domContentEpoch = this.navigationEpoch;
      this.emit("__domcontentloaded", {});
    });
    this.connection.on("Page.loadEventFired", () => {
      this.loadEpoch = this.navigationEpoch;
      this.emit("__load", {});
    });
    this.connection.on("Network.requestWillBeSent", (event) => this.#onRequest(event));
    this.connection.on("Network.responseReceived", (event) => this.#onResponse(event));
    this.connection.on("Network.loadingFinished", ({ requestId }) => this.#finishRequest(requestId, null));
    this.connection.on("Network.loadingFailed", ({ requestId, errorText }) => this.#finishRequest(requestId, errorText || "failed"));
    await Promise.all([
      this.connection.send("Page.enable"),
      this.connection.send("Runtime.enable"),
      this.connection.send("Network.enable", { maxTotalBufferSize: 100_000_000, maxResourceBufferSize: 25_000_000 }),
      this.connection.send("Emulation.setDeviceMetricsOverride", {
        width: this.viewport.width,
        height: this.viewport.height,
        deviceScaleFactor: this.deviceScaleFactor,
        mobile: false,
      }),
    ]);
  }

  #onRequest(event) {
    const request = {
      url: event.request?.url || "",
      method: event.request?.method || "GET",
      headers: event.request?.headers || {},
      postData: event.request?.postData || "",
      resourceType: event.type || "Other",
    };
    this.requests.set(event.requestId, request);
    if (!request.url.startsWith("data:")) this.inflight.add(event.requestId);
    this.lastNetworkActivity = Date.now();
    this.emit("request", requestView(request));
  }

  #onResponse(event) {
    const request = this.requests.get(event.requestId) || {
      url: event.response?.url || "",
      method: "GET",
      headers: {},
      postData: "",
      resourceType: event.type || "Other",
    };
    request.resourceType = event.type || request.resourceType;
    const headers = Object.fromEntries(
      Object.entries(event.response?.headers || {}).map(([key, value]) => [key.toLowerCase(), String(value)]),
    );
    const response = {
      requestId: event.requestId,
      url: event.response?.url || request.url,
      status: event.response?.status || 0,
      headers,
      request,
    };
    if (event.type === "Document" && (!this.mainFrameId || event.frameId === this.mainFrameId)) {
      this.mainResponse = response;
      this.currentUrl = response.url;
    }
    this.emit("response", responseView(this, response));
  }

  #finishRequest(requestId, error) {
    this.inflight.delete(requestId);
    this.lastNetworkActivity = Date.now();
    const pending = this.finishedRequests.get(requestId);
    if (pending) {
      this.finishedRequests.delete(requestId);
      if (error) pending.reject(new Error(error));
      else pending.resolve();
    } else {
      this.finishedRequests.set(requestId, { done: true, error });
    }
  }

  emit(name, payload) {
    for (const listener of this.listeners.get(name) || []) {
      try {
        const result = listener(payload);
        result?.catch?.(() => {});
      } catch {
        // Consumer listeners are observational.
      }
    }
  }

  on(name, listener) {
    const listeners = this.listeners.get(name) || new Set();
    listeners.add(listener);
    this.listeners.set(name, listeners);
    return this;
  }

  off(name, listener) {
    this.listeners.get(name)?.delete(listener);
    return this;
  }

  waitForEvent(name, predicate, timeoutMs) {
    return withTimeout(new Promise((resolve) => {
      const listener = (payload) => {
        if (predicate && !predicate(payload)) return;
        this.off(name, listener);
        resolve(payload);
      };
      this.on(name, listener);
    }), timeoutMs, name);
  }

  async goto(url, { waitUntil = "load", timeout = 30_000 } = {}) {
    this.navigationEpoch += 1;
    this.mainResponse = null;
    const epoch = this.navigationEpoch;
    const eventName = waitUntil === "domcontentloaded" ? "__domcontentloaded" : "__load";
    const eventWait = waitUntil === "networkidle"
      ? null
      : this.waitForEvent(eventName, () => this.navigationEpoch === epoch, timeout);
    const result = await this.connection.send("Page.navigate", { url }, timeout);
    if (result.errorText) throw new Error(`Navigation failed: ${result.errorText}`);
    this.mainFrameId = result.frameId || this.mainFrameId;
    this.currentUrl = url;
    if (waitUntil === "networkidle") await this.waitForNetworkIdle(timeout);
    else await eventWait;
    return this.mainResponse ? responseView(this, this.mainResponse) : null;
  }

  async waitForLoadState(state, { timeout = 30_000 } = {}) {
    if (state === "networkidle") return this.waitForNetworkIdle(timeout);
    const epoch = this.navigationEpoch;
    if (state === "domcontentloaded" && this.domContentEpoch === epoch) return;
    if (state === "load" && this.loadEpoch === epoch) return;
    return this.waitForEvent(state === "domcontentloaded" ? "__domcontentloaded" : "__load", null, timeout);
  }

  async waitForNetworkIdle(timeoutMs) {
    const started = Date.now();
    while (Date.now() - started < timeoutMs) {
      if (this.inflight.size === 0 && Date.now() - this.lastNetworkActivity >= 500) return;
      await new Promise((resolve) => setTimeout(resolve, 50));
    }
    throw new Error(`networkidle timed out after ${timeoutMs}ms`);
  }

  waitForTimeout(timeoutMs) {
    return new Promise((resolve) => setTimeout(resolve, timeoutMs));
  }

  async evaluate(fn, ...args) {
    const serializedArgs = args.map((arg) => JSON.stringify(arg ?? null)).join(",");
    const expression = `(${fn.toString()})(${serializedArgs})`;
    const result = await this.connection.send("Runtime.evaluate", {
      expression,
      awaitPromise: true,
      returnByValue: true,
      userGesture: true,
    });
    if (result.exceptionDetails) {
      throw new Error(result.exceptionDetails.exception?.description || result.exceptionDetails.text || "Evaluation failed");
    }
    return result.result?.value;
  }

  url() {
    return this.currentUrl;
  }

  async screenshot({ path: outputPath, fullPage = false } = {}) {
    const params = { format: "png", fromSurface: true, captureBeyondViewport: true };
    if (fullPage) {
      const metrics = await this.connection.send("Page.getLayoutMetrics");
      params.clip = fullPageScreenshotClip(metrics, this.viewport);
    } else {
      params.clip = { x: 0, y: 0, width: this.viewport.width, height: this.viewport.height, scale: 1 };
    }
    const { data } = await this.connection.send("Page.captureScreenshot", params, 60_000);
    fs.mkdirSync(path.dirname(outputPath), { recursive: true });
    fs.writeFileSync(outputPath, Buffer.from(data, "base64"));
  }

  async responseBody(requestId) {
    const finished = this.finishedRequests.get(requestId);
    if (!finished) {
      await withTimeout(new Promise((resolve, reject) => {
        this.finishedRequests.set(requestId, { resolve, reject });
      }), 30_000, "response body");
    } else if (!finished.done) {
      await withTimeout(new Promise((resolve, reject) => {
        this.finishedRequests.set(requestId, { resolve, reject });
      }), 30_000, "response body");
    } else if (finished.error) {
      throw new Error(finished.error);
    }
    const result = await this.connection.send("Network.getResponseBody", { requestId });
    return Buffer.from(result.body || "", result.base64Encoded ? "base64" : "utf8");
  }

  locator(selector) {
    const page = this;
    const locate = async () => {
      const rect = await page.evaluate((value) => {
        const element = document.querySelector(value);
        if (!element) return null;
        element.scrollIntoView({ block: "center", inline: "center" });
        const box = element.getBoundingClientRect();
        return { x: box.x, y: box.y, width: box.width, height: box.height };
      }, selector);
      if (!rect || rect.width <= 0 || rect.height <= 0) throw new Error(`Element not actionable: ${selector}`);
      return { x: rect.x + rect.width / 2, y: rect.y + rect.height / 2 };
    };
    return {
      first() {
        return this;
      },
      async hover() {
        const point = await locate();
        await page.mouse.move(point.x, point.y);
      },
      async click() {
        const point = await locate();
        await page.mouse.move(point.x, point.y);
        await page.mouse.down();
        await page.mouse.up();
      },
    };
  }

  mouse = {
    move: async (x, y, { steps = 1 } = {}) => {
      const start = this.mousePosition;
      for (let step = 1; step <= steps; step += 1) {
        const next = {
          x: start.x + ((x - start.x) * step) / steps,
          y: start.y + ((y - start.y) * step) / steps,
        };
        await this.connection.send("Input.dispatchMouseEvent", { type: "mouseMoved", ...next });
        this.mousePosition = next;
      }
    },
    down: async () => {
      await this.connection.send("Input.dispatchMouseEvent", {
        type: "mousePressed",
        ...this.mousePosition,
        button: "left",
        buttons: 1,
        clickCount: 1,
      });
    },
    up: async () => {
      await this.connection.send("Input.dispatchMouseEvent", {
        type: "mouseReleased",
        ...this.mousePosition,
        button: "left",
        buttons: 0,
        clickCount: 1,
      });
    },
  };

  async close() {
    this.connection.close();
    await fetch(`${this.browser.httpBase}/json/close/${this.target.id}`).catch(() => undefined);
  }
}

class BrowserRequestContext {
  constructor(context) {
    this.context = context;
  }

  async get(url, { headers = {}, maxRedirects = 5, timeout = 30_000 } = {}) {
    let cookies = [];
    try {
      const page = this.context.pages.at(-1);
      cookies = page ? (await page.connection.send("Network.getCookies", { urls: [url] })).cookies || [] : [];
    } catch {}
    const cookie = cookies.map((entry) => `${entry.name}=${entry.value}`).join("; ");
    const response = await fetch(url, {
      headers: { ...headers, ...(cookie ? { cookie } : {}) },
      redirect: maxRedirects > 0 ? "follow" : "manual",
      signal: AbortSignal.timeout(timeout),
    });
    return {
      ok: () => response.ok,
      status: () => response.status,
      body: async () => Buffer.from(await response.arrayBuffer()),
    };
  }
}

class CdpContext {
  constructor(browser, options = {}) {
    this.browser = browser;
    this.options = options;
    this.pages = [];
    this.request = new BrowserRequestContext(this);
  }

  async newPage() {
    const page = await this.browser.createPage(this.options);
    this.pages.push(page);
    return page;
  }
}

class SystemBrowser {
  constructor(child, profileDir, browserSocketUrl, closeRemote = null) {
    this.child = child;
    this.profileDir = profileDir;
    this.closeRemote = closeRemote;
    const socket = new URL(browserSocketUrl);
    this.httpBase = `http://${socket.host}`;
    this.closed = false;
  }

  async createPage(options = {}) {
    const response = await fetch(`${this.httpBase}/json/new?${encodeURIComponent("about:blank")}`, { method: "PUT" });
    if (!response.ok) throw new Error(`Chrome target creation failed: HTTP ${response.status}`);
    const target = await response.json();
    return CdpPage.create(this, target, options);
  }

  newPage(options = {}) {
    return this.createPage(options);
  }

  newContext(options = {}) {
    return Promise.resolve(new CdpContext(this, options));
  }

  async close() {
    if (this.closed) return;
    this.closed = true;
    if (this.closeRemote) {
      await this.closeRemote();
      return;
    }
    this.child.kill("SIGTERM");
    await Promise.race([
      new Promise((resolve) => this.child.once("exit", resolve)),
      new Promise((resolve) => setTimeout(resolve, 2_000)),
    ]);
    if (this.child.exitCode == null) this.child.kill("SIGKILL");
    fs.rmSync(this.profileDir, { recursive: true, force: true });
  }
}

async function connectOverDaemon({ daemonUrl, projectId }) {
  if (!daemonUrl || !projectId) throw new Error("OD_DAEMON_URL and OD_PROJECT_ID are required");
  const endpoint = `${daemonUrl.replace(/\/$/, "")}/api/projects/${encodeURIComponent(projectId)}/browser-sessions`;
  const response = await fetch(endpoint, { method: "POST", headers: { "content-type": "application/json" } });
  if (!response.ok) {
    const detail = await response.text().catch(() => "");
    throw new Error(`daemon browser session failed: HTTP ${response.status}${detail ? ` ${detail}` : ""}`);
  }
  const payload = await response.json();
  const session = payload.browserSession;
  if (!session?.id || !session?.websocketUrl) throw new Error("daemon returned an invalid browser session");
  return new SystemBrowser(null, null, session.websocketUrl, async () => {
    await fetch(`${endpoint}/${encodeURIComponent(session.id)}`, { method: "DELETE" }).catch(() => undefined);
  });
}

async function launchSystemBrowser({ executablePath }) {
  if (!executablePath) throw new Error("A system browser executable path is required");
  const profileDir = fs.mkdtempSync(path.join(os.tmpdir(), "od-web-clone-browser-"));
  const child = spawn(executablePath, [
    "--headless=new",
    "--remote-debugging-port=0",
    "--remote-allow-origins=*",
    `--user-data-dir=${profileDir}`,
    "--no-first-run",
    "--no-default-browser-check",
    "--disable-background-networking",
    "--disable-component-update",
    "--disable-default-apps",
    "--disable-sync",
    "--metrics-recording-only",
    "about:blank",
  ], { stdio: ["ignore", "pipe", "pipe"] });

  const browserSocketUrl = await withTimeout(new Promise((resolve, reject) => {
    let output = "";
    const inspect = (chunk) => {
      output += String(chunk);
      const match = output.match(/DevTools listening on (ws:\/\/[^\s]+)/);
      if (match) resolve(match[1]);
    };
    child.stdout.on("data", inspect);
    child.stderr.on("data", inspect);
    child.once("error", reject);
    child.once("exit", (code) => reject(new Error(`System browser exited before CDP was ready (code ${code})`)));
  }), 15_000, "system browser startup").catch((error) => {
    child.kill("SIGKILL");
    fs.rmSync(profileDir, { recursive: true, force: true });
    throw error;
  });

  return new SystemBrowser(child, profileDir, browserSocketUrl);
}

export const systemChromium = {
  launch: launchSystemBrowser,
  connectOverDaemon,
};

````

<!-- ===== FILE: scripts/mirror-site.mjs ===== -->
````mjs
#!/usr/bin/env node
// mirror-site.mjs — 把"静态构建站"(Astro / Vite SSG / Hugo 等)的部署资产整套镜像下来，做 1:1 忠实复刻。
// 原理: 这类站的"真源码"不在 GitHub，但部署出来的静态资产(HTML + bundle + CSS + 运行时 fetch 的
//       .sog/.buf/.wasm/.riv/字体/图)就是真相。用真浏览器全程滚动一遍捕获每一个真实请求，按路径镜像同源资产。
// 用法:
//   node scripts/mirror-site.mjs --url <URL> --out <dir> [--scroll-step 700] [--settle 2500] [--max-ms 90000]
// 产物:
//   <dir>/site/...                镜像的同源资产(保留路径；目录 URL 存为 index.html)
//   <dir>/mirror-manifest.json    全部请求(同源+第三方) + 每项状态
//   <dir>/own-asset-urls.txt      同源资产路径清单
//   <dir>/third-party.json        第三方 host + 需自托管的 webfont CSS(typekit/google) 提示
// 纪律: 只搬"真实请求到的"资产，不臆造路径。第三方 CDN(字体/wasm/视频)不自动改写——按 third-party.json 人工处理。
//       后续手工: 自托管锁域名字体(典型 Typekit @import) → 改写 CSS @import 为本地 → 删追踪 → 从 site/ 作 web 根服务。
//       完整配方见 references/static-mirror.md。

import { loadPlaywright, launchChromium } from "./lib/playwright-loader.mjs";
import fs from "node:fs";
import path from "node:path";

function parseArgs(argv) {
  const o = { url: "", out: "", scrollStep: 700, settle: 2500, maxMs: 90000, help: false };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "--help" || a === "-h") o.help = true;
    else if (a === "--url") o.url = argv[++i] || "";
    else if (a === "--out") o.out = argv[++i] || "";
    else if (a === "--scroll-step") o.scrollStep = parseInt(argv[++i] || "700", 10);
    else if (a === "--settle") o.settle = parseInt(argv[++i] || "2500", 10);
    else if (a === "--max-ms") o.maxMs = parseInt(argv[++i] || "90000", 10);
  }
  return o;
}

function usage() {
  console.log(`mirror-site.mjs — 静态构建站全量资产镜像(1:1 忠实复刻)

  node scripts/mirror-site.mjs --url <URL> --out <dir> [--scroll-step 700] [--settle 2500] [--max-ms 90000]

适用: Astro / Vite SSG / Hugo / 任何把客户端运行时输出成可下载静态资产的站(含 WebGL/Canvas 重前端)。
不适用: 真·服务端渲染/数据驱动 SPA(需 network-capture.mjs 做 API 替身)。
配方与后续改写步骤(自托管字体/删追踪/服务) → references/static-mirror.md`);
}

// 同源资产 URL → 本地相对路径(去 query；目录结尾存 index.html)
function urlToLocalPath(u, origin) {
  let p = u.slice(origin.length);
  const q = p.indexOf("?");
  if (q >= 0) p = p.slice(0, q);
  if (p === "" || p.endsWith("/")) p += "index.html";
  return p.replace(/^\/+/, "");
}

const args = parseArgs(process.argv.slice(2));
if (args.help || !args.url || !args.out) {
  usage();
  process.exit(args.help ? 0 : 1);
}

const origin = new URL(args.url).origin;
const siteDir = path.join(path.resolve(args.out), "site");
fs.mkdirSync(siteDir, { recursive: true });

const responses = new Map(); // url -> {status, type, ct}
const pw = loadPlaywright();
const browser = await launchChromium(pw.chromium);
const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 }, deviceScaleFactor: 1 });
const page = await ctx.newPage();
page.on("response", (resp) => {
  try {
    const h = resp.headers();
    responses.set(resp.url(), { status: resp.status(), type: resp.request().resourceType(), ct: h["content-type"] || "" });
  } catch {}
});

console.log(`▸ 加载 + 全程滚动捕获: ${args.url}`);
await page.goto(args.url, { waitUntil: "networkidle", timeout: args.maxMs }).catch((e) => console.warn("  goto:", e.message));
const total = await page.evaluate(() => document.documentElement.scrollHeight);
for (let y = 0; y <= total; y += args.scrollStep) {
  await page.evaluate((yy) => window.scrollTo(0, yy), y);
  await page.waitForTimeout(180);
}
await page.evaluate(() => window.scrollTo(0, document.documentElement.scrollHeight));
await page.waitForTimeout(args.settle);
await page.evaluate(() => window.scrollTo(0, 0));
await page.waitForTimeout(1200);

const all = [...responses.entries()].map(([url, m]) => ({ url, ...m }));
const ownUrls = all.filter((r) => r.url.startsWith(origin + "/") || r.url === origin || r.url === origin + "/");

console.log(`▸ 捕获请求 ${all.length} 个；同源 ${ownUrls.length} 个，开始下载…`);
let ok = 0, fail = 0;
const failed = [];
for (const r of ownUrls) {
  const rel = urlToLocalPath(r.url, origin);
  const dest = path.join(siteDir, rel);
  try {
    const resp = await ctx.request.get(r.url); // 复用浏览器网络栈(cookie/TUN/代理一致)
    if (!resp.ok()) { fail++; failed.push(`HTTP${resp.status()} ${rel}`); continue; }
    const buf = await resp.body();
    fs.mkdirSync(path.dirname(dest), { recursive: true });
    fs.writeFileSync(dest, buf);
    ok++;
  } catch (e) {
    fail++; failed.push(`${e.message} ${rel}`);
  }
}

// 第三方 + webfont 提示
const thirdHosts = [...new Set(all.filter((r) => !r.url.startsWith(origin)).map((r) => { try { return new URL(r.url).host; } catch { return r.url; } }))];
const webfontCss = all.map((r) => r.url).filter((u) => /use\.typekit\.net\/[a-z0-9]+\.css|fonts\.googleapis\.com\/css/i.test(u));
const outRoot = path.resolve(args.out);
fs.writeFileSync(path.join(outRoot, "mirror-manifest.json"), JSON.stringify(all, null, 2));
fs.writeFileSync(path.join(outRoot, "own-asset-urls.txt"), ownUrls.map((r) => urlToLocalPath(r.url, origin)).sort().join("\n") + "\n");
fs.writeFileSync(path.join(outRoot, "third-party.json"), JSON.stringify({ hosts: thirdHosts, webfont_css_to_selfhost: webfontCss }, null, 2));

console.log(`✅ 镜像完成: ${ok} 成功 / ${fail} 失败 → ${siteDir}`);
if (failed.length) console.log("  ⚠️ 失败:\n   " + failed.slice(0, 20).join("\n   "));
console.log(`▸ 第三方 host: ${thirdHosts.join(", ") || "(无)"}`);
if (webfontCss.length) console.log(`▸ 需自托管的 webfont CSS(锁域名,见 static-mirror.md): \n   ${webfontCss.join("\n   ")}`);
console.log(`▸ 下一步: 自托管字体 + 改写 CSS @import + 删追踪 → cd ${siteDir} && python3 -m http.server 8124`);
await browser.close();

````

<!-- ===== FILE: scripts/network-capture.mjs ===== -->
````mjs
#!/usr/bin/env node
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { loadPlaywright, launchChromium } from "./lib/playwright-loader.mjs";

function usage() {
  console.log(`Usage:
  node scripts/network-capture.mjs --url <url> --out RECON/network [--label original] [--wait 5000] [--max-bytes 1000000]

Captures browser requests and saves JSON/text XHR/fetch responses as fixtures.
`);
}

function parseArgs(argv) {
  const out = { url: "", outDir: "RECON/network", label: "site", waitMs: 5000, maxBytes: 1_000_000 };
  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    if (arg === "--help" || arg === "-h") out.help = true;
    else if (arg === "--url") out.url = argv[++i] || "";
    else if (arg === "--out") out.outDir = argv[++i] || "RECON/network";
    else if (arg === "--label") out.label = argv[++i] || "site";
    else if (arg === "--wait") out.waitMs = Number(argv[++i] || "5000");
    else if (arg === "--max-bytes") out.maxBytes = Number(argv[++i] || "1000000");
    else throw new Error(`Unexpected argument: ${arg}`);
  }
  return out;
}

function safeFixtureName(url, contentType) {
  const parsed = new URL(url);
  const cleanPath = parsed.pathname.replace(/[^a-z0-9._-]+/gi, "-").replace(/^-+|-+$/g, "").slice(0, 80) || "response";
  const hash = crypto.createHash("sha1").update(url).digest("hex").slice(0, 10);
  const ext = contentType.includes("json") ? ".json" : ".txt";
  return `${cleanPath}-${hash}${ext}`;
}

function shouldSave(resourceType, contentType) {
  if (!["xhr", "fetch"].includes(resourceType)) return false;
  return /json|text|graphql|javascript/i.test(contentType || "");
}

try {
  const args = parseArgs(process.argv.slice(2));
  if (args.help || !args.url) {
    usage();
    process.exit(args.help ? 0 : 1);
  }

  const outDir = path.resolve(args.outDir);
  const fixturesDir = path.join(outDir, "fixtures");
  fs.mkdirSync(fixturesDir, { recursive: true });

  const { chromium } = loadPlaywright();
  const browser = await launchChromium(chromium);
  const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });

  const requests = [];
  const responses = [];

  page.on("request", (request) => {
    requests.push({
      url: request.url(),
      method: request.method(),
      resourceType: request.resourceType(),
      headers: request.headers(),
      postData: request.postData() || "",
    });
  });

  page.on("response", async (response) => {
    const request = response.request();
    const headers = response.headers();
    const contentType = headers["content-type"] || "";
    const entry = {
      url: response.url(),
      status: response.status(),
      ok: response.ok(),
      method: request.method(),
      resourceType: request.resourceType(),
      contentType,
      fixture: "",
      error: "",
    };

    if (shouldSave(request.resourceType(), contentType)) {
      try {
        const body = await response.body();
        if (body.length <= args.maxBytes) {
          const file = path.join(fixturesDir, safeFixtureName(response.url(), contentType));
          fs.writeFileSync(file, body);
          entry.fixture = path.relative(outDir, file);
          entry.bytes = body.length;
        } else {
          entry.error = `body too large: ${body.length}`;
        }
      } catch (error) {
        entry.error = error.message;
      }
    }

    responses.push(entry);
  });

  await page.goto(args.url, { waitUntil: "domcontentloaded", timeout: 45000 });
  await page.waitForLoadState("networkidle", { timeout: args.waitMs }).catch(() => {});
  if (args.waitMs > 0) await page.waitForTimeout(args.waitMs);
  await browser.close();

  const manifest = {
    label: args.label,
    url: args.url,
    capturedAt: new Date().toISOString(),
    requestCount: requests.length,
    responseCount: responses.length,
    fixtureCount: responses.filter((response) => response.fixture).length,
    requests,
    responses,
  };

  const manifestFile = path.join(outDir, `${args.label}-network.json`);
  fs.writeFileSync(manifestFile, `${JSON.stringify(manifest, null, 2)}\n`);
  console.log(manifestFile);
} catch (error) {
  console.error(`network-capture failed: ${error.message}`);
  process.exit(1);
}

````

<!-- ===== FILE: scripts/od-preview-rewrite.mjs ===== -->
````mjs
#!/usr/bin/env node
import fs from "node:fs";
import path from "node:path";

function usage() {
  console.log(`Usage:
  node scripts/od-preview-rewrite.mjs [--project <clone-dir>]

Rewrites project-root asset URLs in HTML/CSS/SVG files so OpenDesign's
file preview and exported zip can render the clone from nested entry files.
`);
}

function parseArgs(argv) {
  const out = { project: process.cwd(), help: false };
  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    if (arg === "--help" || arg === "-h") out.help = true;
    else if (arg === "--project") out.project = argv[++i] || process.cwd();
    else throw new Error(`Unexpected argument: ${arg}`);
  }
  return out;
}

const includeExt = new Set([".html", ".htm", ".css", ".svg"]);
const skipDirs = new Set([
  ".git",
  ".next",
  ".nuxt",
  "build",
  "coverage",
  "dist",
  "node_modules",
  "RECON",
]);

const projectAssetPrefixes = new Set([
  "_next",
  "asset",
  "assets",
  "assets-cdn",
  "audio",
  "css",
  "favicon",
  "file",
  "files",
  "flower",
  "flowers",
  "font",
  "fonts",
  "icon",
  "icons",
  "image",
  "images",
  "img",
  "install-screenshots",
  "js",
  "media",
  "public",
  "reference-assets",
  "script",
  "scripts",
  "static",
  "video",
  "videos",
]);

const hostRootPrefixes = new Set(["api", "artifacts", "frames"]);

function walk(dir, files = []) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (entry.isDirectory()) {
      if (!skipDirs.has(entry.name)) walk(path.join(dir, entry.name), files);
      continue;
    }
    if (includeExt.has(path.extname(entry.name).toLowerCase())) {
      files.push(path.join(dir, entry.name));
    }
  }
  return files;
}

function rootAssetPath(projectRoot, value) {
  const trimmed = value.trim();
  if (!trimmed.startsWith("/") || trimmed.startsWith("//")) return null;
  const pathOnly = trimmed.split(/[?#]/, 1)[0]?.replace(/^\/+/, "").replace(/\\/g, "/") ?? "";
  if (!pathOnly) return null;

  let decodedPath = pathOnly;
  try {
    decodedPath = decodeURIComponent(pathOnly);
  } catch {
    // Use the encoded path below.
  }

  const parts = decodedPath.split("/");
  if (parts.some((part) => part.trim() === "..")) return null;
  const first = parts[0]?.toLowerCase();
  if (!first || hostRootPrefixes.has(first)) return null;
  const basename = parts.at(-1) ?? "";
  const looksLikeAsset = projectAssetPrefixes.has(first) || /\.[a-z0-9][a-z0-9_-]{0,15}$/i.test(basename);
  if (!looksLikeAsset) return null;
  if (!fs.existsSync(path.join(projectRoot, decodedPath))) return null;
  return decodedPath;
}

function suffixFor(value) {
  return value.match(/^[^?#]*([?#][\s\S]*)$/)?.[1] ?? "";
}

function relativeRef(projectRoot, ownerFile, targetPath, suffix = "") {
  const fromDir = path.dirname(ownerFile);
  const target = path.join(projectRoot, targetPath);
  let rel = path.relative(fromDir, target).split(path.sep).join("/");
  if (!rel.startsWith(".")) rel = `./${rel}`;
  return `${rel}${suffix}`;
}

function rewriteRootRef(projectRoot, ownerFile, value) {
  const target = rootAssetPath(projectRoot, value);
  if (!target) return value;
  return relativeRef(projectRoot, ownerFile, target, suffixFor(value));
}

function rewriteSrcset(projectRoot, ownerFile, srcset) {
  return srcset
    .split(",")
    .map((candidate) => {
      const leading = candidate.match(/^\s*/)?.[0] ?? "";
      const trailing = candidate.match(/\s*$/)?.[0] ?? "";
      const body = candidate.trim();
      if (!body) return candidate;
      const [url, ...descriptors] = body.split(/\s+/);
      return `${leading}${[rewriteRootRef(projectRoot, ownerFile, url ?? ""), ...descriptors].join(" ")}${trailing}`;
    })
    .join(",");
}

function rewriteCssUrls(projectRoot, ownerFile, text) {
  return text.replace(
    /url\(\s*(['"]?)(\/(?!\/)[^'")]+)\1\s*\)/gi,
    (match, quote, value) => {
      const rewritten = rewriteRootRef(projectRoot, ownerFile, value);
      if (rewritten === value) return match;
      const q = quote || "";
      return `url(${q}${rewritten}${q})`;
    },
  );
}

function rewriteHtmlAttrs(projectRoot, ownerFile, text) {
  let next = text.replace(
    /(\s)(src|href|poster|data-src|data-tool-chip-src)\s*=\s*(['"])([\s\S]*?)\3/gi,
    (match, space, name, quote, value) => {
      const rewritten = rewriteRootRef(projectRoot, ownerFile, value);
      if (rewritten === value) return match;
      return `${space}${name}=${quote}${rewritten}${quote}`;
    },
  );
  next = next.replace(
    /(\s)srcset\s*=\s*(['"])([\s\S]*?)\2/gi,
    (match, space, quote, value) => {
      const rewritten = rewriteSrcset(projectRoot, ownerFile, value);
      if (rewritten === value) return match;
      return `${space}srcset=${quote}${rewritten}${quote}`;
    },
  );
  return next;
}

function rewriteFile(projectRoot, file) {
  const before = fs.readFileSync(file, "utf8");
  const ext = path.extname(file).toLowerCase();
  let after = rewriteCssUrls(projectRoot, file, before);
  if (ext === ".html" || ext === ".htm" || ext === ".svg") {
    after = rewriteHtmlAttrs(projectRoot, file, after);
  }
  if (after === before) return false;
  fs.writeFileSync(file, after);
  return true;
}

try {
  const args = parseArgs(process.argv.slice(2));
  if (args.help) {
    usage();
    process.exit(0);
  }

  const projectRoot = path.resolve(args.project);
  const files = walk(projectRoot);
  const changed = files.filter((file) => rewriteFile(projectRoot, file));
  for (const file of changed) {
    console.log(path.relative(projectRoot, file).split(path.sep).join("/"));
  }
  console.log(`od-preview-rewrite: ${changed.length} file(s) updated`);
} catch (error) {
  console.error(`od-preview-rewrite failed: ${error.message}`);
  process.exit(1);
}

````

<!-- ===== FILE: scripts/recon-site.mjs ===== -->
````mjs
#!/usr/bin/env node
import fs from "node:fs";
import path from "node:path";
import { loadPlaywright, launchChromium } from "./lib/playwright-loader.mjs";

function usage() {
  console.log(`Usage:
  node scripts/recon-site.mjs --url <url> --out <RECON dir> [--label original|clone] [--widths 1440,768,390] [--wait 1200] [--navigation-timeout 45000]

  --wait is an extra post-navigation stabilization delay. It does not change
  the navigation timeout; use --navigation-timeout for that.

Outputs:
  <out>/<label>-recon.json
  <out>/<label>-summary.md
  <out>/screenshots/<label>-<width>.png
`);
}

function parseArgs(argv) {
  const out = {
    url: "",
    outDir: "RECON",
    label: "site",
    widths: [1440, 768, 390],
    waitMs: 1200,
    navigationTimeoutMs: 45000,
  };
  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    if (arg === "--help" || arg === "-h") out.help = true;
    else if (arg === "--url") out.url = argv[++i] || "";
    else if (arg === "--out") out.outDir = argv[++i] || "";
    else if (arg === "--label") out.label = argv[++i] || "site";
    else if (arg === "--widths") out.widths = (argv[++i] || "").split(",").map((n) => Number(n.trim())).filter(Boolean);
    else if (arg === "--wait") out.waitMs = Number(argv[++i] || "1200");
    else if (arg === "--navigation-timeout") out.navigationTimeoutMs = Number(argv[++i] || "45000");
    else throw new Error(`Unexpected argument: ${arg}`);
  }
  return out;
}

function summarizeFlags(signals) {
  return Object.entries(signals.frameworks || {})
    .filter(([, value]) => value)
    .map(([key]) => key);
}

function writeSummary(file, data) {
  const first = data.captures[0]?.signals || {};
  const lines = [
    `# ${data.label} recon`,
    "",
    `- URL: ${data.url}`,
    `- Title: ${first.title || ""}`,
    `- Lang: ${first.lang || ""}`,
    `- Viewports: ${data.captures.map((c) => c.viewport.width).join(", ")}`,
    `- Framework signals: ${summarizeFlags(first).join(", ") || "none"}`,
    `- Canvas count: ${first.counts?.canvas ?? 0}`,
    `- Video count: ${first.counts?.video ?? 0}`,
    `- Image count: ${first.counts?.images ?? 0}`,
    `- Link count: ${first.counts?.links ?? 0}`,
    `- Console errors: ${data.console.errors.length}`,
    `- Page errors: ${data.console.pageErrors.length}`,
    `- Recovered navigation timeouts: ${(data.navigation || []).filter((entry) => entry.recovered).length}`,
    "",
    "## Palette (computed — 复刻必须照抄这些值，不许目测)",
    ...Object.entries(first.palette || {})
      .filter(([key, value]) => key !== "buttons" && value)
      .map(([key, value]) => `- ${key}: bg ${value.backgroundColor} · text ${value.color} · font ${value.fontFamily?.split(",")[0] || ""}`),
    "",
    "## Fonts (真字体自托管，禁止系统字体近似)",
    `- Loaded families: ${(first.fonts || []).join(", ") || "none"}`,
    `- @font-face rules: ${(first.fontFaces || []).length}; font files: ${(first.resources?.fonts || []).length}`,
    "",
    "## Assets",
    `- Image resources loaded: ${(first.resources?.images || []).length} (run asset-harvest to download ALL of them)`,
    "",
    "## Screenshots",
    ...data.captures.map((c) => `- ${c.viewport.width}: ${c.screenshot}`),
    "",
  ];
  fs.writeFileSync(file, lines.join("\n"));
}

async function navigateForRecon(page, url, timeout) {
  try {
    await page.goto(url, { waitUntil: "domcontentloaded", timeout });
    return { recovered: false, url: page.url(), readyState: await page.evaluate(() => document.readyState) };
  } catch (error) {
    const state = await page.evaluate(() => ({
      url: location.href,
      readyState: document.readyState,
      hasDocument: Boolean(document.documentElement),
      hasBody: Boolean(document.body),
      bodyTextChars: (document.body?.innerText || "").length,
    })).catch(() => null);
    const isTimeout = error?.name === "TimeoutError" || /timeout/i.test(error?.message || "");
    const hasUsableDocument = state?.hasDocument
      && state.hasBody
      && /^https?:/i.test(state.url);
    if (!isTimeout || !hasUsableDocument) throw error;
    return {
      recovered: true,
      url: state.url,
      readyState: state.readyState,
      bodyTextChars: state.bodyTextChars,
      warning: `Navigation did not reach DOMContentLoaded within ${timeout}ms; continuing with the committed document.`,
    };
  }
}

async function collectSignals(page) {
  return page.evaluate(() => {
    const bySelector = (selector) => Array.from(document.querySelectorAll(selector));
    const text = (node) => (node?.textContent || "").trim().replace(/\s+/g, " ");
    const win = window;
    const scripts = bySelector("script[src]").map((s) => s.src);
    const stylesheets = bySelector("link[rel='stylesheet']").map((s) => s.href);
    const headings = bySelector("h1,h2,h3").slice(0, 60).map((h) => ({
      tag: h.tagName.toLowerCase(),
      text: text(h).slice(0, 160),
    }));
    const sections = bySelector("header,nav,main,section,article,aside,footer").slice(0, 80).map((node) => {
      const rect = node.getBoundingClientRect();
      const style = getComputedStyle(node);
      return {
        tag: node.tagName.toLowerCase(),
        id: node.id || "",
        className: String(node.className || "").slice(0, 160),
        text: text(node).slice(0, 240),
        rect: {
          x: Math.round(rect.x),
          y: Math.round(rect.y),
          width: Math.round(rect.width),
          height: Math.round(rect.height),
        },
        style: {
          display: style.display,
          position: style.position,
          backgroundColor: style.backgroundColor,
          color: style.color,
          fontFamily: style.fontFamily,
          fontSize: style.fontSize,
        },
      };
    });
    const cssVariables = Array.from(document.styleSheets).flatMap((sheet) => {
      try {
        return Array.from(sheet.cssRules || []);
      } catch {
        return [];
      }
    }).flatMap((rule) => {
      const style = rule.style;
      if (!style) return [];
      return Array.from(style)
        .filter((name) => name.startsWith("--"))
        .map((name) => [name, style.getPropertyValue(name).trim()]);
    }).slice(0, 200);
    const images = bySelector("img").slice(0, 120).map((img) => ({
      src: img.currentSrc || img.src || img.getAttribute("data-src") || "",
      srcset: img.srcset || img.getAttribute("data-srcset") || "",
      alt: img.alt || "",
      width: img.naturalWidth || img.width || 0,
      height: img.naturalHeight || img.height || 0,
    }));
    // @font-face 规则原文 + 解析出的 src url——复刻必须自托管这些真字体，
    // 禁止用系统字体近似(见 SKILL.md 保真门槛)。
    const fontFaces = Array.from(document.styleSheets).flatMap((sheet) => {
      let rules;
      try {
        rules = Array.from(sheet.cssRules || []);
      } catch {
        return [];
      }
      return rules
        .filter((rule) => rule instanceof CSSFontFaceRule)
        .map((rule) => {
          const src = rule.style.getPropertyValue("src");
          const srcUrls = Array.from(src.matchAll(/url\(\s*['"]?([^'")]+)['"]?\s*\)/gi)).map((m) => m[1]);
          return {
            family: rule.style.getPropertyValue("font-family").replace(/['"]/g, "").trim(),
            weight: rule.style.getPropertyValue("font-weight") || "",
            style: rule.style.getPropertyValue("font-style") || "",
            srcUrls,
            cssText: rule.cssText,
            sheetHref: sheet.href || location.href,
          };
        });
    }).slice(0, 60);
    // 页面实际加载过的资源 URL(懒加载图、CSS 背景图、字体二进制都在这)——
    // 这是"真实用到的资产"全集，asset-harvest 以此下载。
    const resourceEntries = performance.getEntriesByType("resource");
    const resources = { images: [], fonts: [], media: [] };
    for (const entry of resourceEntries) {
      const url = entry.name;
      if (/\.(woff2?|ttf|otf|eot)(?:$|[?#])/i.test(url)) resources.fonts.push(url);
      else if (entry.initiatorType === "img" || /\.(png|jpe?g|gif|webp|avif|svg|ico)(?:$|[?#])/i.test(url)) resources.images.push(url);
      else if (/\.(mp4|webm|m4v|mp3|ogg)(?:$|[?#])/i.test(url)) resources.media.push(url);
    }
    resources.images = Array.from(new Set(resources.images)).slice(0, 300);
    resources.fonts = Array.from(new Set(resources.fonts)).slice(0, 60);
    resources.media = Array.from(new Set(resources.media)).slice(0, 40);
    // 关键区块的精确取色——复刻时颜色必须照抄这里的值，不许目测。
    const paletteOf = (node) => {
      if (!node) return null;
      const style = getComputedStyle(node);
      return {
        backgroundColor: style.backgroundColor,
        color: style.color,
        borderColor: style.borderTopColor,
        fontFamily: style.fontFamily,
        backgroundImage: style.backgroundImage !== "none" ? style.backgroundImage.slice(0, 300) : "",
      };
    };
    const palette = {
      body: paletteOf(document.body),
      header: paletteOf(document.querySelector("header")),
      nav: paletteOf(document.querySelector("nav")),
      main: paletteOf(document.querySelector("main")),
      footer: paletteOf(document.querySelector("footer")),
      buttons: bySelector("button,[role='button'],a[class*='btn' i],a[class*='button' i]")
        .slice(0, 12)
        .map((node) => ({ text: text(node).slice(0, 40), ...paletteOf(node) })),
    };
    // 滚动体感信号——复刻必须还原原站的滚动手感(平滑滚动库/snap/sticky)，
    // 配合 frameworks 里的 lenis/gsap 检测一起读。
    const motion = (() => {
      let scrollSnapRules = 0;
      let smoothScrollRules = 0;
      for (const sheet of Array.from(document.styleSheets)) {
        let rules;
        try {
          rules = Array.from(sheet.cssRules || []);
        } catch {
          continue;
        }
        for (const rule of rules) {
          const ruleText = rule.cssText || "";
          if (ruleText.includes("scroll-snap")) scrollSnapRules += 1;
          if (ruleText.includes("scroll-behavior") && ruleText.includes("smooth")) smoothScrollRules += 1;
        }
      }
      const stickyOrFixedCount = bySelector("header,nav,aside,section,div")
        .slice(0, 500)
        .filter((el) => {
          const position = getComputedStyle(el).position;
          return position === "sticky" || position === "fixed";
        }).length;
      return {
        htmlScrollBehavior: getComputedStyle(document.documentElement).scrollBehavior,
        scrollSnapRules,
        smoothScrollRules,
        stickyOrFixedCount,
      };
    })();
    // :root 自定义属性的"计算后"值(声明值可能是 var() 链)。
    const rootStyle = getComputedStyle(document.documentElement);
    const rootVariables = cssVariables
      .map(([name]) => [name, rootStyle.getPropertyValue(name).trim()])
      .filter(([, value]) => value)
      .slice(0, 200);
    const canvases = bySelector("canvas").map((canvas) => ({
      width: canvas.width,
      height: canvas.height,
      cssWidth: canvas.getBoundingClientRect().width,
      cssHeight: canvas.getBoundingClientRect().height,
    }));
    return {
      href: location.href,
      title: document.title,
      lang: document.documentElement.lang || "",
      bodyTextChars: (document.body?.innerText || "").length,
      scrollHeight: document.documentElement.scrollHeight,
      viewport: {
        width: window.innerWidth,
        height: window.innerHeight,
      },
      h1: bySelector("h1").map((h) => text(h)).filter(Boolean).slice(0, 10),
      headings,
      metaDescription: document.querySelector("meta[name='description']")?.content || "",
      counts: {
        links: bySelector("a[href]").length,
        images: bySelector("img").length,
        video: bySelector("video").length,
        canvas: bySelector("canvas").length,
        sections: sections.length,
        forms: bySelector("form").length,
        buttons: bySelector("button").length,
        inputs: bySelector("input,textarea,select").length,
        interactive: bySelector("a[href],button,input,textarea,select,summary,[role='button'],[tabindex]").length,
        scripts: scripts.length,
        stylesheets: stylesheets.length,
      },
      frameworks: {
        react: Boolean(win.__REACT_DEVTOOLS_GLOBAL_HOOK__) || Boolean(document.querySelector("#__next,[data-reactroot],[data-reactid]")),
        next: Boolean(document.querySelector("#__next")) || scripts.some((src) => src.includes("/_next/")),
        vue: Boolean(win.__VUE__) || Boolean(document.querySelector("[data-v-app]")),
        nuxt: Boolean(win.__NUXT__) || scripts.some((src) => src.includes("/_nuxt/")),
        svelte: Boolean(document.querySelector("[data-svelte-h]")),
        astro: Boolean(document.querySelector("[data-astro-cid]")) || scripts.some((src) => src.includes("astro")),
        three: Boolean(win.THREE) || scripts.some((src) => /three(\.module)?(\.min)?\.js/i.test(src)),
        gsap: Boolean(win.gsap) || scripts.some((src) => src.toLowerCase().includes("gsap")),
        lenis: Boolean(win.Lenis) || scripts.some((src) => src.toLowerCase().includes("lenis")),
      },
      scripts: scripts.slice(0, 120),
      stylesheets: stylesheets.slice(0, 80),
      sections,
      cssVariables,
      rootVariables,
      palette,
      motion,
      fonts: Array.from(document.fonts || []).map((font) => font.family).filter(Boolean).slice(0, 40),
      fontFaces,
      resources,
      images,
      canvases,
    };
  });
}

// 全程滚动一遍再采集: 懒加载图(loading=lazy / IntersectionObserver)只有滚到才
// 发请求; 不滚的话 images/resources 只覆盖首屏, 复刻必然缺图。
async function scrollThroughPage(page, stepPx = 700) {
  const total = await page.evaluate(() => document.documentElement.scrollHeight);
  for (let y = 0; y <= total; y += stepPx) {
    await page.evaluate((yy) => window.scrollTo(0, yy), y);
    await page.waitForTimeout(150);
  }
  await page.waitForTimeout(1000);
  await page.evaluate(() => window.scrollTo(0, 0));
  await page.waitForTimeout(600);
}

let browser = null;
try {
  const args = parseArgs(process.argv.slice(2));
  if (args.help || !args.url) {
    usage();
    process.exit(args.help ? 0 : 1);
  }

  const { chromium } = loadPlaywright();
  const outDir = path.resolve(args.outDir);
  const screenshotsDir = path.join(outDir, "screenshots");
  fs.mkdirSync(screenshotsDir, { recursive: true });

  const consoleState = { errors: [], warnings: [], pageErrors: [] };
  browser = await launchChromium(chromium);
  const captures = [];
  const navigation = [];

  for (const width of args.widths) {
    const page = await browser.newPage({ viewport: { width, height: 900 }, deviceScaleFactor: 1 });
    page.on("console", (message) => {
      const entry = { type: message.type(), text: message.text(), viewport: width };
      if (message.type() === "error") consoleState.errors.push(entry);
      if (message.type() === "warning") consoleState.warnings.push(entry);
    });
    page.on("pageerror", (error) => {
      consoleState.pageErrors.push({ message: error.message, viewport: width });
    });

    const navigationState = await navigateForRecon(page, args.url, args.navigationTimeoutMs);
    navigation.push({ viewport: width, ...navigationState });
    if (navigationState.warning) console.warn(`recon-site warning (${width}px): ${navigationState.warning}`);
    await page.waitForLoadState("networkidle", { timeout: 8000 }).catch(() => {});
    if (args.waitMs > 0) await page.waitForTimeout(args.waitMs);
    await scrollThroughPage(page);

    const signals = await collectSignals(page);
    const screenshotName = `${args.label}-${width}.png`;
    const screenshotPath = path.join(screenshotsDir, screenshotName);
    await page.screenshot({ path: screenshotPath, fullPage: true });
    captures.push({
      viewport: { width, height: 900 },
      screenshot: path.relative(outDir, screenshotPath),
      signals,
    });
    await page.close();
  }

  await browser.close();
  browser = null;

  const result = {
    label: args.label,
    url: args.url,
    capturedAt: new Date().toISOString(),
    console: consoleState,
    navigation,
    captures,
  };
  const jsonFile = path.join(outDir, `${args.label}-recon.json`);
  fs.writeFileSync(jsonFile, `${JSON.stringify(result, null, 2)}\n`);
  writeSummary(path.join(outDir, `${args.label}-summary.md`), result);
  console.log(jsonFile);
} catch (error) {
  console.error(`recon-site failed: ${error.message}`);
  process.exitCode = 1;
} finally {
  await browser?.close().catch(() => {});
}

````

<!-- ===== FILE: scripts/route-crawl.mjs ===== -->
````mjs
#!/usr/bin/env node
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { loadPlaywright, launchChromium } from "./lib/playwright-loader.mjs";

function usage() {
  console.log(`Usage:
  node scripts/route-crawl.mjs --url <url> --out RECON/routes [--label original] [--max-pages 25] [--max-depth 2] [--width 1440] [--wait 800] [--allow-subdomains]

Crawls same-site internal links, captures a screenshot per route, and writes a route map.
`);
}

function parseArgs(argv) {
  const out = {
    url: "",
    outDir: "RECON/routes",
    label: "site",
    maxPages: 25,
    maxDepth: 2,
    width: 1440,
    waitMs: 800,
    allowSubdomains: false,
  };
  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    if (arg === "--help" || arg === "-h") out.help = true;
    else if (arg === "--url") out.url = argv[++i] || "";
    else if (arg === "--out") out.outDir = argv[++i] || "RECON/routes";
    else if (arg === "--label") out.label = argv[++i] || "site";
    else if (arg === "--max-pages") out.maxPages = Number(argv[++i] || "25");
    else if (arg === "--max-depth") out.maxDepth = Number(argv[++i] || "2");
    else if (arg === "--width") out.width = Number(argv[++i] || "1440");
    else if (arg === "--wait") out.waitMs = Number(argv[++i] || "800");
    else if (arg === "--allow-subdomains") out.allowSubdomains = true;
    else throw new Error(`Unexpected argument: ${arg}`);
  }
  return out;
}

function normalizeUrl(rawUrl, baseUrl) {
  try {
    const url = new URL(rawUrl, baseUrl);
    if (!["http:", "https:"].includes(url.protocol)) return "";
    url.hash = "";
    url.searchParams.sort();
    return url.toString().replace(/\/$/, "");
  } catch {
    return "";
  }
}

function sameSite(candidate, origin, allowSubdomains) {
  const url = new URL(candidate);
  const root = new URL(origin);
  if (url.origin === root.origin) return true;
  return allowSubdomains && url.hostname.endsWith(`.${root.hostname}`);
}

function routeFileName(url) {
  const parsed = new URL(url);
  const clean = `${parsed.hostname}${parsed.pathname}`.replace(/[^a-z0-9._-]+/gi, "-").replace(/^-+|-+$/g, "").slice(0, 90) || "route";
  const hash = crypto.createHash("sha1").update(url).digest("hex").slice(0, 8);
  return `${clean}-${hash}.png`;
}

function summarizeMarkdown(result) {
  const lines = [
    `# ${result.label} route map`,
    "",
    `- URL: ${result.url}`,
    `- Captured routes: ${result.routes.length}`,
    `- Max depth: ${result.maxDepth}`,
    `- Max pages: ${result.maxPages}`,
    "",
    "## Routes",
    "| Depth | Status | Path | Title | H1 | Links | Screenshot |",
    "|---:|---:|---|---|---|---:|---|",
  ];
  for (const route of result.routes) {
    const url = new URL(route.url);
    const pathLabel = `${url.pathname}${url.search}`;
    lines.push(`| ${route.depth} | ${route.status || ""} | ${pathLabel || "/"} | ${route.title.replaceAll("|", "\\|")} | ${route.h1.join(" / ").replaceAll("|", "\\|")} | ${route.linkCount} | ${route.screenshot} |`);
  }
  if (result.skipped.length) {
    lines.push("");
    lines.push("## Skipped / Failed");
    for (const item of result.skipped.slice(0, 80)) {
      lines.push(`- ${item.url} · ${item.reason}`);
    }
  }
  return `${lines.join("\n")}\n`;
}

async function collectPage(page) {
  return page.evaluate(() => {
    const text = (node) => (node?.textContent || "").trim().replace(/\s+/g, " ");
    const links = Array.from(document.querySelectorAll("a[href]")).map((a) => ({
      href: a.href,
      text: text(a).slice(0, 120),
    }));
    const headings = Array.from(document.querySelectorAll("h1,h2,h3")).slice(0, 40).map((node) => ({
      tag: node.tagName.toLowerCase(),
      text: text(node).slice(0, 160),
    }));
    return {
      href: location.href,
      title: document.title || "",
      lang: document.documentElement.lang || "",
      metaDescription: document.querySelector("meta[name='description']")?.content || "",
      h1: Array.from(document.querySelectorAll("h1")).map((node) => text(node)).filter(Boolean).slice(0, 8),
      headings,
      scrollHeight: document.documentElement.scrollHeight,
      counts: {
        links: links.length,
        images: document.images.length,
        canvas: document.querySelectorAll("canvas").length,
        forms: document.forms.length,
        buttons: document.querySelectorAll("button,[role='button']").length,
      },
      links,
    };
  });
}

try {
  const args = parseArgs(process.argv.slice(2));
  if (args.help || !args.url) {
    usage();
    process.exit(args.help ? 0 : 1);
  }

  const startUrl = normalizeUrl(args.url, args.url);
  if (!startUrl) throw new Error(`Invalid URL: ${args.url}`);

  const outDir = path.resolve(args.outDir);
  const screenshotsDir = path.join(outDir, "screenshots");
  fs.mkdirSync(screenshotsDir, { recursive: true });

  const { chromium } = loadPlaywright();
  const browser = await launchChromium(chromium);
  const page = await browser.newPage({ viewport: { width: args.width, height: 900 }, deviceScaleFactor: 1 });

  const queue = [{ url: startUrl, depth: 0, from: "" }];
  const seen = new Set();
  const routes = [];
  const skipped = [];

  while (queue.length && routes.length < args.maxPages) {
    const current = queue.shift();
    if (!current || seen.has(current.url)) continue;
    seen.add(current.url);

    if (current.depth > args.maxDepth) {
      skipped.push({ url: current.url, reason: `depth>${args.maxDepth}` });
      continue;
    }
    if (!sameSite(current.url, startUrl, args.allowSubdomains)) {
      skipped.push({ url: current.url, reason: "external" });
      continue;
    }

    const consoleErrors = [];
    const onConsole = (message) => {
      if (message.type() === "error") consoleErrors.push(message.text());
    };
    page.on("console", onConsole);

    try {
      const response = await page.goto(current.url, { waitUntil: "domcontentloaded", timeout: 45000 });
      await page.waitForLoadState("networkidle", { timeout: 6000 }).catch(() => {});
      if (args.waitMs > 0) await page.waitForTimeout(args.waitMs);
      const data = await collectPage(page);
      const screenshotName = routeFileName(current.url);
      const screenshotPath = path.join(screenshotsDir, screenshotName);
      await page.screenshot({ path: screenshotPath, fullPage: true });

      routes.push({
        url: current.url,
        from: current.from,
        depth: current.depth,
        status: response?.status() || 0,
        title: data.title,
        lang: data.lang,
        metaDescription: data.metaDescription,
        h1: data.h1,
        headings: data.headings,
        counts: data.counts,
        linkCount: data.links.length,
        screenshot: path.relative(outDir, screenshotPath),
        consoleErrors,
      });

      for (const link of data.links) {
        const nextUrl = normalizeUrl(link.href, current.url);
        if (!nextUrl || seen.has(nextUrl)) continue;
        if (!sameSite(nextUrl, startUrl, args.allowSubdomains)) continue;
        queue.push({ url: nextUrl, depth: current.depth + 1, from: current.url });
      }
    } catch (error) {
      skipped.push({ url: current.url, reason: error.message });
    } finally {
      page.off("console", onConsole);
    }
  }

  await browser.close();

  const result = {
    label: args.label,
    url: startUrl,
    capturedAt: new Date().toISOString(),
    maxPages: args.maxPages,
    maxDepth: args.maxDepth,
    allowSubdomains: args.allowSubdomains,
    routes,
    skipped,
  };
  const jsonFile = path.join(outDir, `${args.label}-route-map.json`);
  const mdFile = path.join(outDir, `${args.label}-route-map.md`);
  fs.writeFileSync(jsonFile, `${JSON.stringify(result, null, 2)}\n`);
  fs.writeFileSync(mdFile, summarizeMarkdown(result));
  console.log(jsonFile);
} catch (error) {
  console.error(`route-crawl failed: ${error.message}`);
  process.exit(1);
}

````

<!-- ===== FILE: scripts/sourcemap-hunt.mjs ===== -->
````mjs
#!/usr/bin/env node
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";

function usage() {
  console.log(`Usage:
  node scripts/sourcemap-hunt.mjs --recon original-recon.json --out RECON/sourcemaps [--all-external]

Finds sourceMappingURL hints in discovered JavaScript bundles and tries to download source maps.
`);
}

function parseArgs(argv) {
  const out = { recon: "", outDir: "RECON/sourcemaps", allExternal: false };
  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    if (arg === "--help" || arg === "-h") out.help = true;
    else if (arg === "--recon") out.recon = argv[++i] || "";
    else if (arg === "--out") out.outDir = argv[++i] || "RECON/sourcemaps";
    else if (arg === "--all-external") out.allExternal = true;
    else throw new Error(`Unexpected argument: ${arg}`);
  }
  return out;
}

function collectScripts(recon) {
  const scripts = new Set();
  for (const capture of recon.captures || []) {
    for (const script of capture.signals?.scripts || []) {
      if (/^https?:\/\//i.test(script)) scripts.add(script);
    }
  }
  return Array.from(scripts);
}

function fileNameFor(url, suffix = "") {
  const parsed = new URL(url);
  const base = path.basename(parsed.pathname).replace(/[^a-z0-9._-]+/gi, "-").slice(0, 90) || "bundle.js";
  const hash = crypto.createHash("sha1").update(url).digest("hex").slice(0, 10);
  return `${base}-${hash}${suffix}`;
}

function resolveMapUrl(scriptUrl, mapHint) {
  if (!mapHint) return `${scriptUrl}.map`;
  if (mapHint.startsWith("data:")) return "";
  return new URL(mapHint, scriptUrl).toString();
}

async function fetchText(url) {
  const response = await fetch(url, {
    headers: {
      "user-agent": "web-clone-skill/1.0 sourcemap-hunt",
      "accept": "*/*",
    },
  });
  if (!response.ok) throw new Error(`${response.status} ${response.statusText}`);
  return response.text();
}

try {
  const args = parseArgs(process.argv.slice(2));
  if (args.help || !args.recon) {
    usage();
    process.exit(args.help ? 0 : 1);
  }

  const recon = JSON.parse(fs.readFileSync(args.recon, "utf8"));
  const originHost = recon.url ? new URL(recon.url).hostname : "";
  const scripts = collectScripts(recon).filter((script) => args.allExternal || new URL(script).hostname === originHost);
  const outDir = path.resolve(args.outDir);
  fs.mkdirSync(outDir, { recursive: true });

  const results = [];
  for (const scriptUrl of scripts) {
    const entry = { scriptUrl, status: "unknown", mapUrl: "", mapFile: "", error: "" };
    try {
      const js = await fetchText(scriptUrl);
      const hint = js.match(/[#@]\s*sourceMappingURL=([^\s*]+)/)?.[1] || "";
      entry.mapUrl = resolveMapUrl(scriptUrl, hint);
      if (!entry.mapUrl) {
        entry.status = "inline-or-data-map";
        results.push(entry);
        continue;
      }
      const mapText = await fetchText(entry.mapUrl);
      const mapFile = path.join(outDir, fileNameFor(entry.mapUrl, ".map"));
      fs.writeFileSync(mapFile, mapText);
      entry.mapFile = mapFile;
      entry.status = "ok";
    } catch (error) {
      entry.status = "error";
      entry.error = error.message;
    }
    results.push(entry);
  }

  const manifest = {
    source: args.recon,
    url: recon.url,
    allExternal: args.allExternal,
    scriptCount: scripts.length,
    mapCount: results.filter((item) => item.status === "ok").length,
    results,
  };
  const manifestFile = path.join(outDir, "sourcemap-manifest.json");
  fs.writeFileSync(manifestFile, `${JSON.stringify(manifest, null, 2)}\n`);
  console.log(manifestFile);
} catch (error) {
  console.error(`sourcemap-hunt failed: ${error.message}`);
  process.exit(1);
}

````

<!-- ===== FILE: scripts/visual-diff.mjs ===== -->
````mjs
#!/usr/bin/env node
import fs from "node:fs";
import path from "node:path";
import { loadPlaywright, launchChromium } from "./lib/playwright-loader.mjs";

function usage() {
  console.log(`Usage:
  node scripts/visual-diff.mjs --original <png> --clone <png> --out visual-diff.json [--diff visual-diff.png] [--threshold 0.08]

Compares screenshots in a real browser canvas and outputs numeric visual-diff metrics.
`);
}

function parseArgs(argv) {
  const out = { original: "", clone: "", out: "visual-diff.json", diff: "", threshold: 0.08 };
  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    if (arg === "--help" || arg === "-h") out.help = true;
    else if (arg === "--original") out.original = argv[++i] || "";
    else if (arg === "--clone") out.clone = argv[++i] || "";
    else if (arg === "--out") out.out = argv[++i] || "visual-diff.json";
    else if (arg === "--diff") out.diff = argv[++i] || "";
    else if (arg === "--threshold") out.threshold = Number(argv[++i] || "0.08");
    else throw new Error(`Unexpected argument: ${arg}`);
  }
  return out;
}

function imageDataUrl(file) {
  const ext = path.extname(file).slice(1).toLowerCase() || "png";
  const mime = ext === "jpg" || ext === "jpeg" ? "image/jpeg" : "image/png";
  return `data:${mime};base64,${fs.readFileSync(file).toString("base64")}`;
}

function scoreFromDiff(diffRatio, meanAbsDiff) {
  if (diffRatio <= 0.01 && meanAbsDiff <= 0.01) return 5;
  if (diffRatio <= 0.04 && meanAbsDiff <= 0.025) return 4.5;
  if (diffRatio <= 0.08 && meanAbsDiff <= 0.05) return 4;
  if (diffRatio <= 0.16 && meanAbsDiff <= 0.08) return 3;
  if (diffRatio <= 0.3 && meanAbsDiff <= 0.14) return 2;
  return 1;
}

async function compareInBrowser(page, original, clone, threshold) {
  return page.evaluate(async ({ original, clone, threshold }) => {
    const loadImage = (src) => new Promise((resolve, reject) => {
      const image = new Image();
      image.onload = () => resolve(image);
      image.onerror = () => reject(new Error(`Failed to load image: ${src.slice(0, 80)}`));
      image.src = src;
    });

    const [left, right] = await Promise.all([loadImage(original), loadImage(clone)]);
    const width = Math.max(left.naturalWidth, right.naturalWidth);
    const height = Math.max(left.naturalHeight, right.naturalHeight);

    const canvasA = document.createElement("canvas");
    const canvasB = document.createElement("canvas");
    const canvasD = document.createElement("canvas");
    for (const canvas of [canvasA, canvasB, canvasD]) {
      canvas.width = width;
      canvas.height = height;
    }

    const ctxA = canvasA.getContext("2d");
    const ctxB = canvasB.getContext("2d");
    const ctxD = canvasD.getContext("2d");
    ctxA.fillStyle = "white";
    ctxB.fillStyle = "white";
    ctxA.fillRect(0, 0, width, height);
    ctxB.fillRect(0, 0, width, height);
    ctxA.drawImage(left, 0, 0);
    ctxB.drawImage(right, 0, 0);

    const a = ctxA.getImageData(0, 0, width, height);
    const b = ctxB.getImageData(0, 0, width, height);
    const d = ctxD.createImageData(width, height);
    let changed = 0;
    let sumAbs = 0;
    let sumSq = 0;

    for (let i = 0; i < a.data.length; i += 4) {
      const dr = Math.abs(a.data[i] - b.data[i]);
      const dg = Math.abs(a.data[i + 1] - b.data[i + 1]);
      const db = Math.abs(a.data[i + 2] - b.data[i + 2]);
      const da = Math.abs(a.data[i + 3] - b.data[i + 3]);
      const delta = (dr + dg + db + da) / 1020;
      sumAbs += delta;
      sumSq += delta * delta;
      if (delta > threshold) changed += 1;

      if (delta > threshold) {
        d.data[i] = 255;
        d.data[i + 1] = Math.max(0, 80 - delta * 80);
        d.data[i + 2] = Math.max(0, 80 - delta * 80);
        d.data[i + 3] = 255;
      } else {
        d.data[i] = Math.round(a.data[i] * 0.25 + 245 * 0.75);
        d.data[i + 1] = Math.round(a.data[i + 1] * 0.25 + 245 * 0.75);
        d.data[i + 2] = Math.round(a.data[i + 2] * 0.25 + 245 * 0.75);
        d.data[i + 3] = 255;
      }
    }

    ctxD.putImageData(d, 0, 0);
    const pixels = width * height;
    const diffPixelRatio = changed / pixels;
    const meanAbsDiff = sumAbs / pixels;
    const rmse = Math.sqrt(sumSq / pixels);

    return {
      original: { width: left.naturalWidth, height: left.naturalHeight },
      clone: { width: right.naturalWidth, height: right.naturalHeight },
      comparedCanvas: { width, height },
      threshold,
      changedPixels: changed,
      totalPixels: pixels,
      diffPixelRatio,
      meanAbsDiff,
      rmse,
      diffPngDataUrl: canvasD.toDataURL("image/png"),
    };
  }, { original, clone, threshold });
}

try {
  const args = parseArgs(process.argv.slice(2));
  if (args.help || !args.original || !args.clone) {
    usage();
    process.exit(args.help ? 0 : 1);
  }

  const { chromium } = loadPlaywright();
  const browser = await launchChromium(chromium);
  const page = await browser.newPage();
  const result = await compareInBrowser(page, imageDataUrl(args.original), imageDataUrl(args.clone), args.threshold);
  await browser.close();

  const diffDataUrl = result.diffPngDataUrl;
  delete result.diffPngDataUrl;
  result.visualScore = scoreFromDiff(result.diffPixelRatio, result.meanAbsDiff);
  result.files = {
    original: path.resolve(args.original),
    clone: path.resolve(args.clone),
    diff: args.diff ? path.resolve(args.diff) : "",
  };

  fs.mkdirSync(path.dirname(path.resolve(args.out)), { recursive: true });
  fs.writeFileSync(args.out, `${JSON.stringify(result, null, 2)}\n`);

  if (args.diff) {
    const base64 = diffDataUrl.replace(/^data:image\/png;base64,/, "");
    fs.mkdirSync(path.dirname(path.resolve(args.diff)), { recursive: true });
    fs.writeFileSync(args.diff, Buffer.from(base64, "base64"));
  }

  console.log(path.resolve(args.out));
} catch (error) {
  console.error(`visual-diff failed: ${error.message}`);
  process.exit(1);
}

````