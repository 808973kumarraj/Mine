---
name: frame-macos-notification
zh_name: "macOS 通知横幅"
en_name: "macOS Notification Banner"
emoji: "🔔"
description: "Realistic macOS notification banner with app icon, title, and body, suited to video overlays or product teasers."
zh_description: "拟真 macOS 通知 banner + app icon + 标题正文, 适合 video overlay / 产品发布预告"
en_description: "Realistic macOS notification banner with app icon, title, and body, suited to video overlays or product teasers."
category: card
scenario: video
aspect_hint: "1920×1080 视频或 480×120 横幅"
featured: 41
tags: ["macos", "notification", "banner", "overlay", "frame"]
example_id: sample-frame-macos-notification
example_name: "macOS 通知 · 新功能发布"
example_format: markdown
example_tagline: "Big Sur 磨砂玻璃 banner"
example_desc: "App icon + 标题 + 双行正文, 视频角落叠加用"
example_source_url: "https://hyperframes.heygen.com/catalog"
example_source_label: "hyperframes · macos-notification"
od:
  mode: video
  surface: video
  scenario: video
  upstream: "https://github.com/nexu-io/html-anything"
  preview:
    type: html
    entry: index.html
    reload: debounce-100
  design_system:
    requires: false
  example_prompt: "Use the macOS Notification Banner template to turn my content into a realistic macOS notification banner for a video overlay or product teaser. Preserve the template's visual signature, use real content and data, and avoid lorem ipsum or placeholder images."
  example_prompt_i18n:
    zh-CN: "用「macOS 通知横幅」模板把我的内容做成一段「拟真 macOS 通知 banner + app icon + 标题正文, 适合 video overlay / 产品发布预告」。保持模板的视觉签名，使用真实内容和数据，避免 lorem ipsum 和占位图片。"
---

【模板: macOS 通知横幅】
【意图】把一段公告 / 消息 / 提示渲染成 macOS Big Sur+ 风格的通知横幅, 适合视频角落叠加、产品发布预告、社媒图。Inspired by hyperframes macos-notification。

【画布】两种用法:
- 视频叠加 1920×1080, 通知放右上角, 周围透明。
- 单独 banner 480×120, 居中输出。

【横幅结构】
- 外框: 圆角 14px (macOS Big Sur 标准), 480×120 (或更长 480×180 含正文), 12-16px 内边距。
- 背景: **frosted glass** 效果 — `background: rgba(245,245,247,0.78)` + `backdrop-filter: blur(40px) saturate(180%)`; 暗色版 `rgba(28,28,30,0.78)`。
- 边框: 1px `rgba(0,0,0,0.06)` (light) / `rgba(255,255,255,0.08)` (dark); 顶部加 1px 亮 highlight `rgba(255,255,255,0.5)`。
- 阴影: `0 10px 40px rgba(0,0,0,0.18), 0 2px 6px rgba(0,0,0,0.08)`。

【内容】
- 左侧: **App icon** (44×44, 圆角 10px, CSS gradient + 1 个 emoji 或 monogram 字母, **不用外链图片**)。
- 中间:
  - 顶部 row: App 名 (SF Pro 13px, weight 600) + `now` 或具体时间 (12px, opacity 0.6) — 两端对齐。
  - 标题 (15px, weight 600, 1 行截断)。
  - 正文 (13px, weight 400, 1-2 行截断, line-height 1.35)。
- 右侧 (可选): action button "Open" 或 "Reply" (capsule, 浅灰底)。

【字体】
- 主: `SF Pro Text` → fallback `Inter` / `system-ui`; 中文用 `PingFang SC` / `Noto Sans SC`。

【可选附加】
- 多条通知堆叠: 第一条在前, 后面 2 条向后向下递缩 (scale 0.96 + opacity 0.6 + translateY)。
- 入场动效: 从屏幕外右侧滑入 `transform: translateX(110%)→0`, 200ms ease-out; 可被 `prefers-reduced-motion` 关闭。
- 右上角控制 chip "Clear" (hover 显示, opacity 默认 0)。

【设计细节】
- light mode 背景白磨砂, dark mode (推荐 video) 几乎黑磨砂。
- icon 不能用外链 emoji 图片, 用 unicode emoji 或 CSS 绘制几何。
- 必须用用户提供的内容; 标题 + 正文清晰来自用户输入。
- 单文件 HTML, 注意 `backdrop-filter` Safari 需要 `-webkit-` 前缀。


<!-- ===== FILE: example.html ===== -->
````html
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8" />
<title>macOS Notification · 转换完成</title>
<script src="https://cdn.tailwindcss.com"></script>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Noto+Sans+SC:wght@400;500;700&display=swap" rel="stylesheet" />
<style>
  body {
    font-family: 'Inter','Noto Sans SC','PingFang SC',system-ui,sans-serif;
    background:
      linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%),
      radial-gradient(circle at 80% 20%, rgba(255,200,150,0.3) 0%, transparent 50%);
    background-blend-mode: screen;
    min-height: 100vh;
  }
  .frost {
    background: rgba(28,28,30,0.78);
    -webkit-backdrop-filter: blur(40px) saturate(180%);
    backdrop-filter: blur(40px) saturate(180%);
    border: 1px solid rgba(255,255,255,0.08);
    box-shadow: 0 10px 40px rgba(0,0,0,0.5), 0 2px 6px rgba(0,0,0,0.2), inset 0 1px 0 rgba(255,255,255,0.08);
  }
  @keyframes slideIn { from { transform: translateX(120%); opacity:0 } to { transform: translateX(0); opacity:1 } }
  .notif-1 { animation: slideIn .4s ease-out; }
  .notif-2 { transform: translateY(-12px) scale(0.96); opacity: 0.7; }
  .notif-3 { transform: translateY(-24px) scale(0.92); opacity: 0.4; }
</style>
</head>
<body class="flex flex-col items-end justify-start gap-3 p-12 text-white">
  <!-- top stacked notifs -->
  <div class="frost rounded-2xl w-[420px] p-3 flex gap-3 items-center notif-3">
    <div class="w-11 h-11 rounded-[10px] flex items-center justify-center text-xl" style="background:linear-gradient(135deg,#1DB954,#0d7a35)">🎵</div>
    <div class="flex-1 min-w-0">
      <div class="flex items-center justify-between"><span class="text-[13px] font-semibold">Spotify</span><span class="text-[11px] opacity-60">2m ago</span></div>
      <div class="text-[12.5px] truncate opacity-80">Now Playing — Lo-Fi Essentials</div>
    </div>
  </div>
  <div class="frost rounded-2xl w-[420px] p-3 flex gap-3 items-center notif-2">
    <div class="w-11 h-11 rounded-[10px] flex items-center justify-center text-xl" style="background:linear-gradient(135deg,#0f0f12,#2a2a35)">⌘</div>
    <div class="flex-1 min-w-0">
      <div class="flex items-center justify-between"><span class="text-[13px] font-semibold">Cursor</span><span class="text-[11px] opacity-60">1m ago</span></div>
      <div class="text-[12.5px] truncate opacity-80">同步完成 · 8 个文件已上传</div>
    </div>
  </div>
  <!-- main, in-focus notif -->
  <div class="frost rounded-2xl w-[420px] p-3 flex gap-3 items-center notif-1">
    <div class="w-11 h-11 rounded-[10px] flex items-center justify-center text-xl shrink-0" style="background:linear-gradient(135deg,#ff7849,#d97757)">H</div>
    <div class="flex-1 min-w-0">
      <div class="flex items-center justify-between">
        <span class="text-[13px] font-semibold">HTML Anything</span>
        <span class="text-[11px] opacity-60">now</span>
      </div>
      <div class="text-[14px] font-semibold leading-tight mt-0.5">转换完成 · 杂志风网页 PPT</div>
      <div class="text-[12.5px] opacity-80 leading-snug mt-0.5">31.2 KB · 12 帧 · 已在右侧预览面板渲染。点击复制为公众号 / 推特格式。</div>
    </div>
    <button class="text-[11px] font-semibold px-2.5 py-1 rounded-full ml-1 shrink-0" style="background:rgba(255,255,255,0.12)">Open</button>
  </div>
</body>
</html>

````

<!-- ===== FILE: example.md ===== -->
````md
App: HTML Anything
Title: 转换完成
Body: 你的杂志风网页 PPT 已生成 · 31.2 KB · 视频中输出
Time: now

二级通知 (堆叠):
- Cursor · 同步完成 · 8 个文件已上传
- Spotify · 现在播放 Lo-Fi Essentials

````