---
name: oil-motion
description: "处理视频和序列帧，编译滚动、指针、拖动与状态驱动的网页动效；内含本地媒体处理脚本和运行时。新素材生成使用宿主工具。"
en_name: oil-motion
zh_name: "Oil Motion · 交互媒体动效"
zh_description: "处理视频和序列帧，编译滚动、指针、拖动与状态驱动的网页动效；内含本地媒体处理脚本和运行时。新素材生成使用宿主工具。"
triggers:
  - "oil-motion"
  - "动效"
  - "动画"
  - "motion"
  - "oil"
  - "滚动"
  - "拖动"
  - "交互媒体"
  - "序列帧"
license: MIT
od:
  mode: utility
  category: animation-motion
  upstream: https://github.com/oil-oil/oil-motion
  source-commit: 07e31f2265f80caa8f2c1df825d85ac24a46307c
---
## Open Design 宿主约定

这是当前任务中的功能技能。保留用户选定的任务类型、品牌、技术栈、当前阶段和交付格式；不要因为 @ 选择而改成视频项目。规划阶段只规划，实现阶段才写代码。检查、渲染和导出仅在宿主当前阶段允许且工具真实可用时执行；技能不能额外开启独立 Agent、强制审批或绕过宿主交付边界。

附属文件相对当前技能包根目录读取，按当前问题选读，不把全部参考文档粘入提示词。不读取其他 Agent 的全局配置。素材优先用用户已有文件；需要新图片、视频或音频时使用当前宿主实际提供且用户允许的工具。缺少生成、测量或导出能力时说明具体缺口，交付可验证部分，不声称完成未执行的步骤。遵循当前任务的输出路径，不覆盖输入或历史产物。


# Oil Motion

把用户的交互意图转换为可验收的动画素材、时间轴清单和网页运行时。AI 生成负责肢体、结构、材质、遮挡等语义变化；程序负责输入映射、播放控制、媒体处理和性能。

本适配包包含本地媒体处理脚本和网页控制器。运行 Python 脚本前检查 Python 3.10+、支持 `-fps_mode` 的 FFmpeg / ffprobe、Pillow、NumPy、PyYAML；缺少依赖时仅在任务隔离环境中按 `scripts/requirements.txt` 安装，不修改全局环境。纯本地处理不需要 API Key。

运行参考命令前，将 `OIL_MOTION` 设为本次实际加载的技能目录：

```bash
OIL_MOTION="<本次 SKILL.md 所在绝对目录>"
```

图片／视频生成交给宿主已有工具。此包不包含上游的生成服务、Keychain 或凭据配置页面；不要尝试调用它们。

## 四个唯一事实源

每项信息只保存在一个位置，其他文件引用它，不复制：

1. `source/concept-contract.yaml`：用户明确要求的对象、视觉、交互和连续性。
2. `source/motion-brief.yaml`：由合同派生的关键帧、片段和生产计划。
3. `build/timeline.json`：成片的实际帧率、段落边界、停帧和播放曲线。
4. `build/motion-budget.json`：交付格式与运行时控制器的自动选择结果。

## 主流程

### 1. 锁定用户意图

用户只有模糊目标时，先读 [references/concepts.md](references/concepts.md)，给出最多三个真正不同的方向；要求已经明确时直接写 Concept Contract。

需要外部案例启发时，按表达目的选读 [references/motion-patterns.md](references/motion-patterns.md)。先分清哪些变化属于素材本身、哪些只是容器编排或 UI 状态，只有前者进入生成流程。

```yaml
subject_count: <number>
subjects:
  - identity: <可验证的身份或外观锚点>
style: <用户原词>
motion_intent: <动作及视觉结果>
background_owner: video | page
scene: <背景属于视频时的场景、镜头和光线要求>
driver: scroll | pointer | drag | touch | orientation | audio | data | state | time
input_semantics: continuous | step | event
time_control: scrub | segment-play | autonomous
navigation: continuous | paged | none
clip_continuity: chain | independent
continuity: [<必须保持不变或连续的内容>]
aspect_ratio: 16:9 | 9:16 | 1:1 | 21:9 | custom
destination: <页面位置、最大显示尺寸和目标设备>
```

判断规则：

- `aspect_ratio` 取自 `destination` 的真实容器：横向全屏或 Hero 通常是 `16:9`，竖屏全屏是 `9:16`，卡片、头像等方形视窗是 `1:1`；不要未经确认就默认 `1:1`。容器比例与生成比例不一致时，在合同中写明裁切或补边策略。锁定后关键帧尺寸、视频画幅和编译输出都沿用同一比例，尺寸对照见 [references/prompting.md](references/prompting.md)。
- `scrub`：输入值与时间轴位置持续对应，输入停止时画面停在当前位置。
- `segment-play`：输入选择下一状态，片段随后按时间播放；反向输入应从当前画面撤回，不得换源硬切。
- `autonomous`：动画由时间推进，交互只负责开始、暂停或切换状态。
- `navigation` 只描述页面如何移动，不决定视频如何播放；分页页面也可以使用连续时间轴。
- 镜头、环境光、接触阴影、景深或背景连续性重要时使用 `background_owner: video`。只有主体必须透明复用在页面背景上时使用 `page`。
- 用户已说清的内容直接记录，不改写、不扩写。缺项会改变可生成性、可验收结果或生产路线时，必须先补齐。

### 2. 建立生产计划

Motion Brief 只保存派生计划，不复制合同字段：

```yaml
concept_contract: source/concept-contract.yaml
identity_bible: source/identity-bible.md | null
parameter_space: linear | circular | 2d | discrete
media_access: sequential | random
gesture_policy:
  unit: continuous | one-gesture-one-step
  inertia: coalesce | preserve
  while_active: retarget | queue | ignore
  boundary: clamp | loop
  programmatic_navigation: ignore | observe
storyboard: <有序视觉阶段>
keyframes: <K0…Kn>
clip_chain: <每段使用的相邻关键帧>
rest_state: <初始及失去输入时的状态>
loop: open | closed | none
anchor: fixed-body | center | bottom | free
scene_continuity: <仅背景属于视频时填写>
frame_policy: native | interpolate
target_fps: <由源素材和运行时需求决定>
quality_target: <分辨率、DPR 和文件预算>
pixel_dimensions: <宽x高，由合同的 aspect_ratio 与 DPR 派生>
reduced_motion: <静态替代状态>
```

`parameter_space` 描述素材时间轴，不描述页面布局：`linear` 是有起止的时间轴，`circular` 是闭环，`2d` 是二维采样，`discrete` 是互不连续的状态。不要把二维或无序状态压成一条线性视频。

`frame_policy` 与 `target_fps` 的取舍标准见 [references/optimization.md](references/optimization.md)。

整组位移、缩放、旋转、裁切和时间映射由程序完成；关节、结构、材质、接触和遮挡变化由生成模型完成。如果只移动整张图不能保持自然，就生成完整动作，不继续叠加 CSS 补丁。

### 3. 自动选择交付与运行时

在宿主允许运行工具的阶段，用 Brief 中的计划帧数、显示尺寸和参数空间运行 `motion_budget.py --strict`，显式传入合同中的 `background_owner` 和 `time_control`，保存 `build/motion-budget.json`。Pilot 按这个结果挂载到真实页面；之后帧数或尺寸变化就重新预算。脚本分别返回：

- `delivery.selected`：`baked-video | chroma-video | alpha-atlas`。
- `runtime.controller`：`frame-scrub | segment-playback | autonomous-playback`。

格式选择与播放方式是两件事，不得互相推断。命令和决策顺序见 [references/delivery-selection.md](references/delivery-selection.md)。按结果只读取一条媒体路线：

- `alpha-atlas`：[references/alpha-atlas.md](references/alpha-atlas.md)
- `chroma-video`：[references/chroma-video.md](references/chroma-video.md)
- `baked-video`：[references/baked-video.md](references/baked-video.md)

### 4. 制作关键帧

1. 有角色或需要身份一致时，先写 Identity Bible。
2. 生成并验收 `K0…Kn`；每段只承担一个主要语义变化，片段 `i` 使用 `Ki → Ki+1`。`clip_continuity: chain` 时，第 2 段起的首帧改用上一段验收后的实际尾帧，尾帧仍是计划关键帧。
3. 用宿主可用图片工具生成关键帧：按 `aspect_ratio` 传尺寸，并核对脚本报告的实际宽高比；尺寸至少覆盖最大 CSS 尺寸乘目标 DPR。真实产品、既定角色或上一张关键帧用 `--image` 作为参考输入，不只凭文字描述。
4. `background_owner: page` 请求透明输出，并实际检查 Alpha 通道；不得先生成色底再反向抠图。视频模型需要色键输入时，由 `composite_alpha_keyframe.py` 从透明源合成副本。`background_owner: video` 使用不透明场景输出，场景直接画进关键帧。
5. 命令、尺寸对照、提示词、首尾帧模式和提交方式见 [references/prompting.md](references/prompting.md)。宿主自带的图片工具同样能输出真实 Alpha 并接受参考图时也可以使用，验收标准不变。已有视频或序列帧时跳过生成，保留原始素材并从分析开始。

### 5. 先做 Pilot

批量生成前，只完成第一组关键帧、第一段视频，并按已选路线挂载到真实页面。按 [references/qa.md](references/qa.md) 通过 Pilot 硬门后才能量产；失败就修正上游，不在运行时掩盖。

### 6. 生成并逐段验收

按 [references/prompting.md](references/prompting.md) 生成母版，按 [references/qa.md](references/qa.md) 验收内容与连续帧链。`chain` 模式必须同时验证生成输入接力和相邻成片解码后的输出接缝；任一失败都停止后续生产。

### 7. 帧准备、清理与编译时间轴

按 [references/optimization.md](references/optimization.md) 执行 `frame_policy`（插帧出现重影或伪影时退回 `native` 或重新生成），再按已选媒体路线清理和编译。所有裁剪和拼接都要检查新产生的相邻帧；不得用一次远距离跳帧替代缓慢尾部变化。

编译后生成 `build/timeline.json`，字段语义只以 [references/runtime.md](references/runtime.md) 的时间轴规范为准。时间值必须由最终编译结果生成，不手工抄写。

### 8. 接入运行时

从 [assets/interactive-motion.ts](assets/interactive-motion.ts) 的对应控制器开始实现（`frame-scrub` 管理随动与最短环形距离，`segment-playback` 管理分段与反向）；分步手势使用 [assets/step-gesture.ts](assets/step-gesture.ts)。输入映射、分段播放、反向、取消、预加载和降级只以 [references/runtime.md](references/runtime.md) 为准。

### 9. 最终验收

按 [references/qa.md](references/qa.md) 在目标 CSS 尺寸、DPR、冷缓存、快速反向、移动端和资源失败条件下验收。页面导航、时间控制、媒体格式和连续性分别检查，不用一种检查代替另一种。

需要动画原理展示页时，读 [references/explainer.md](references/explainer.md) 并使用 `create_explainer.py`。

## 交付

保留 `source/`、`pilot/`、`build/`、`qa/` 和 `final/`。`final/` 只包含选中的主资源、静态降级和运行时入口；同时按宿主交付契约附上四个事实源及可复现的处理命令。


## 随包运行文件

下列文件随会话冻结，按需读取；所有 Python 内部依赖和运行时模板均在包内。

- `assets/chroma-video-renderer.ts`
- `assets/interactive-motion.ts`
- `assets/motion-explainer-template.html`
- `assets/motion-manifest.example.json`
- `assets/step-gesture.ts`
- `references/alpha-atlas.md`
- `references/baked-video.md`
- `references/chroma-video.md`
- `references/concepts.md`
- `references/delivery-selection.md`
- `references/explainer.md`
- `references/motion-patterns.md`
- `references/optimization.md`
- `references/prompting.md`
- `references/qa.md`
- `references/runtime.md`
- `scripts/chroma_key.py`
- `scripts/compile_scroll_video.py`
- `scripts/compose_travel_frames.py`
- `scripts/composite_alpha_keyframe.py`
- `scripts/create_explainer.py`
- `scripts/loop_cleanup.py`
- `scripts/media_edges.py`
- `scripts/motion_budget.py`
- `scripts/motion_pipeline.py`
- `scripts/optimize_motion.py`
- `scripts/production_gate.py`
- `scripts/requirements.txt`

## 许可随包保留

`references/license.md` 随会话包保留来源许可。复制参考代码到交付工程时保留上游署名及许可文本。


<!-- ===== FILE: LICENSE ===== -->
````LICENSE
MIT License

Copyright (c) 2026 Lin Zhihuang

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

````

<!-- ===== FILE: SOURCES.md ===== -->
````md
# Source and adaptation

- Upstream: https://github.com/oil-oil/oil-motion/tree/07e31f2265f80caa8f2c1df825d85ac24a46307c
- Commit: `07e31f2265f80caa8f2c1df825d85ac24a46307c`
- License: MIT; see LICENSE.

## Open Design changes

- Preserved all local media processing scripts, controller assets and relevant reference guides.
- Replaced provider-specific generation and credential setup with host tools; excluded upstream image/video clients and credential UI.
- requirements.txt contains only local processing dependencies; no credential dependency.
- Adapted entrypoint, prompting and Alpha QA wording; normalized trailing whitespace.
- Demo media, README art, standalone service tests and credential configuration are not shipped.
- Replaced removed FFmpeg `-vsync 0` with output-scoped `-fps_mode passthrough` in frame extraction; requires FFmpeg with fps_mode support, as does the upstream compiler; verified with FFmpeg 9.0.1.

````

<!-- ===== FILE: assets/chroma-video-renderer.ts ===== -->
````ts
export type ChromaKeyingParameters = {
  algorithm: "dominance-v2";
  mode: "green" | "magenta";
  keyColor: [number, number, number];
  similarity: number;
  smoothness: number;
  dominanceStart: number;
  dominanceEnd: number;
  spillStart: number;
  spillEnd: number;
  spill: number;
};

export type ChromaVideoRendererOptions = {
  video: HTMLVideoElement;
  canvas: HTMLCanvasElement;
  frameCount: number;
  fps: number;
  keying?: ChromaKeyingParameters;
  keyColor?: [number, number, number];
  similarity?: number;
  smoothness?: number;
  spill?: number;
  maxDpr?: number;
  onFrame?: (frame: number, seekMilliseconds: number) => void;
};

export type ChromaVideoRenderer = {
  render(frame: number): void;
  startLive(): void;
  stopLive(): void;
  resize(): void;
  destroy(): void;
};

const VERTEX_SHADER = `
attribute vec2 aPosition;
varying vec2 vTextureCoordinate;
uniform vec2 uUvScale;
uniform vec2 uUvOffset;

void main() {
  vec2 normalized = (aPosition + 1.0) * 0.5;
  vTextureCoordinate = normalized * uUvScale + uUvOffset;
  gl_Position = vec4(aPosition, 0.0, 1.0);
}
`;

const FRAGMENT_SHADER = `
precision mediump float;
varying vec2 vTextureCoordinate;
uniform sampler2D uTexture;
uniform vec3 uKeyColor;
uniform float uSimilarity;
uniform float uSmoothness;
uniform float uKeyMode;
uniform float uDominanceStart;
uniform float uDominanceEnd;
uniform float uSpillStart;
uniform float uSpillEnd;
uniform float uSpill;

vec2 chroma(vec3 color) {
  float luminance = dot(color, vec3(0.299, 0.587, 0.114));
  return vec2(color.b - luminance, color.r - luminance);
}

void main() {
  vec4 sampleColor = texture2D(uTexture, vTextureCoordinate);
  float distanceFromKey = distance(chroma(sampleColor.rgb), chroma(uKeyColor));
  float distanceAlpha = smoothstep(
    uSimilarity,
    uSimilarity + max(0.0001, uSmoothness),
    distanceFromKey
  );

  vec3 color = sampleColor.rgb;
  float greenDominance = color.g - max(color.r, color.b);
  float magentaDominance = min(color.r, color.b) - color.g;
  float keyDominance = mix(greenDominance, magentaDominance, uKeyMode);
  float dominanceMask = smoothstep(
    uDominanceStart,
    uDominanceEnd,
    keyDominance
  );
  float alpha = min(distanceAlpha, 1.0 - dominanceMask);
  float dominanceSpill = smoothstep(uSpillStart, uSpillEnd, keyDominance);
  float spillMask = clamp(
    max(dominanceSpill, (1.0 - alpha) * uSpill),
    0.0,
    1.0
  );
  if (uKeyMode < 0.5) {
    color.g = mix(color.g, max(color.r, color.b), spillMask);
  } else {
    color.r = mix(color.r, color.g, spillMask);
    color.b = mix(color.b, color.g, spillMask);
  }

  gl_FragColor = vec4(color * alpha, alpha);
}
`;

const clamp = (value: number, min: number, max: number) =>
  Math.min(max, Math.max(min, value));

function compileShader(
  gl: WebGLRenderingContext,
  type: number,
  source: string,
) {
  const shader = gl.createShader(type);
  if (!shader) throw new Error("无法创建 WebGL Shader");
  gl.shaderSource(shader, source);
  gl.compileShader(shader);
  if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
    const message = gl.getShaderInfoLog(shader) ?? "未知 Shader 编译错误";
    gl.deleteShader(shader);
    throw new Error(message);
  }
  return shader;
}

function createProgram(gl: WebGLRenderingContext) {
  const program = gl.createProgram();
  if (!program) throw new Error("无法创建 WebGL Program");
  const vertex = compileShader(gl, gl.VERTEX_SHADER, VERTEX_SHADER);
  const fragment = compileShader(gl, gl.FRAGMENT_SHADER, FRAGMENT_SHADER);
  gl.attachShader(program, vertex);
  gl.attachShader(program, fragment);
  gl.linkProgram(program);
  gl.deleteShader(vertex);
  gl.deleteShader(fragment);
  if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
    const message = gl.getProgramInfoLog(program) ?? "未知 WebGL 链接错误";
    gl.deleteProgram(program);
    throw new Error(message);
  }
  return program;
}

function requiredLocation(
  value: WebGLUniformLocation | null,
  name: string,
): WebGLUniformLocation {
  if (value === null) throw new Error(`缺少 WebGL 变量：${name}`);
  return value;
}

export function createChromaVideoRenderer(
  options: ChromaVideoRendererOptions,
): ChromaVideoRenderer {
  const { video, canvas } = options;
  const frameCount = Math.max(1, Math.floor(options.frameCount));
  const fps = Math.max(1, options.fps);
  const legacyKeyColor = options.keyColor ?? [0, 255, 0];
  const keying: ChromaKeyingParameters = options.keying ?? {
    algorithm: "dominance-v2",
    mode:
      legacyKeyColor[0] >= legacyKeyColor[1] + 40 &&
      legacyKeyColor[2] >= legacyKeyColor[1] + 40
        ? "magenta"
        : "green",
    keyColor: legacyKeyColor,
    similarity: options.similarity ?? 0.12,
    smoothness: options.smoothness ?? 0.06,
    dominanceStart: 0,
    dominanceEnd: 0.12,
    spillStart: -0.005,
    spillEnd: 0.06,
    spill: options.spill ?? 1,
  };
  if (keying.algorithm !== "dominance-v2") {
    throw new Error(`不支持的色键算法：${keying.algorithm}`);
  }
  const maxDpr = options.maxDpr ?? 2;
  const gl = canvas.getContext("webgl", {
    alpha: true,
    antialias: false,
    premultipliedAlpha: true,
    preserveDrawingBuffer: false,
  });
  if (!gl) throw new Error("当前浏览器无法创建 WebGL 绿幕渲染器");

  const program = createProgram(gl);
  const positionLocation = gl.getAttribLocation(program, "aPosition");
  if (positionLocation < 0) throw new Error("缺少 WebGL 顶点位置变量");
  const uvScaleLocation = requiredLocation(
    gl.getUniformLocation(program, "uUvScale"),
    "uUvScale",
  );
  const uvOffsetLocation = requiredLocation(
    gl.getUniformLocation(program, "uUvOffset"),
    "uUvOffset",
  );
  const keyColorLocation = requiredLocation(
    gl.getUniformLocation(program, "uKeyColor"),
    "uKeyColor",
  );
  const similarityLocation = requiredLocation(
    gl.getUniformLocation(program, "uSimilarity"),
    "uSimilarity",
  );
  const smoothnessLocation = requiredLocation(
    gl.getUniformLocation(program, "uSmoothness"),
    "uSmoothness",
  );
  const keyModeLocation = requiredLocation(
    gl.getUniformLocation(program, "uKeyMode"),
    "uKeyMode",
  );
  const dominanceStartLocation = requiredLocation(
    gl.getUniformLocation(program, "uDominanceStart"),
    "uDominanceStart",
  );
  const dominanceEndLocation = requiredLocation(
    gl.getUniformLocation(program, "uDominanceEnd"),
    "uDominanceEnd",
  );
  const spillStartLocation = requiredLocation(
    gl.getUniformLocation(program, "uSpillStart"),
    "uSpillStart",
  );
  const spillEndLocation = requiredLocation(
    gl.getUniformLocation(program, "uSpillEnd"),
    "uSpillEnd",
  );
  const spillLocation = requiredLocation(
    gl.getUniformLocation(program, "uSpill"),
    "uSpill",
  );

  const buffer = gl.createBuffer();
  const texture = gl.createTexture();
  if (!buffer || !texture) throw new Error("无法创建 WebGL 缓冲区");
  gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
  gl.bufferData(
    gl.ARRAY_BUFFER,
    new Float32Array([-1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, 1]),
    gl.STATIC_DRAW,
  );
  gl.bindTexture(gl.TEXTURE_2D, texture);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
  gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, 1);

  let destroyed = false;
  let seeking = false;
  let pendingFrame: number | null = 0;
  let requestedFrame = 0;
  let seekStartedAt = 0;
  let live = false;
  let liveHandle = 0;

  const resize = () => {
    if (destroyed) return;
    const rectangle = canvas.getBoundingClientRect();
    const dpr = Math.min(maxDpr, window.devicePixelRatio || 1);
    const width = Math.max(1, Math.round(rectangle.width * dpr));
    const height = Math.max(1, Math.round(rectangle.height * dpr));
    if (canvas.width !== width || canvas.height !== height) {
      canvas.width = width;
      canvas.height = height;
    }
    gl.viewport(0, 0, width, height);
  };

  const updateCoverTransform = () => {
    const sourceAspect = video.videoWidth / Math.max(1, video.videoHeight);
    const canvasAspect = canvas.width / Math.max(1, canvas.height);
    let scaleX = 1;
    let scaleY = 1;
    if (sourceAspect > canvasAspect) scaleX = canvasAspect / sourceAspect;
    else scaleY = sourceAspect / canvasAspect;
    gl.uniform2f(uvScaleLocation, scaleX, scaleY);
    gl.uniform2f(uvOffsetLocation, (1 - scaleX) / 2, (1 - scaleY) / 2);
  };

  let contextLost = false;

  const draw = () => {
    if (destroyed || contextLost || video.readyState < video.HAVE_CURRENT_DATA) return;
    resize();
    gl.clearColor(0, 0, 0, 0);
    gl.clear(gl.COLOR_BUFFER_BIT);
    gl.useProgram(program);
    gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
    gl.enableVertexAttribArray(positionLocation);
    gl.vertexAttribPointer(positionLocation, 2, gl.FLOAT, false, 0, 0);
    gl.bindTexture(gl.TEXTURE_2D, texture);
    gl.texImage2D(
      gl.TEXTURE_2D,
      0,
      gl.RGBA,
      gl.RGBA,
      gl.UNSIGNED_BYTE,
      video,
    );
    updateCoverTransform();
    gl.uniform3f(
      keyColorLocation,
      keying.keyColor[0] / 255,
      keying.keyColor[1] / 255,
      keying.keyColor[2] / 255,
    );
    gl.uniform1f(similarityLocation, keying.similarity);
    gl.uniform1f(smoothnessLocation, keying.smoothness);
    gl.uniform1f(keyModeLocation, keying.mode === "magenta" ? 1 : 0);
    gl.uniform1f(dominanceStartLocation, keying.dominanceStart);
    gl.uniform1f(dominanceEndLocation, keying.dominanceEnd);
    gl.uniform1f(spillStartLocation, keying.spillStart);
    gl.uniform1f(spillEndLocation, keying.spillEnd);
    gl.uniform1f(spillLocation, keying.spill);
    gl.drawArrays(gl.TRIANGLES, 0, 6);
  };

  const cancelLiveFrame = () => {
    if (!liveHandle) return;
    if (video.cancelVideoFrameCallback) {
      video.cancelVideoFrameCallback(liveHandle);
    } else {
      cancelAnimationFrame(liveHandle);
    }
    liveHandle = 0;
  };

  const scheduleLiveFrame = () => {
    cancelLiveFrame();
    if (!live || destroyed) return;
    const callback = () => {
      liveHandle = 0;
      if (!live || destroyed) return;
      draw();
      scheduleLiveFrame();
    };
    if (video.requestVideoFrameCallback) {
      liveHandle = video.requestVideoFrameCallback(callback);
    } else {
      liveHandle = requestAnimationFrame(callback);
    }
  };

  const flush = () => {
    if (
      destroyed ||
      seeking ||
      pendingFrame === null ||
      !Number.isFinite(video.duration) ||
      video.duration <= 0
    ) return;
    const nextFrame = pendingFrame;
    pendingFrame = null;
    const nextTime = Math.min(
      nextFrame / fps,
      Math.max(0, video.duration - 1 / fps),
    );
    if (Math.abs(video.currentTime - nextTime) <= 1 / (fps * 2)) {
      draw();
      options.onFrame?.(nextFrame, 0);
      return;
    }
    requestedFrame = nextFrame;
    seeking = true;
    seekStartedAt = performance.now();
    video.currentTime = nextTime;
  };

  const handleSeeked = () => {
    seeking = false;
    if (pendingFrame !== null) {
      if (pendingFrame !== requestedFrame) {
        flush();
        return;
      }
      pendingFrame = null;
    }
    draw();
    options.onFrame?.(requestedFrame, performance.now() - seekStartedAt);
    flush();
  };
  const handleLoaded = () => {
    video.pause();
    draw();
    flush();
  };
  const handleVideoError = () => {
    seeking = false;
    pendingFrame = null;
  };
  const handleContextLost = (event: Event) => {
    event.preventDefault();
    contextLost = true;
    cancelLiveFrame();
  };
  const handleContextRestored = () => {
    contextLost = false;
    draw();
  };
  const resizeObserver = new ResizeObserver(() => draw());
  resizeObserver.observe(canvas);
  video.muted = true;
  video.playsInline = true;
  video.preload = "auto";
  video.addEventListener("loadeddata", handleLoaded);
  video.addEventListener("seeked", handleSeeked);
  video.addEventListener("error", handleVideoError);
  canvas.addEventListener("webglcontextlost", handleContextLost);
  canvas.addEventListener("webglcontextrestored", handleContextRestored);
  if (video.readyState >= video.HAVE_CURRENT_DATA) handleLoaded();

  return {
    render(frame: number) {
      pendingFrame = Math.round(clamp(frame, 0, frameCount - 1));
      flush();
    },
    startLive() {
      live = true;
      draw();
      scheduleLiveFrame();
    },
    stopLive() {
      live = false;
      cancelLiveFrame();
    },
    resize,
    destroy() {
      destroyed = true;
      live = false;
      cancelLiveFrame();
      resizeObserver.disconnect();
      video.removeEventListener("loadeddata", handleLoaded);
      video.removeEventListener("seeked", handleSeeked);
      video.removeEventListener("error", handleVideoError);
      canvas.removeEventListener("webglcontextlost", handleContextLost);
      canvas.removeEventListener("webglcontextrestored", handleContextRestored);
      gl.deleteTexture(texture);
      gl.deleteBuffer(buffer);
      gl.deleteProgram(program);
    },
  };
}

````

<!-- ===== FILE: assets/interactive-motion.ts ===== -->
````ts
export type FrameAnimatorOptions = {
  frameCount: number;
  initialFrame?: number;
  circular?: boolean;
  smoothTime?: number;
  maxSpeed?: number;
  reducedMotion?: boolean;
  render: (frame: number) => void;
};

export type FrameAnimator = {
  setTarget(frame: number): void;
  setDirection(x: number, y: number, startAngle?: number): void;
  setProgress(progress: number): void;
  getCurrentFrame(): number;
  destroy(): void;
};

const clamp = (value: number, min: number, max: number) =>
  Math.min(max, Math.max(min, value));

const wrap = (value: number, length: number) =>
  ((value % length) + length) % length;

const shortestCircularDelta = (
  from: number,
  to: number,
  frameCount: number,
) => {
  let delta = wrap(to, frameCount) - wrap(from, frameCount);
  if (delta > frameCount / 2) delta -= frameCount;
  if (delta < -frameCount / 2) delta += frameCount;
  return delta;
};

const smoothDamp = (
  current: number,
  target: number,
  velocity: number,
  smoothTime: number,
  maxSpeed: number,
  deltaTime: number,
): [number, number] => {
  const safeTime = Math.max(0.0001, smoothTime);
  const omega = 2 / safeTime;
  const x = omega * deltaTime;
  const decay = 1 / (1 + x + 0.48 * x * x + 0.235 * x * x * x);
  const originalTarget = target;
  const maxChange = maxSpeed * safeTime;
  const change = clamp(current - target, -maxChange, maxChange);
  const limitedTarget = current - change;
  const temp = (velocity + omega * change) * deltaTime;
  let nextVelocity = (velocity - omega * temp) * decay;
  let nextPosition = limitedTarget + (change + temp) * decay;

  if (
    (originalTarget - current > 0) ===
    (nextPosition > originalTarget)
  ) {
    nextPosition = originalTarget;
    nextVelocity = 0;
  }
  return [nextPosition, nextVelocity];
};

export function createFrameAnimator(
  options: FrameAnimatorOptions,
): FrameAnimator {
  const frameCount = Math.max(1, Math.floor(options.frameCount));
  const circular = options.circular ?? false;
  const smoothTime = options.smoothTime ?? 0.11;
  const maxSpeed = options.maxSpeed ?? frameCount * 2;
  const reducedMotion = options.reducedMotion ?? false;
  let position = clamp(options.initialFrame ?? 0, 0, frameCount - 1);
  let target = position;
  let velocity = 0;
  let lastFrame = -1;
  let lastTime = 0;
  let raf = 0;
  let destroyed = false;

  const normalizeFrame = (frame: number) =>
    circular
      ? wrap(frame, frameCount)
      : clamp(frame, 0, frameCount - 1);

  const render = () => {
    const frame = Math.round(normalizeFrame(position));
    if (frame !== lastFrame) {
      options.render(frame);
      lastFrame = frame;
    }
  };

  const loop = (now: number) => {
    raf = 0;
    if (destroyed) return;
    const deltaTime = lastTime
      ? Math.min((now - lastTime) / 1000, 1 / 30)
      : 1 / 60;
    lastTime = now;

    if (reducedMotion) {
      position = target;
      velocity = 0;
    } else {
      [position, velocity] = smoothDamp(
        position,
        target,
        velocity,
        smoothTime,
        maxSpeed,
        deltaTime,
      );
    }
    render();

    if (Math.abs(target - position) > 0.002 || Math.abs(velocity) > 0.002) {
      raf = requestAnimationFrame(loop);
    } else if (circular) {
      position = wrap(position, frameCount);
      target = position;
    }
  };

  const schedule = () => {
    if (!raf && !destroyed) raf = requestAnimationFrame(loop);
  };

  render();

  return {
    setTarget(frame: number) {
      const normalized = normalizeFrame(frame);
      target = circular
        ? position + shortestCircularDelta(position, normalized, frameCount)
        : normalized;
      schedule();
    },
    setDirection(x: number, y: number, startAngle = -Math.PI * 0.75) {
      const angle = Math.atan2(y, x);
      const turn = Math.PI * 2;
      const normalized = ((angle - startAngle + turn) % turn) / turn;
      this.setTarget(normalized * frameCount);
    },
    setProgress(progress: number) {
      this.setTarget(clamp(progress, 0, 1) * (frameCount - 1));
    },
    getCurrentFrame() {
      return normalizeFrame(position);
    },
    destroy() {
      destroyed = true;
      if (raf) cancelAnimationFrame(raf);
      raf = 0;
    },
  };
}
export function createCssSpriteRenderer(
  element: HTMLElement,
  columns: number,
  rows: number,
) {
  const safeColumns = Math.max(1, Math.floor(columns));
  const safeRows = Math.max(1, Math.floor(rows));
  element.style.backgroundSize = `${safeColumns * 100}% ${safeRows * 100}%`;

  return (frame: number) => {
    const column = frame % safeColumns;
    const row = Math.floor(frame / safeColumns);
    const x = safeColumns === 1 ? 0 : (column / (safeColumns - 1)) * 100;
    const y = safeRows === 1 ? 0 : (row / (safeRows - 1)) * 100;
    element.style.backgroundPosition = `${x}% ${y}%`;
  };
}

export type SegmentRateCurve =
  | { type: "constant"; rate: number }
  | {
      type: "edge-mid-edge";
      edgeRate: number;
      midRate: number;
    };

export type TimelineSegment = {
  id?: string;
  from?: string;
  to?: string;
  start: number;
  hold: number;
  endExclusive: number;
  curve?: SegmentRateCurve;
};

export type TimelineState = {
  id: string;
  hold: number;
};

export type SegmentPlayerOptions = {
  video: HTMLVideoElement;
  segments: readonly TimelineSegment[];
  states?: readonly TimelineState[];
  frameDuration: number;
  initialState?: number | string;
  reducedMotion?: boolean;
  onStateChange?: (state: number) => void;
  onError?: (error: unknown) => void;
};

export type SegmentPlayerState = {
  currentState: number;
  currentStateId: string;
  targetState: number;
  targetStateId: string;
  playing: boolean;
  currentTime: number;
};

export type SegmentPlayer = {
  goTo(state: number | string): void;
  step(direction: -1 | 1): void;
  cancel(): void;
  getState(): SegmentPlayerState;
  destroy(): void;
};

type VideoFrameCapable = HTMLVideoElement & {
  requestVideoFrameCallback?: (callback: (now: number) => void) => number;
  cancelVideoFrameCallback?: (handle: number) => void;
};

const segmentRate = (segment: TimelineSegment, time: number) => {
  const curve = segment.curve ?? { type: "constant", rate: 1 };
  if (curve.type === "constant") return Math.max(0.1, curve.rate);
  const span = Math.max(0.0001, segment.hold - segment.start);
  const progress = clamp((time - segment.start) / span, 0, 1);
  const edgeWeight = Math.cos(Math.PI * progress) ** 2;
  return Math.max(
    0.1,
    curve.midRate + (curve.edgeRate - curve.midRate) * edgeWeight,
  );
};

const validateSegments = (segments: readonly TimelineSegment[]) => {
  if (!segments.length) throw new Error("segments 不能为空");
  segments.forEach((segment, index) => {
    if (!(segment.start <= segment.hold && segment.hold < segment.endExclusive)) {
      throw new Error(`segment ${index} 必须满足 start <= hold < endExclusive`);
    }
    if (index > 0 && segment.start < segments[index - 1].endExclusive) {
      throw new Error(`segment ${index} 与上一段时间范围重叠`);
    }
  });
};

export function createSegmentPlayer(
  options: SegmentPlayerOptions,
): SegmentPlayer {
  validateSegments(options.segments);
  const video = options.video as VideoFrameCapable;
  const maxState = options.segments.length;
  const frameDuration = Math.max(0.001, options.frameDuration);
  const reducedMotion = options.reducedMotion ?? false;
  const states = options.states ?? [
    { id: "state-0", hold: options.segments[0].start },
    ...options.segments.map((segment, index) => ({
      id: segment.to ?? `state-${index + 1}`,
      hold: segment.hold,
    })),
  ];
  if (states.length !== maxState + 1) {
    throw new Error("states 数量必须等于 segments 数量加一");
  }
  const stateIds = states.map((state) => state.id);
  if (new Set(stateIds).size !== stateIds.length || stateIds.some((id) => !id)) {
    throw new Error("timeline state id 必须非空且唯一");
  }
  if (Math.abs(states[0].hold - options.segments[0].start) > frameDuration / 2) {
    throw new Error("初始 state hold 必须对应第一段 start");
  }
  options.segments.forEach((segment, index) => {
    if (segment.from && segment.from !== states[index].id) {
      throw new Error(`segment ${index} 的 from 与 states 顺序不一致`);
    }
    if (segment.to && segment.to !== states[index + 1].id) {
      throw new Error(`segment ${index} 的 to 与 states 顺序不一致`);
    }
    if (Math.abs(states[index + 1].hold - segment.hold) > frameDuration / 2) {
      throw new Error(`segment ${index} 的 hold 与目标 state 不一致`);
    }
  });
  const resolveState = (state: number | string) => {
    if (typeof state === "string") {
      const index = stateIds.indexOf(state);
      if (index < 0) throw new Error(`未知 timeline state id：${state}`);
      return index;
    }
    return clamp(Math.round(state), 0, maxState);
  };
  let currentState = resolveState(options.initialState ?? 0);
  let targetState = currentState;
  let running = false;
  let destroyed = false;
  let runToken = 0;
  let scheduledHandle = 0;
  let scheduledWithVideo = false;
  let lastTick = 0;

  const stateTime = (state: number) => states[state].hold;

  const cancelScheduled = () => {
    if (!scheduledHandle) return;
    if (scheduledWithVideo) {
      video.cancelVideoFrameCallback?.(scheduledHandle);
    } else {
      cancelAnimationFrame(scheduledHandle);
    }
    scheduledHandle = 0;
  };

  const schedule = (direction: -1 | 1, callback: (now: number) => void) => {
    cancelScheduled();
    if (direction === 1 && video.requestVideoFrameCallback) {
      scheduledWithVideo = true;
      scheduledHandle = video.requestVideoFrameCallback(callback);
    } else {
      scheduledWithVideo = false;
      scheduledHandle = requestAnimationFrame(callback);
    }
  };

  const segmentForTime = (time: number, direction: -1 | 1) => {
    if (direction === 1) {
      return (
        options.segments.find(
          (segment) => time < segment.hold + frameDuration / 2,
        ) ?? options.segments[maxState - 1]
      );
    }
    for (let index = maxState - 1; index >= 0; index -= 1) {
      if (time > options.segments[index].start - frameDuration / 2) {
        return options.segments[index];
      }
    }
    return options.segments[0];
  };

  const removeBoundaryGap = (
    time: number,
    direction: -1 | 1,
    targetTime: number,
  ) => {
    if (direction === 1) {
      for (let index = 1; index < maxState; index += 1) {
        const previousHold = options.segments[index - 1].hold;
        const nextStart = options.segments[index].start;
        if (
          targetTime > previousHold + frameDuration / 2 &&
          time >= previousHold - frameDuration / 2 &&
          time < nextStart
        ) return nextStart;
      }
    } else {
      for (let index = maxState - 1; index > 0; index -= 1) {
        const previousHold = options.segments[index - 1].hold;
        const nextStart = options.segments[index].start;
        if (
          targetTime <= previousHold + frameDuration / 2 &&
          time > previousHold &&
          time <= nextStart + frameDuration / 2
        ) return previousHold;
      }
    }
    return time;
  };

  const settle = () => {
    cancelScheduled();
    video.pause();
    video.currentTime = stateTime(targetState);
    currentState = targetState;
    running = false;
    lastTick = 0;
    options.onStateChange?.(currentState);
  };

  const startRun = () => {
    const token = ++runToken;
    cancelScheduled();
    video.pause();
    const targetTime = stateTime(targetState);
    const initialTime = removeBoundaryGap(
      video.currentTime,
      targetTime >= video.currentTime ? 1 : -1,
      targetTime,
    );
    if (initialTime !== video.currentTime) video.currentTime = initialTime;

    if (reducedMotion || Math.abs(targetTime - video.currentTime) <= frameDuration / 2) {
      settle();
      return;
    }

    const direction: -1 | 1 = targetTime > video.currentTime ? 1 : -1;
    running = true;
    lastTick = 0;

    const tick = (now: number) => {
      scheduledHandle = 0;
      if (destroyed || token !== runToken) return;

      const boundedTime = removeBoundaryGap(
        video.currentTime,
        direction,
        targetTime,
      );
      if (boundedTime !== video.currentTime) video.currentTime = boundedTime;
      const reached =
        direction === 1
          ? video.currentTime >= targetTime - frameDuration / 2
          : video.currentTime <= targetTime + frameDuration / 2;
      if (reached) {
        settle();
        return;
      }

      const segment = segmentForTime(video.currentTime, direction);
      const rate = segmentRate(segment, video.currentTime);
      if (direction === 1) {
        video.playbackRate = rate;
      } else {
        video.pause();
        const delta = lastTick
          ? Math.min((now - lastTick) / 1000, 1 / 30)
          : 1 / 60;
        video.currentTime = Math.max(targetTime, video.currentTime - rate * delta);
      }
      lastTick = now;
      schedule(direction, tick);
    };

    if (direction === 1) {
      const segment = segmentForTime(video.currentTime, direction);
      video.playbackRate = segmentRate(segment, video.currentTime);
      void video
        .play()
        .then(() => {
          if (token !== runToken || destroyed) return;
          schedule(direction, tick);
        })
        .catch((error) => {
          if (token !== runToken || destroyed) return;
          running = false;
          options.onError?.(error);
        });
    } else {
      schedule(direction, tick);
    }
  };

  const seekInitialState = () => {
    if (destroyed) return;
    video.currentTime = stateTime(currentState);
  };
  if (video.readyState >= 1) seekInitialState();
  else video.addEventListener("loadedmetadata", seekInitialState, { once: true });

  const handleVideoError = (event: Event) => {
    if (destroyed) return;
    cancelScheduled();
    video.pause();
    running = false;
    lastTick = 0;
    options.onError?.(video.error ?? event);
  };
  video.addEventListener("error", handleVideoError);

  return {
    goTo(state: number | string) {
      if (destroyed) return;
      targetState = resolveState(state);
      startRun();
    },
    step(direction: -1 | 1) {
      this.goTo(targetState + direction);
    },
    cancel() {
      runToken += 1;
      cancelScheduled();
      video.pause();
      running = false;
      lastTick = 0;
    },
    getState() {
      return {
        currentState,
        currentStateId: states[currentState].id,
        targetState,
        targetStateId: states[targetState].id,
        playing: running,
        currentTime: video.currentTime,
      };
    },
    destroy() {
      this.cancel();
      destroyed = true;
      video.removeEventListener("loadedmetadata", seekInitialState);
      video.removeEventListener("error", handleVideoError);
    },
  };
}

````

<!-- ===== FILE: assets/motion-explainer-template.html ===== -->
````html
<!doctype html>
<html lang="zh-CN">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Oil Motion — 动画原理</title>
    <style>
      :root {
        color-scheme: light;
        --ink: #191919;
        --paper: #fffefa;
        --muted: #92928e;
        --line: rgba(25, 25, 25, 0.13);
        --grid: rgba(25, 25, 25, 0.05);
        --yellow: #ffe28a;
      }

      * {
        box-sizing: border-box;
      }

      html {
        min-width: 320px;
        background: var(--paper);
      }

      body {
        min-width: 320px;
        min-height: 100svh;
        margin: 0;
        overflow-x: hidden;
        color: var(--ink);
        background:
          linear-gradient(var(--grid) 1px, transparent 1px),
          linear-gradient(90deg, var(--grid) 1px, transparent 1px),
          radial-gradient(circle at 8% 4%, rgba(255, 226, 138, 0.24), transparent 28%),
          var(--paper);
        background-size: 44px 44px, 44px 44px, auto, auto;
        font-family:
          Inter, ui-sans-serif, -apple-system, BlinkMacSystemFont, "PingFang SC",
          "Microsoft YaHei", sans-serif;
      }

      button,
      input {
        font: inherit;
      }

      .shell {
        min-height: 100svh;
        height: 100svh;
        display: grid;
        grid-template-rows: auto minmax(0, 1fr);
        gap: 16px;
        padding: 22px;
      }

      body.is-scroll .shell {
        position: sticky;
        top: 0;
      }

      .scroll-spacer {
        display: none;
        height: var(--scroll-height, 300svh);
        pointer-events: none;
      }

      body.is-scroll .scroll-spacer {
        display: block;
      }

      .topbar {
        display: flex;
        align-items: flex-end;
        justify-content: space-between;
        gap: 24px;
        min-width: 0;
        padding: 0 4px;
      }

      .topbar h1 {
        margin: 0;
        font-size: clamp(25px, 2.4vw, 40px);
        font-weight: 760;
        line-height: 1;
        letter-spacing: -0.045em;
      }

      .topbar p,
      .kicker,
      .readout,
      .formula {
        font-family: ui-monospace, "SFMono-Regular", Menlo, monospace;
      }

      .topbar p {
        margin: 0;
        color: var(--muted);
        font-size: 12px;
        letter-spacing: 0.13em;
        text-transform: uppercase;
      }

      .workspace {
        min-height: 0;
        display: grid;
        grid-template-columns: minmax(0, 2fr) minmax(300px, 1fr);
        gap: 16px;
      }

      .panel {
        position: relative;
        min-width: 0;
        min-height: 0;
        overflow: hidden;
        border: 1px solid var(--line);
        border-radius: 28px;
        background: rgba(255, 255, 255, 0.82);
      }

      .source-panel,
      .preview-panel {
        display: grid;
        grid-template-rows: auto minmax(0, 1fr) auto;
      }

      .panel-head {
        position: relative;
        z-index: 4;
        min-height: 62px;
        display: flex;
        align-items: center;
        gap: 18px;
        padding: 14px 20px;
        border-bottom: 1px solid var(--line);
      }

      .source-tabs {
        display: flex;
        gap: 5px;
        padding: 4px;
        border: 1px solid var(--line);
        border-radius: 999px;
        background: rgba(25, 25, 25, 0.035);
      }

      .source-tab {
        min-height: 30px;
        padding: 0 12px;
        border: 0;
        border-radius: 999px;
        color: var(--muted);
        background: transparent;
        font-size: 12px;
        font-weight: 650;
        cursor: pointer;
      }

      .source-tab[aria-selected="true"] {
        color: var(--ink);
        background: var(--paper);
        box-shadow: 0 1px 5px rgba(25, 25, 25, 0.1);
      }

      .source-tab:focus-visible,
      .zoom-controls button:focus-visible,
      .zoom-controls input:focus-visible {
        outline: 2px solid var(--ink);
        outline-offset: 2px;
      }

      .kicker {
        margin: 0;
        color: var(--muted);
        font-size: 11px;
        font-weight: 650;
        letter-spacing: 0.12em;
        text-transform: uppercase;
      }

      .readout {
        display: flex;
        align-items: baseline;
        gap: 9px;
        margin-left: auto;
        white-space: nowrap;
      }

      .readout strong {
        font-size: 18px;
      }

      .readout span {
        color: var(--muted);
        font-size: 10px;
      }

      [hidden] {
        display: none !important;
      }

      .atlas-viewport {
        position: relative;
        min-height: 0;
        display: grid;
        place-items: center;
        overflow: hidden;
        cursor: grab;
        touch-action: none;
        user-select: none;
      }

      .atlas-viewport.dragging {
        cursor: grabbing;
      }

      .atlas-stage {
        position: relative;
        width: min(94%, calc((100svh - 178px) * var(--atlas-ratio)));
        max-height: 94%;
        aspect-ratio: var(--atlas-ratio);
        flex: none;
        transform: translate3d(var(--pan-x, 0), var(--pan-y, 0), 0)
          scale(var(--zoom, 1));
        transform-origin: center;
        will-change: transform;
      }

      .atlas-stage img {
        display: block;
        width: 100%;
        height: 100%;
        object-fit: fill;
        pointer-events: none;
      }

      .atlas-grid {
        position: absolute;
        inset: 0;
        pointer-events: none;
        background:
          repeating-linear-gradient(
            90deg,
            transparent 0 calc(var(--cell-pct-x) - 1px),
            rgba(25, 25, 25, 0.09) calc(var(--cell-pct-x) - 1px) var(--cell-pct-x)
          ),
          repeating-linear-gradient(
            0deg,
            transparent 0 calc(var(--cell-pct-y) - 1px),
            rgba(25, 25, 25, 0.09) calc(var(--cell-pct-y) - 1px) var(--cell-pct-y)
          );
      }

      .frame-highlight {
        position: absolute;
        z-index: 3;
        width: var(--cell-pct-x);
        height: var(--cell-pct-y);
        border: calc(3px / var(--zoom, 1)) solid var(--ink);
        background: rgba(255, 226, 138, 0.24);
        box-shadow:
          0 0 0 calc(4px / var(--zoom, 1)) var(--yellow),
          0 0 calc(20px / var(--zoom, 1)) rgba(255, 196, 31, 0.75);
        pointer-events: none;
      }

      .zoom-controls,
      .video-meta {
        min-height: 58px;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 10px;
        padding: 10px 18px;
        border-top: 1px solid var(--line);
      }

      .zoom-controls button {
        min-width: 36px;
        min-height: 34px;
        border: 1px solid var(--line);
        border-radius: 999px;
        background: var(--paper);
        color: var(--ink);
        cursor: pointer;
      }

      .zoom-controls .reset {
        min-width: 64px;
        font-size: 11px;
      }

      .zoom-controls input {
        width: min(220px, 42%);
        accent-color: var(--ink);
      }

      .video-view {
        min-height: 0;
        display: grid;
        place-items: center;
        overflow: hidden;
        padding: 18px;
      }

      .video-shell {
        position: relative;
        width: min(84%, 62svh);
        max-height: 100%;
        border: 1px solid var(--line);
        border-radius: 22px;
        overflow: hidden;
        background: #00ff00;
      }

      .video-shell video {
        display: block;
        width: 100%;
        max-height: calc(100svh - 190px);
        object-fit: contain;
      }

      .video-badge {
        position: absolute;
        top: 12px;
        left: 12px;
        z-index: 2;
        padding: 7px 10px;
        border: 1px solid rgba(25, 25, 25, 0.18);
        border-radius: 999px;
        background: rgba(255, 254, 250, 0.9);
        font: 650 10px/1 ui-monospace, Menlo, monospace;
        letter-spacing: 0.08em;
      }

      .video-meta {
        color: var(--muted);
        font-size: 11px;
        letter-spacing: 0.06em;
      }

      .preview-stage {
        position: relative;
        min-height: 0;
        display: grid;
        place-items: center;
        overflow: hidden;
        touch-action: none;
        user-select: none;
      }

      .preview-stage.drag-driver {
        cursor: ew-resize;
      }

      .preview-stage::before {
        content: "";
        position: absolute;
        width: min(82%, 430px);
        aspect-ratio: 1;
        border: 1px dashed rgba(25, 25, 25, 0.12);
        border-radius: 50%;
      }

      .sprite {
        position: relative;
        z-index: 2;
        width: min(78%, 430px);
        aspect-ratio: var(--cell-ratio);
        background-image: var(--atlas-image);
        background-repeat: no-repeat;
        background-size: calc(var(--columns) * 100%) calc(var(--rows) * 100%);
        filter: drop-shadow(0 18px 22px rgba(25, 25, 25, 0.1));
        will-change: background-position;
      }

      .target-dot {
        position: absolute;
        z-index: 4;
        left: 50%;
        top: 50%;
        width: 14px;
        height: 14px;
        border: 3px solid var(--ink);
        border-radius: 50%;
        background: var(--yellow);
        opacity: 0;
        transform: translate(-50%, -50%) scale(0.75);
        transition: opacity 160ms ease, transform 160ms ease;
        pointer-events: none;
      }

      .target-dot.visible {
        opacity: 1;
        transform: translate(-50%, -50%) scale(1);
      }

      .hint {
        position: absolute;
        top: 24px;
        left: 50%;
        z-index: 3;
        margin: 0;
        color: var(--muted);
        font-size: 12px;
        letter-spacing: 0.12em;
        transform: translateX(-50%);
        white-space: nowrap;
        pointer-events: none;
      }

      .formula {
        min-height: 58px;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-wrap: wrap;
        gap: 9px;
        padding: 12px 18px;
        border-top: 1px solid var(--line);
        color: var(--muted);
        font-size: 11px;
        text-align: center;
      }

      .formula b {
        color: var(--ink);
        font-weight: 650;
      }

      .formula i {
        width: 5px;
        height: 5px;
        border-radius: 50%;
        background: var(--yellow);
        box-shadow: 0 0 0 1px var(--ink);
      }

      .loading-cover {
        position: fixed;
        inset: 0;
        z-index: 20;
        display: grid;
        place-items: center;
        background: var(--paper);
        transition: opacity 280ms ease, visibility 280ms ease;
      }

      .loading-cover::before {
        content: "";
        width: 34px;
        aspect-ratio: 1;
        border: 3px solid rgba(25, 25, 25, 0.12);
        border-top-color: var(--ink);
        border-radius: 50%;
        animation: spin 700ms linear infinite;
      }

      .loading-cover.ready {
        opacity: 0;
        visibility: hidden;
      }

      @keyframes spin {
        to { transform: rotate(1turn); }
      }

      @media (max-width: 820px) {
        .shell,
        body.is-scroll .shell {
          position: relative;
          height: auto;
          min-height: 100svh;
          display: block;
          padding: 14px;
        }

        body.is-scroll .shell {
          position: sticky;
          top: 0;
        }

        .topbar {
          align-items: flex-start;
          margin: 4px 2px 14px;
        }

        .topbar p {
          display: none;
        }

        .workspace {
          grid-template-columns: 1fr;
        }

        .panel {
          min-height: 70svh;
          border-radius: 22px;
        }

        .source-panel {
          min-height: 78svh;
        }

        .atlas-stage {
          width: min(96%, calc(55svh * var(--atlas-ratio)));
        }

        .preview-panel {
          min-height: 70svh;
        }

        .sprite {
          width: min(68vw, 390px);
        }

        body.is-scroll .source-panel {
          display: none;
        }

        body.is-scroll .workspace {
          height: calc(100svh - 76px);
        }
      }

      @media (prefers-reduced-motion: reduce) {
        .loading-cover,
        .target-dot {
          transition: none;
        }

        .loading-cover::before {
          animation: none;
        }
      }
    </style>
  </head>
  <body>
    <script type="application/json" id="motion-config">__MOTION_EXPLAINER_CONFIG__</script>
    <div class="loading-cover" id="loading-cover" aria-hidden="true"></div>

    <main class="shell">
      <header class="topbar">
        <h1 id="page-title">动画原理展示</h1>
        <p id="driver-summary">Input → Smooth → Frame → Sprite</p>
      </header>

      <div class="workspace">
        <section class="panel source-panel" aria-label="动画素材">
          <header class="panel-head">
            <div class="source-tabs" role="tablist" aria-label="查看动画素材">
              <button class="source-tab" id="tab-atlas" type="button" role="tab"
                aria-selected="true" aria-controls="panel-atlas">雪碧图</button>
              <button class="source-tab" id="tab-video" type="button" role="tab"
                aria-selected="false" aria-controls="panel-video">母版视频</button>
            </div>
            <div class="readout" id="atlas-readout" aria-live="polite">
              <strong id="frame-number">000</strong>
              <span id="frame-position">ROW 01 · COL 01</span>
            </div>
            <div class="readout" id="video-readout" hidden>
              <strong id="video-time">00:00</strong>
              <span>MASTER</span>
            </div>
          </header>

          <div class="atlas-viewport" id="panel-atlas" role="tabpanel"
            aria-labelledby="tab-atlas">
            <div class="atlas-stage" id="atlas-stage">
              <img id="atlas-image" alt="动画完整雪碧图" draggable="false" />
              <div class="atlas-grid" aria-hidden="true"></div>
              <div class="frame-highlight" id="frame-highlight" aria-hidden="true"></div>
            </div>
          </div>

          <div class="video-view" id="panel-video" role="tabpanel"
            aria-labelledby="tab-video" hidden>
            <div class="video-shell">
              <span class="video-badge">AI MOTION · ORIGINAL</span>
              <video id="source-video" controls muted loop playsinline preload="metadata"></video>
            </div>
          </div>

          <div class="zoom-controls" id="atlas-controls" aria-label="雪碧图缩放">
            <button id="zoom-out" type="button" aria-label="缩小">−</button>
            <input id="zoom-range" type="range" min="1" max="4" step="0.05"
              value="1" aria-label="雪碧图缩放比例" />
            <button id="zoom-in" type="button" aria-label="放大">＋</button>
            <button class="reset" id="zoom-reset" type="button">100%</button>
          </div>
          <div class="video-meta" id="video-meta" hidden>
            <span>AI 生成的动作母版</span>
          </div>
        </section>

        <section class="panel preview-panel" aria-label="实时渲染">
          <header class="panel-head">
            <p class="kicker" id="driver-label">实时渲染</p>
            <div class="readout">
              <strong id="rendered-frame">000</strong>
              <span>RENDERED FRAME</span>
            </div>
          </header>
          <div class="preview-stage" id="preview-stage">
            <p class="hint" id="hint"></p>
            <div class="sprite" id="sprite" role="img" aria-label="实时动画"></div>
            <div class="target-dot" id="target-dot" aria-hidden="true"></div>
          </div>
          <div class="formula" id="formula" aria-label="动画实现原理"></div>
        </section>
      </div>
    </main>
    <div class="scroll-spacer" aria-hidden="true"></div>

    <script>
      (() => {
        const config = JSON.parse(
          document.querySelector("#motion-config").textContent,
        );
        const FRAME_COUNT = config.frameCount;
        const COLUMNS = config.columns;
        const ROWS = config.rows;
        const REST_FRAME = config.restFrame;
        const CIRCULAR = config.driver === "pointer-angle";
        const FULL_TURN = Math.PI * 2;
        const ANGLE_START = (config.angleStartDeg * Math.PI) / 180;
        const reduceMotion = matchMedia("(prefers-reduced-motion: reduce)").matches;

        const root = document.documentElement;
        const body = document.body;
        const loadingCover = document.querySelector("#loading-cover");
        const pageTitle = document.querySelector("#page-title");
        const driverSummary = document.querySelector("#driver-summary");
        const driverLabel = document.querySelector("#driver-label");
        const hint = document.querySelector("#hint");
        const formula = document.querySelector("#formula");
        const previewStage = document.querySelector("#preview-stage");
        const sprite = document.querySelector("#sprite");
        const targetDot = document.querySelector("#target-dot");
        const highlight = document.querySelector("#frame-highlight");
        const frameNumber = document.querySelector("#frame-number");
        const framePosition = document.querySelector("#frame-position");
        const renderedFrame = document.querySelector("#rendered-frame");
        const atlasImage = document.querySelector("#atlas-image");
        const atlasViewport = document.querySelector("#panel-atlas");
        const atlasStage = document.querySelector("#atlas-stage");
        const zoomRange = document.querySelector("#zoom-range");
        const zoomReset = document.querySelector("#zoom-reset");
        const sourceVideo = document.querySelector("#source-video");
        const videoTab = document.querySelector("#tab-video");
        const videoPanel = document.querySelector("#panel-video");
        const videoMeta = document.querySelector("#video-meta");
        const videoReadout = document.querySelector("#video-readout");
        const atlasReadout = document.querySelector("#atlas-readout");
        const atlasControls = document.querySelector("#atlas-controls");
        const videoTime = document.querySelector("#video-time");
        const sourceTabs = [...document.querySelectorAll(".source-tab")];

        const driverCopy = {
          "pointer-angle": {
            label: "POINTER ANGLE",
            hint: "移动指针，观察方向如何映射成帧",
            summary: "Pointer → Angle → Frame → Sprite",
            formula: ["指针方向", "atan2", "smoothDamp", "background-position"],
          },
          "pointer-x": {
            label: "POINTER X",
            hint: "左右移动指针，控制动画进度",
            summary: "Pointer X → Progress → Frame → Sprite",
            formula: ["指针 X", "progress", "smoothDamp", "background-position"],
          },
          drag: {
            label: "DRAG",
            hint: "左右拖拽，逐帧查看动作",
            summary: "Drag → Progress → Frame → Sprite",
            formula: ["拖拽距离", "progress", "smoothDamp", "background-position"],
          },
          scroll: {
            label: "SCROLL",
            hint: "继续向下滚动，时间轴会跟着前进",
            summary: "Scroll → Progress → Frame → Sprite",
            formula: ["滚动进度", "progress", "smoothDamp", "background-position"],
          },
          autoplay: {
            label: "AUTOPLAY",
            hint: "时间轴正在自动播放",
            summary: "Time → Progress → Frame → Sprite",
            formula: ["时间", config.autoplayMode, "frame", "background-position"],
          },
        };
        const copy = driverCopy[config.driver];

        const clamp = (value, min = 0, max = 1) =>
          Math.min(max, Math.max(min, value));
        const wrap = (value) =>
          ((value % FRAME_COUNT) + FRAME_COUNT) % FRAME_COUNT;
        const shortestDelta = (from, to) => {
          let delta = wrap(to) - wrap(from);
          if (delta > FRAME_COUNT / 2) delta -= FRAME_COUNT;
          if (delta < -FRAME_COUNT / 2) delta += FRAME_COUNT;
          return delta;
        };
        const setTarget = (target) => {
          frameTarget = CIRCULAR
            ? frameValue + shortestDelta(frameValue, target)
            : clamp(target, 0, FRAME_COUNT - 1);
          schedule();
        };
        const smoothDamp = (
          current, target, velocity, smoothTime, maxSpeed, deltaTime,
        ) => {
          const safeTime = Math.max(0.0001, smoothTime);
          const omega = 2 / safeTime;
          const x = omega * deltaTime;
          const decay = 1 / (1 + x + 0.48 * x * x + 0.235 * x * x * x);
          const originalTarget = target;
          const change = clamp(
            current - target,
            -maxSpeed * safeTime,
            maxSpeed * safeTime,
          );
          const limitedTarget = current - change;
          const temp = (velocity + omega * change) * deltaTime;
          let nextVelocity = (velocity - omega * temp) * decay;
          let next = limitedTarget + (change + temp) * decay;
          if ((originalTarget - current > 0) === (next > originalTarget)) {
            next = originalTarget;
            nextVelocity = 0;
          }
          return [next, nextVelocity];
        };

        let frameTarget = REST_FRAME;
        let frameValue = REST_FRAME;
        let frameVelocity = 0;
        let lastRendered = -1;
        let lastTime = 0;
        let raf = 0;
        let autoStart = 0;
        let dragPreviewId = null;
        let dragStartX = 0;
        let dragStartFrame = REST_FRAME;

        let zoom = 1;
        let panX = 0;
        let panY = 0;
        let atlasDragId = null;
        let atlasDragX = 0;
        let atlasDragY = 0;
        let atlasPanX = 0;
        let atlasPanY = 0;

        const setFrame = (frame) => {
          const column = frame % COLUMNS;
          const row = Math.floor(frame / COLUMNS);
          const x = COLUMNS === 1 ? 0 : (column / (COLUMNS - 1)) * 100;
          const y = ROWS === 1 ? 0 : (row / (ROWS - 1)) * 100;
          sprite.style.backgroundPosition = `${x}% ${y}%`;
          highlight.style.left = `${(column / COLUMNS) * 100}%`;
          highlight.style.top = `${(row / ROWS) * 100}%`;
          frameNumber.textContent = String(frame).padStart(3, "0");
          renderedFrame.textContent = String(frame).padStart(3, "0");
          framePosition.textContent =
            `ROW ${String(row + 1).padStart(2, "0")} · COL ${String(column + 1).padStart(2, "0")}`;
        };

        const schedule = () => {
          if (!raf) raf = requestAnimationFrame(loop);
        };

        const autoplayTarget = (now) => {
          if (!autoStart) autoStart = now;
          const raw = ((now - autoStart) / 1000) * config.autoplayFps;
          if (config.autoplayMode === "once") {
            return Math.min(raw, FRAME_COUNT - 1);
          }
          if (config.autoplayMode === "pingpong") {
            const span = Math.max(1, (FRAME_COUNT - 1) * 2);
            const phase = raw % span;
            return phase <= FRAME_COUNT - 1 ? phase : span - phase;
          }
          return raw % FRAME_COUNT;
        };

        const loop = (now) => {
          raf = 0;
          const dt = lastTime ? Math.min((now - lastTime) / 1000, 1 / 30) : 1 / 60;
          lastTime = now;

          if (config.driver === "autoplay" && !reduceMotion) {
            frameTarget = autoplayTarget(now);
          }

          if (reduceMotion) {
            frameValue = config.driver === "scroll" ? frameTarget : REST_FRAME;
            frameVelocity = 0;
          } else {
            [frameValue, frameVelocity] = smoothDamp(
              frameValue,
              frameTarget,
              frameVelocity,
              config.smoothTime,
              config.maxFrameSpeed,
              dt,
            );
          }

          const rendered = CIRCULAR || config.autoplayMode === "loop"
            ? wrap(Math.round(frameValue))
            : clamp(Math.round(frameValue), 0, FRAME_COUNT - 1);
          if (rendered !== lastRendered) {
            setFrame(rendered);
            lastRendered = rendered;
          }

          const moving =
            Math.abs(frameTarget - frameValue) > 0.003 ||
            Math.abs(frameVelocity) > 0.003;
          const keepPlaying =
            config.driver === "autoplay" &&
            !reduceMotion &&
            !(config.autoplayMode === "once" && frameTarget >= FRAME_COUNT - 1);
          if (moving || keepPlaying) raf = requestAnimationFrame(loop);
        };

        const pointerPosition = (event) => {
          const rect = previewStage.getBoundingClientRect();
          targetDot.style.left = `${clamp(event.clientX - rect.left, 10, rect.width - 10)}px`;
          targetDot.style.top = `${clamp(event.clientY - rect.top, 10, rect.height - 10)}px`;
          targetDot.classList.add("visible");
          return rect;
        };

        const updatePointer = (event) => {
          if (config.driver !== "pointer-angle" && config.driver !== "pointer-x") return;
          const stageRect = pointerPosition(event);
          if (config.driver === "pointer-x") {
            const progress = clamp((event.clientX - stageRect.left) / stageRect.width);
            setTarget(progress * (FRAME_COUNT - 1));
            return;
          }
          const rect = sprite.getBoundingClientRect();
          const originX = rect.left + rect.width / 2;
          const originY = rect.top + rect.height / 2;
          const angle = Math.atan2(event.clientY - originY, event.clientX - originX);
          const progress = ((angle - ANGLE_START + FULL_TURN) % FULL_TURN) / FULL_TURN;
          setTarget(progress * FRAME_COUNT);
        };

        const updateScroll = () => {
          if (config.driver !== "scroll") return;
          const maxScroll = Math.max(1, document.documentElement.scrollHeight - innerHeight);
          setTarget(clamp(scrollY / maxScroll) * (FRAME_COUNT - 1));
        };

        const clampPan = () => {
          const maxX = Math.max(
            0,
            (atlasStage.offsetWidth * zoom - atlasViewport.clientWidth) / 2,
          );
          const maxY = Math.max(
            0,
            (atlasStage.offsetHeight * zoom - atlasViewport.clientHeight) / 2,
          );
          panX = clamp(panX, -maxX, maxX);
          panY = clamp(panY, -maxY, maxY);
        };
        const renderZoom = () => {
          clampPan();
          atlasStage.style.setProperty("--zoom", zoom.toFixed(3));
          atlasStage.style.setProperty("--pan-x", `${panX.toFixed(1)}px`);
          atlasStage.style.setProperty("--pan-y", `${panY.toFixed(1)}px`);
          zoomRange.value = String(zoom);
          zoomReset.textContent = `${Math.round(zoom * 100)}%`;
        };
        const setZoom = (next) => {
          zoom = clamp(next, 1, 4);
          if (zoom === 1) {
            panX = 0;
            panY = 0;
          }
          renderZoom();
        };

        const selectSource = (source) => {
          const video = source === "video";
          sourceTabs.forEach((tab) => {
            const selected = tab.id === (video ? "tab-video" : "tab-atlas");
            tab.setAttribute("aria-selected", String(selected));
            tab.tabIndex = selected ? 0 : -1;
          });
          atlasViewport.hidden = video;
          videoPanel.hidden = !video;
          atlasReadout.hidden = video;
          videoReadout.hidden = !video;
          atlasControls.hidden = video;
          videoMeta.hidden = !video;
          if (video) sourceVideo.play().catch(() => {});
          else sourceVideo.pause();
        };

        pageTitle.textContent = config.title;
        document.title = `Oil Motion — ${config.title}`;
        driverSummary.textContent = copy.summary;
        driverLabel.textContent = copy.label;
        hint.textContent = copy.hint;
        formula.innerHTML = copy.formula
          .map((part, index) => `${index ? "<i></i>" : ""}${index === 0 || index === copy.formula.length - 1 ? `<b>${part}</b>` : `<span>${part}</span>`}`)
          .join("");

        const atlasRatio =
          (COLUMNS * config.cellWidth) / (ROWS * config.cellHeight);
        root.style.setProperty("--atlas-ratio", String(atlasRatio));
        root.style.setProperty("--cell-ratio", String(config.cellWidth / config.cellHeight));
        root.style.setProperty("--columns", String(COLUMNS));
        root.style.setProperty("--rows", String(ROWS));
        root.style.setProperty("--cell-pct-x", `${100 / COLUMNS}%`);
        root.style.setProperty("--cell-pct-y", `${100 / ROWS}%`);
        root.style.setProperty("--atlas-image", `url("${config.atlasUrl.replaceAll('"', '\\"')}")`);
        root.style.setProperty("--scroll-height", `${config.scrollPages * 100}svh`);
        atlasImage.src = config.atlasUrl;

        if (config.driver === "scroll") {
          body.classList.add("is-scroll");
          addEventListener("scroll", updateScroll, { passive: true });
        }
        if (config.driver === "drag") {
          previewStage.classList.add("drag-driver");
          previewStage.addEventListener("pointerdown", (event) => {
            dragPreviewId = event.pointerId;
            dragStartX = event.clientX;
            dragStartFrame = clamp(frameValue, 0, FRAME_COUNT - 1);
            previewStage.setPointerCapture(event.pointerId);
          });
          previewStage.addEventListener("pointermove", (event) => {
            if (event.pointerId !== dragPreviewId) return;
            const width = Math.max(1, previewStage.clientWidth);
            setTarget(
              dragStartFrame +
              ((event.clientX - dragStartX) / width) * (FRAME_COUNT - 1),
            );
          });
          const endPreviewDrag = (event) => {
            if (event.pointerId !== dragPreviewId) return;
            dragPreviewId = null;
            if (previewStage.hasPointerCapture(event.pointerId)) {
              previewStage.releasePointerCapture(event.pointerId);
            }
          };
          previewStage.addEventListener("pointerup", endPreviewDrag);
          previewStage.addEventListener("pointercancel", endPreviewDrag);
        }

        addEventListener("pointermove", updatePointer, { passive: true });
        document.documentElement.addEventListener("pointerleave", () => {
          targetDot.classList.remove("visible");
        });
        addEventListener("resize", () => {
          renderZoom();
          updateScroll();
        });

        sourceTabs.forEach((tab) => {
          tab.addEventListener("click", () => {
            selectSource(tab.id === "tab-video" ? "video" : "atlas");
          });
          tab.addEventListener("keydown", (event) => {
            if (event.key !== "ArrowLeft" && event.key !== "ArrowRight") return;
            event.preventDefault();
            const index = sourceTabs.indexOf(tab);
            const next = sourceTabs[(index + 1) % sourceTabs.length];
            next.focus();
            next.click();
          });
        });

        if (!config.videoUrl) {
          videoTab.hidden = true;
          sourceTabs.splice(sourceTabs.indexOf(videoTab), 1);
        } else {
          sourceVideo.src = config.videoUrl;
          sourceVideo.addEventListener("timeupdate", () => {
            const seconds = Math.max(0, Math.floor(sourceVideo.currentTime || 0));
            videoTime.textContent =
              `${String(Math.floor(seconds / 60)).padStart(2, "0")}:${String(seconds % 60).padStart(2, "0")}`;
          });
        }

        atlasViewport.addEventListener("wheel", (event) => {
          event.preventDefault();
          setZoom(zoom + (event.deltaY > 0 ? -0.16 : 0.16));
        }, { passive: false });
        atlasViewport.addEventListener("pointerdown", (event) => {
          atlasDragId = event.pointerId;
          atlasDragX = event.clientX;
          atlasDragY = event.clientY;
          atlasPanX = panX;
          atlasPanY = panY;
          atlasViewport.setPointerCapture(event.pointerId);
          atlasViewport.classList.add("dragging");
        });
        atlasViewport.addEventListener("pointermove", (event) => {
          if (event.pointerId !== atlasDragId) return;
          panX = atlasPanX + event.clientX - atlasDragX;
          panY = atlasPanY + event.clientY - atlasDragY;
          renderZoom();
        });
        const endAtlasDrag = (event) => {
          if (event.pointerId !== atlasDragId) return;
          atlasDragId = null;
          atlasViewport.classList.remove("dragging");
          if (atlasViewport.hasPointerCapture(event.pointerId)) {
            atlasViewport.releasePointerCapture(event.pointerId);
          }
        };
        atlasViewport.addEventListener("pointerup", endAtlasDrag);
        atlasViewport.addEventListener("pointercancel", endAtlasDrag);
        zoomRange.addEventListener("input", () => setZoom(Number(zoomRange.value)));
        document.querySelector("#zoom-out").addEventListener("click", () => setZoom(zoom - 0.25));
        document.querySelector("#zoom-in").addEventListener("click", () => setZoom(zoom + 0.25));
        zoomReset.addEventListener("click", () => setZoom(1));

        setFrame(REST_FRAME);
        renderZoom();
        updateScroll();

        const asset = new Image();
        asset.src = config.atlasUrl;
        const decoded = typeof asset.decode === "function"
          ? asset.decode()
          : new Promise((resolve, reject) => {
              asset.onload = resolve;
              asset.onerror = reject;
            });
        decoded.catch(() => {}).finally(() => {
          loadingCover.classList.add("ready");
          schedule();
        });
      })();
    </script>
  </body>
</html>

````

<!-- ===== FILE: assets/motion-manifest.example.json ===== -->
````json
{
  "version": 1,
  "type": "sprite-atlas",
  "parameterSpace": "circular",
  "frameCount": 240,
  "columns": 16,
  "rows": 15,
  "cellWidth": 240,
  "cellHeight": 240,
  "atlasWidth": 3840,
  "atlasHeight": 3600,
  "initialFrame": 157,
  "startAngleRadians": -2.356194490192345,
  "circular": true,
  "sourceFps": 24,
  "outputFps": 48
}

````

<!-- ===== FILE: assets/step-gesture.ts ===== -->
````ts
export type StepDirection = -1 | 1;

export type StepGestureOptions = {
  threshold?: number;
  idleMilliseconds?: number;
  onStep: (direction: StepDirection) => void;
};

export type StepGestureAdapter = {
  feed(delta: number): void;
  setProgrammaticNavigation(active: boolean): void;
  reset(): void;
  destroy(): void;
};

export function createStepGestureAdapter(
  options: StepGestureOptions,
): StepGestureAdapter {
  const threshold = Math.max(1, options.threshold ?? 40);
  const idleMilliseconds = Math.max(16, options.idleMilliseconds ?? 140);
  let accumulated = 0;
  let lockedDirection: StepDirection | 0 = 0;
  let programmaticNavigation = false;
  let releaseTimer = 0;
  let destroyed = false;

  const clearRelease = () => {
    if (releaseTimer) window.clearTimeout(releaseTimer);
    releaseTimer = 0;
  };

  const reset = () => {
    clearRelease();
    accumulated = 0;
    lockedDirection = 0;
  };

  const scheduleRelease = () => {
    clearRelease();
    releaseTimer = window.setTimeout(reset, idleMilliseconds);
  };

  return {
    feed(delta: number) {
      if (
        destroyed ||
        programmaticNavigation ||
        !Number.isFinite(delta) ||
        delta === 0
      ) return;
      const direction: StepDirection = delta < 0 ? -1 : 1;
      if (lockedDirection === direction) {
        scheduleRelease();
        return;
      }
      if (lockedDirection === -direction) {
        accumulated = 0;
        lockedDirection = 0;
      }
      if (accumulated && Math.sign(accumulated) !== direction) accumulated = 0;
      accumulated += delta;
      scheduleRelease();
      if (Math.abs(accumulated) < threshold) return;
      accumulated = 0;
      lockedDirection = direction;
      options.onStep(direction);
    },
    setProgrammaticNavigation(active: boolean) {
      programmaticNavigation = active;
      if (active) reset();
    },
    reset,
    destroy() {
      destroyed = true;
      reset();
    },
  };
}

````

<!-- ===== FILE: references/alpha-atlas.md ===== -->
````md
# 透明图集路线

仅当 Concept Contract 锁定 `background_owner: page`（主体确有透明复用需求），且
`motion_budget.py` 返回 `delivery.selected=alpha-atlas` 时执行本流程。结果不是
`alpha-atlas` 时停止阅读，改走 [chroma-video.md](chroma-video.md) 或
[baked-video.md](baked-video.md)。

本文档只覆盖图集路线专属的帧提取、清理、检测与打包。公共步骤各有唯一事实源：

- 预算与路线选择：[delivery-selection.md](delivery-selection.md)
- 关键帧、提示词与提交命令：[prompting.md](prompting.md)
- 帧策略与图集压缩：[optimization.md](optimization.md)
- 母版验收、抠图验收、Pilot 与帧链硬门：[qa.md](qa.md)
- 运行时映射：[runtime.md](runtime.md)

## 交付物

```text
motion-name/
├── source/
│   ├── first-frame.png
│   ├── last-frame.png            # 单向转场需要
│   ├── prompt.txt
│   ├── master.mp4
│   └── master.job.json
├── frames/
│   ├── raw/
│   ├── clean/                    # 闭环或尾部清理后
│   └── final/
├── qa/
│   ├── raw-analysis.json
│   ├── raw-contact.jpg
│   ├── final-analysis.json
│   └── final-contact.jpg
└── final/
    ├── motion.webp
    ├── motion.json
    └── implementation.*
```

## 1. 帧准备与离线抠色

母版通过 [qa.md](qa.md) 的母版验收后再提取帧。色键在这一步离线去除，网页只加载已经透明的图集。

`frame_policy=native` 时按源帧提取，`--key auto` 从画面边缘采样实际背景色：

```bash
python3 "$OIL_MOTION/scripts/motion_pipeline.py" extract \
  source/master.mp4 frames/raw \
  --key auto

python3 "$OIL_MOTION/scripts/motion_pipeline.py" analyze frames/raw \
  --output qa/raw-analysis.json

python3 "$OIL_MOTION/scripts/motion_pipeline.py" contact frames/raw \
  --output qa/raw-contact.jpg \
  --columns 8
```

`frame_policy=interpolate` 时改用 [optimization.md](optimization.md) 的插帧命令，它同时输出原始与插帧的接触表和对比报告。

在白、黑和真实页面背景上查看接触表：残留色键、主体内部被误删或边缘溢色时，回到母版或关键帧返工，不靠调阈值掩盖。

## 2. 闭环清理与可选稳定

闭环动画：

```bash
python3 "$OIL_MOTION/scripts/loop_cleanup.py" \
  frames/raw frames/clean \
  --seam-window "$SEAM_WINDOW" \
  --duplicate-threshold "$DUPLICATE_THRESHOLD" \
  --report qa/loop-cleanup.json
```

该工具只做确定性选帧，不生成动作，也不对相邻帧做透明叠加。接缝选错时调整
`--seam-window`，不要为了减少帧数盲目提高重复阈值。首尾不同的单向转场传入
`--end-reference last-frame.png`，裁掉模型在尾帧上的多余停顿。

固定主体存在轻微漂移时才稳定：

```bash
python3 "$OIL_MOTION/scripts/motion_pipeline.py" normalize \
  frames/clean frames/final \
  --anchor bottom \
  --max-scale-change 0.08
```

不需要清理或稳定的步骤直接跳过，把上一步合格的帧作为 `frames/final`。自由运动、镜头运动和真实透视变化禁止稳定。

## 3. 最终门槛与图集打包

```bash
python3 "$OIL_MOTION/scripts/motion_pipeline.py" analyze frames/final \
  --output qa/final-analysis.json

python3 "$OIL_MOTION/scripts/motion_pipeline.py" contact frames/final \
  --output qa/final-contact.jpg \
  --columns 8

python3 "$OIL_MOTION/scripts/motion_pipeline.py" atlas frames/final \
  --output final/motion.webp \
  --manifest final/motion.json \
  --cell-width 360 \
  --cell-height 360 \
  --quality 88
```

打包前用最终帧数和单元格尺寸重新运行 [delivery-selection.md](delivery-selection.md)
的预算。只有仍返回 `alpha-atlas` 且通过时才打包；结果变成 `chroma-video` 时停止打包，
改走视频路线。需要压到目标体积时按 [optimization.md](optimization.md) 执行，不要手动
反复猜 WebP 质量。

## 4. 网页实现

从 [assets/interactive-motion.ts](../assets/interactive-motion.ts) 的对应控制器开始，
映射、阻尼、预加载和降级按 [runtime.md](runtime.md) 执行，验收和故障定位按
[qa.md](qa.md) 执行。出现闪帧时按“母版 → 帧 → 图集 → 映射 → 解码”的顺序定位。

````

<!-- ===== FILE: references/baked-video.md ===== -->
````md
# 烘焙视频路线

仅当 `background_owner: video` 且预算返回 `delivery.selected=baked-video` 时读取。视频包含完整画面；不做抠色、色键或页面背景合成。

## 编译

先完成内容验收和预算，再运行：

```bash
python3 "$OIL_MOTION/scripts/compile_scroll_video.py" \
  "$SOURCE_VIDEO" "$OUTPUT_DIRECTORY" \
  --background-owner video \
  --budget-report build/motion-budget.json \
  --frame-policy "$FRAME_POLICY" \
  --fps "$TARGET_FPS" \
  --timeline-output build/timeline.json \
  --desktop-width "$DESKTOP_WIDTH" \
  --mobile-width "$MOBILE_WIDTH"
```

`FRAME_POLICY` 与 `TARGET_FPS` 来自 Motion Brief。使用 `native` 时目标帧率等于源帧率；使用 `interpolate` 时目标帧率必须更高。

编译器会：

1. 按帧策略保留原始帧或插帧，并输出对应接触表和报告。
2. 按需清理闭环接缝或尾部重复帧。
3. 编码桌面端和移动端全关键帧 MP4，移除音轨。
4. 生成普通 `poster.png` 与 `compile.json`。

多段时间轴用 `--initial-state-id` 指定初始状态，并用重复的 `--segment DESTINATION_STATE_ID=START:HOLD:END_EXCLUSIVE` 传入后续状态与帧边界；需要统一播放曲线时使用 `--playback-curve` 及对应速率参数。编译器负责生成状态映射并把最终保留帧换算成时间。

成功后默认删除可重新生成的中间 PNG；只有诊断帧准备、裁剪或编码问题时才使用 `--keep-frames`。

## 多段连续

`clip_continuity=chain` 时，按 [qa.md](qa.md) 同时执行：

- 上一段实际尾帧作为下一段生成输入；
- 相邻成片解码后的尾帧与首帧接缝验收；
- 身份、构图、光线和背景偏差累积检查。

合并后从最终成片生成 `timeline.json`，不手工抄写段落时间。

“分段”只属于生产过程。交付前必须把连续链编译为每个设备版本各自的一条主视频；运行时不得把生产片段逐段设为 `src`。

## 网页接入

页面只保留一个持续存在的视频元素：

```html
<section class="motion-stage">
  <video class="motion-video" muted playsinline preload="auto"></video>
</section>
```

```css
.motion-stage { overflow: hidden; }
.motion-video { width: 100%; height: 100%; object-fit: cover; display: block; }
```

根据预算中的 `runtime.controller` 接入 [runtime.md](runtime.md)：

- `frame-scrub`：整数帧映射到 `currentTime`。
- `segment-playback`：读取 `timeline.json` 分段播放、反向和精确停帧。
- `autonomous-playback`：按时间播放，仅在素材通过闭环验收时循环。

控制器变化不改变视频背景归属，也不需要重新选择媒体格式。

桌面与移动资源只在会话初始化时选择。分页、反向和普通 resize 期间不换 `src`；确需切换设备版本时，执行一次受控重载并恢复到当前状态的 `hold`，不能把换源当作页面转场。

## 加载与降级

- 预加载 `poster.png` 和首个需要的视频资源。
- 视频解码或资源加载失败时显示 `poster.png`。
- `prefers-reduced-motion` 显示合同指定的静态状态。

## 验收

- 完整观看桌面与移动输出，确认主体、背景、光线、接触关系和镜头连续。
- 多段输出接缝通过 [qa.md](qa.md) 的成片连续性硬门。
- `compile.json` 中桌面与移动输出的 `allFramesAreKeyframes` 为 `true`。
- 实际页面没有抠色、色键 Shader 或阈值配置。
- 按选中的控制器验收 seek、分段播放或自动播放，不混用验收标准。

````

<!-- ===== FILE: references/chroma-video.md ===== -->
````md
# 色键视频路线

仅当 `background_owner: page` 且预算返回 `delivery.selected=chroma-video` 时读取。主体通过 WebGL 实时生成 Alpha，页面拥有最终背景。

如果镜头、环境光、接触阴影、景深或背景连续性属于画面主体的一部分，停止本路线并回到合同改用 [baked-video.md](baked-video.md)。

## 编译

输入必须是从已验收透明关键帧确定性合成、并由视频模型保持均匀的色键母版：

```bash
python3 "$OIL_MOTION/scripts/compile_scroll_video.py" \
  "$SOURCE_VIDEO" "$OUTPUT_DIRECTORY" \
  --background-owner page \
  --budget-report build/motion-budget.json \
  --frame-policy "$FRAME_POLICY" \
  --fps "$TARGET_FPS" \
  --timeline-output build/timeline.json \
  --desktop-width "$DESKTOP_WIDTH" \
  --mobile-width "$MOBILE_WIDTH"
```

需要记录语义锚点时追加 `--anchor NAME=SOURCE_FRAME`；静态降级状态使用 `--poster-source-frame`。索引都基于帧准备后的序列，编译器会在清理后重新映射。

编译器会：

1. 按 `frame_policy` 保留原始帧或插帧，并输出接触表与报告。
2. 按需清理接缝或重复尾帧。
3. 检查整段代表帧的色键颜色与边缘均匀度。
4. 编码桌面与移动全关键帧 MP4。
5. 逐帧模拟运行时抠色，使用与 WebGL 相同的 `dominance-v2` 参数检查残留、误删和溢色。
6. 生成编码后 Alpha 接触表、`background-matrix`、静态 Alpha 降级图和 `compile.json`。

多段时间轴用 `--initial-state-id` 指定初始状态，并用重复的 `--segment DESTINATION_STATE_ID=START:HOLD:END_EXCLUSIVE` 传入后续状态与帧边界。编译器从最终保留帧生成状态映射与 `timeline.json`，页面不得手工换算秒数。

默认删除可重新生成的中间 PNG；诊断帧准备、抠色或编码问题时才使用 `--keep-frames`。

## 抠色硬门

- 编译后的实际 MP4 解码帧仍有可见色键块、边缘溢色、主体内部误删或半透明脏边时，拒收母版。
- 禁止靠扩大抠色阈值、腐蚀轮廓或模糊边缘掩盖素材缺陷。
- 阈值只能复现已验收母版的已知色键，不能修复不均匀背景或错误主体颜色。
- 半透明、发丝和大范围运动模糊属于高风险输入；无法稳定通过时重新生成，或重新评估背景归属。
- 自动报告通过后仍要查看白、黑、高饱和色和真实页面背景上的合成结果。

## 网页接入

使用两个共享实现：

- [assets/interactive-motion.ts](../assets/interactive-motion.ts)：按 `runtime.controller` 控制帧或视频时间。
- [assets/chroma-video-renderer.ts](../assets/chroma-video-renderer.ts)：读取 `compile.json.runtime.keying` 并绘制透明 Canvas。

`frame-scrub` 调用 renderer 的 `render(frame)`。`segment-playback` 或 `autonomous-playback` 在视频按时间播放期间调用 `startLive()`，停止或销毁时调用 `stopLive()`。不要在页面复制 Shader 参数或另写抠色算法。

```ts
const runtime = manifest.runtime;
const renderer = createChromaVideoRenderer({
  video,
  canvas,
  frameCount: runtime.frameCount,
  fps: runtime.fps,
  keying: runtime.keying,
});
```

页面不能直接显示色键视频：

```html
<section class="motion-stage">
  <video class="motion-source" muted playsinline preload="auto"></video>
  <canvas class="motion-canvas"></canvas>
</section>
```

```css
.motion-stage { background: var(--page-background); }
.motion-source { display: none; }
.motion-canvas { width: 100%; height: 100%; display: block; }
```

## 加载与降级

- 预加载静态 Alpha 状态、视频元数据和首个需要的媒体。
- WebGL、视频解码或资源加载失败时显示静态 Alpha 图，不能露出色键母版。
- `prefers-reduced-motion` 显示合同指定的静态 Alpha 状态。

## 验收

- `qa/post-encode-keying.json` 的桌面与移动结果均为 `passed: true`。
- `compile.postEncodeKeyingPassed` 为 `true`，实际检查帧数与报告一致。
- 查看 Alpha 接触表和 `background-matrix`；自动报告不能替代视觉检查。
- `allFramesAreKeyframes` 为 `true`。
- 按实际 `runtime.controller` 检查快速反向、停帧、连续播放或循环。
- 页面更换背景只改变页面层，不重新生成主体。

````

<!-- ===== FILE: references/concepts.md ===== -->
````md
# 交互动画创意方法

当用户询问“可以做什么效果”、只有目标没有动作方案，或现有动画缺少表达目的时读取本文件。

## 从作用开始

先确定动画承担的主要作用，只选一个主作用：

- 引导注意：让用户发现可以交互的对象。
- 解释关系：展示输入、过程、因果、层级或空间关系。
- 表达进度：让连续位置、阶段或完成度可感知。
- 提供反馈：确认悬停、拖拽、提交、成功、失败或等待。
- 奖励探索：让用户主动操作后获得有意义的变化。
- 营造情绪：建立轻快、克制、紧张、柔和或机械的节奏。

没有作用的动作只是装饰。装饰可以存在，但必须低成本、可暂停且不干扰内容。

需要案例时，按作用查阅 [网页动效参考模式](motion-patterns.md)。借用输入与反馈的关系、视觉锚点和信息节奏，再替换成用户自己的对象；不要把参考站的皮肤、题材或实现猜测当作默认方案。

## 先审计对象的运动潜力

不要从“场景视频、绿幕、雪碧图、视差、跟随鼠标”开始。先检查对象本身：

| 维度 | 要问的问题 | 常见变化 |
|---|---|---|
| 结构 | 由哪些层、壳体、部件和连接组成？ | 组装、拆解、爆炸图、剖切、折叠、展开 |
| 功能 | 输入、处理和输出是什么？ | 启动、传递、计算、充能、响应、完成 |
| 材质 | 表面和内部能否改变可见性？ | 透明、X 光、线框、液态、熔化、结晶 |
| 空间 | 用户应该从哪里看到哪里？ | 环绕、推进、拉远、穿越、进入内部、越过尺度 |
| 状态 | 前后状态有什么意义？ | 开关、空满、快慢、新旧、普通与专业模式 |
| 信息 | 哪些关系需要被理解？ | 分流、汇聚、映射、因果、比较、层级、反馈 |

一个手机可以从完整外观变成爆炸图、进入芯片内部、沿信号路径点亮，再重新组装。
一个软件产品可以从界面进入数据管线，展示处理过程后回到结果。例子只说明方法，不是
Skill 的默认题材。

## 动作语法

从下面选择能表达内容的动词，不要把所有变化塞进一条动画：

- 结构：assemble、disassemble、explode、separate、stack、fold、unfold、peel、cutaway。
- 形态：morph、inflate、compress、grow、dissolve、crystallize、flow。
- 材质：reveal、x-ray、wireframe、scan、heatmap、translucent。
- 空间：orbit、dolly、macro、fly-through、tunnel、parallax、scale-jump。
- 信息：trace、route、pulse、branch、converge、compare、highlight。
- 状态：activate、charge、complete、unlock、switch、transform。

## 把输入映射到变化

| 输入 | 连续参数 | 适合的视觉回应 | 参数结构 |
|---|---|---|---|
| scroll | 全页或局部进度、速度 | 拆解、组装、穿越、材质和章节转场 | linear |
| pointer | 方向、距离、速度 | 环绕视角、聚焦部件、剖切深度、光照扫描 | circular / 2d |
| drag | 位移、角度、拉伸量 | 直接拆分、撕开、旋转、比较前后 | linear / 2d |
| touch / orientation | 倾斜、方向、力度 | 重力、内部层差、液体、空间视差 | 2d |
| audio | 音量、频谱、节拍 | 频谱结构、脉冲、形变、排列 | linear |
| data / state | 数值、阶段、成功失败 | 流量、热力、完成度、模式切换 | linear / discrete |

### 转动与视向：先分清转的是什么

“转动 360°”至少对应四种完全不同的素材。合同里只写“转一圈”，模型就会自己挑一个旋转轴，所以先按下表分型：

| 类型 | 画面上发生什么 | 参数空间 | 输入映射 | 典型用途 |
|---|---|---|---|---|
| 圆周注视 | 脸始终朝向镜头，视线沿屏幕前方的一圈移动：12 点抬头、3 点看右、6 点低头、9 点看左，再回到 12 点；不露后脑勺 | circular | 指针相对主体中心的角度 | 吉祥物、头像、数字人跟随光标 |
| 二维注视 | 同样面向镜头，但上下与左右幅度分别变化，指针靠近中心时接近正视 | 2d | 指针的 x、y 分量 | 需要区分“看得多远”的角色 |
| 水平摆头 | 只绕竖直轴左右转，例如 -60° 到 +60°，两端是极限，中间是正视 | linear | 指针 x 或横向进度 | 横向巡视、侧向视差 |
| 展台自转 | 主体绕自身竖直中轴转满一圈，依次露出正面、侧面和背面 | circular | 拖动距离或滚动进度 | 手机、腕表、球鞋等硬件展示 |

圆周注视只用到方向角，指针远近不改变姿态。如果角色在指针靠近时应该接近正视、离远了才明显转头，就要用二维注视，不能拿一条环形视频代替。展台自转会露出侧面和背面：真实产品先用参考图生成 0°、90°、180°、270° 四张关键帧，再分四段生成；只给一张正面图让模型一次转完，背面就是模型猜出来的。

## 一镜到底：先想好接缝藏在哪里

滚动驱动的一镜到底，本质上是多段首尾相接的短视频（`K0 → K1 → K2…`）：上一段的尾帧就是下一段的首帧，每段只完成一级变化。场景切换发生在段内，靠某个一直在画面里的东西把前后两个世界接起来。所以先选“接缝藏在哪里”，再设计关键帧：

| 范式 | 接缝藏在哪里 | 交接关键帧怎么定 | 主要风险 |
|---|---|---|---|
| 尺度穿透 | 画面正中心的锚点物体 | 上一段的尾帧就是下一段的首帧，画面中心的小物体是下一段要推近的目标 | 每段只放大一级；跨度太大时模型会在途中换掉物体 |
| 遮挡转场 | 前景实体完全挡住镜头的那一帧 | 遮挡物占满画幅的同一张图，同时作为上一段尾帧和下一段首帧 | 遮挡不完全时，背景置换会露出来 |
| 形状匹配 | 两个场景里轮廓相同的物体 | 一段以圆形表盘为首帧、以同位置同大小的星球为尾帧，轮廓不动，只换表面内容 | 轮廓在段内移动或变形，就会像硬切 |
| 时间流转 | 锁死的机位和轮廓 | 用同一构图和姿态，生成不同年代或季节的状态图 | 模型容易顺带改几何；关键帧之间逐项对照结构 |
| 倒影穿越 | 眼睛、镜面或水滴里的倒影 | 一段以倒影特写为首帧、以倒影里的场景全景为尾帧，推进中倒影逐渐充满画面 | 特写帧里的倒影要足够清楚，提前生成锁定 |
| 剖切穿墙 | 外墙溶解成剖面或线框 | 完整外墙为首帧，剖开后的内部结构为尾帧 | 推进速度要匀，突然减速会让溶解看起来像卡住 |

整座城市折叠、重力翻转这类大范围形变，当前视频模型很难保持几何连续。只在用户明确要求时尝试，并先用 Pilot 验证。

选定范式后再检查三件事：

- **倒放是否成立。** scrub 模式下用户会往回滚：推进变成拉远，溶解变成复原，这些都自然；爆炸、泼洒这类倒放违反直觉的动作，要单独生成反向片段；分段播放的反向默认也是倒放同一段，同样要检查。
- **停在任意位置是否好看。** scrub 的每一帧都可能成为静止画面，不要靠运动模糊掩盖形变。
- **文字放在哪里。** 需要阅读的说明放在交接关键帧附近的稳定状态上，由页面层叠加，不写进视频。

## 判断语义与几何

- 部件连接、壳体开启、材质形变、关节、抓握、毛发、布料和遮挡属于语义运动，由关键帧约束下的 AI 视频生成。
- 位移、缩放、旋转、裁切、路径、惯性和参数映射属于几何运动，由程序完成。
- 只要移动整张图片会破坏接触或遮挡关系，就生成完整语义动作。

## 按显示尺度选择复杂度

- 小型控件：动作短、轮廓清晰、状态明确，只生成必要的短片段和少量帧。
- 内容插画：允许一个主要语义动作，控制持续时间和资源体积。
- Hero 或全屏叙事：先锁 Concept Contract 的背景归属，再做资源预算；路线选择按
  [delivery-selection.md](delivery-selection.md) 的决策顺序执行。
- 长页面连续滚动：区分全页进度和局部章节进度，不默认把整页映射到一条视频。

## 让三个方向真正不同

方向必须来自对象本身，而不是沿用上一个项目。同一个对象先从结构、空间或镜头、材质或状态三类变化里各想一个方向，再挑出最多三个。用户已经明确动作时，不为凑数量增加无关方向。

三个方向至少在两项上不同：

- 不同驱动方式。
- 不同参数空间。
- 不同表达作用。
- 不同运动主体或结构。
- 不同关键状态或镜头路径。

避免给出三个只是速度、幅度或颜色不同的同类方案。

## 方向卡

每个方向写一张简短的方向卡，方便用户比较和挑选：

1. **表达目的**：用户通过这次交互新理解了什么，或完成了什么。
2. **起止状态与锚点**：起始和最终画面是什么，哪些身份、结构或阅读位置始终不变。
3. **真正变化的部分**：哪些结构、材质或镜头发生变化；镜头移动时写清轨迹。
4. **输入与回应**：输入怎样映射到进度或状态；停手、反向和再次触发时画面怎样回应。
5. **制作分工**：哪些画面由关键帧锁定，哪些变化交给视频模型，哪些文字、布局和状态由程序实现。
6. **成本与替代**：目标尺寸下的清晰度、帧数和加载成本，触屏怎么操作，静态替代是什么，以及最需要先验证的风险。

借用了外部案例时，再写明案例链接、实际看到的现象，以及哪些只是推测，见 [motion-patterns.md](motion-patterns.md)。

## 把方向变成关键帧

需要生成素材时，生产顺序固定为“先生图，再生视频”。每个方向先回答：

1. 起始图是什么。
2. 结束图是什么。
3. 是否需要中间关键帧才能让变化稳定。
4. 哪两张相邻关键帧组成一段视频。

- 真实产品的 Logo、孔位、部件数量和比例不能漂移时，用原始产品图作为参考生成并验收每张关键帧，不让视频模型凭文字猜终点。
- 单段视频只完成一个主要语义变化，例如“整机拆开”或“镜头进入芯片”。
- 多阶段叙事使用 `K0 → K1 → K2…`：先验收全部计划关键帧，再从 Pilot 开始逐段生成视频。
- 文字、数字、进度和高亮由程序在运行时叠加；主要画面与转场仍来自关键帧约束的 AI 视频。

例如“手机完整态 → 爆炸图 → 芯片特写 → 重新组装”需要四张关键帧和三段视频，
不是一条长提示词。这样每段更稳定，也便于滚动正反播放和单独重做。

## 创意质量门槛

拒绝以下方向：

- 用户输入与画面变化没有可理解的关系。
- 动画只有自动播放，没有交互带来的新信息或反馈。
- 静止状态不成立，必须一直运动才能看懂。
- 用高成本栅格视频实现简单几何运动。
- 为了使用已有视频而强行选择不匹配的参数模型。
- 只能在演示尺寸成立，缩小或触屏后失去意义。
- 用赛博霓虹、机械电路、发光细线这类套路装饰填满画面，掩盖结构和镜头上的问题。

选定方向后，把它转换为 Motion Brief，再进入资源预算、生成和实现。

````

<!-- ===== FILE: references/delivery-selection.md ===== -->
````md
# 自动选择交付与运行时

本文件是媒体格式选择的唯一事实源。选择分为三个正交问题，必须依次处理：

1. `background_owner` 决定背景是否烧入媒体。
2. 参数空间、访问方式和资源预算决定媒体格式。
3. `time_control` 决定运行时控制器。

不要用媒体格式推断播放方式，也不要用滚动或分页布局推断 scrub。

## 1. 背景归属

- `video`：背景与主体在同一视频中生成，选择 `baked-video`，不抠色。
- `page`：主体必须透明复用。关键帧直接生成真实 Alpha；需要视频模型时才从透明源合成色键输入，再在 `alpha-atlas` 与 `chroma-video` 中预算。

`--background-owner` 没有默认值。合同未锁定时停止，不得因为参数缺失静默选择透明或色键路线。

## 2. 执行预算

生成素材前用 Brief 的计划帧数（目标帧率 × 时长）运行一次，帧准备完成后再用实际帧数复核：

```bash
python3 "$OIL_MOTION/scripts/motion_budget.py" \
  --frames "$FRAME_COUNT" \
  --display "$DISPLAY_SIZE" \
  --dpr "$TARGET_DPR" \
  --driver "$DRIVER" \
  --time-control "$TIME_CONTROL" \
  --parameter-space "$PARAMETER_SPACE" \
  --background-owner "$BACKGROUND_OWNER" \
  --report build/motion-budget.json \
  --strict \
  --json
```

只有 `driver=scroll` 且 `time_control=scrub` 时才额外传 `--scroll-pages`，用于检查滚动采样密度。分段播放按成片帧率验收，不把页面数量换算成 scrub 帧数。

读取以下结果：

- `delivery.selected`：唯一主媒体格式。
- `delivery.reasonCodes`：选择依据。
- `runtime.renderer`：对应渲染器。
- `runtime.controller`：对应时间控制器。
- `failures` 与 `passes`：阻断项。

## 3. 固定决策顺序：媒体格式

1. `background_owner=video`：选择 `baked-video`。
2. `parameter_space=2d`：选择 `alpha-atlas`；超预算时降低采样或拆分轴后重新预算。
3. `parameter_space=discrete`：每个独立状态或转场分别预算，不把无序状态拼成线性视频。
4. 随机访问且单图集与解码内存均在预算内：选择 `alpha-atlas`。
5. 一维顺序访问且达到视频帧数门槛：选择 `chroma-video`。
6. 一维图集超过纹理或解码内存预算：选择 `chroma-video`。
7. 其余小型透明资源：选择 `alpha-atlas`。

`background_owner=video` 遇到二维或无序离散参数时，拆成多条独立烘焙片段分别预算；不能压成一条时间轴。

## 纹理上限怎么计算

`--max-texture=4096` 限制的是单张纹理的宽和高，不直接限制帧数。预算必须使用
“最大 CSS 显示尺寸 × 目标 DPR”得到最低单格尺寸，再计算单张图集容量：

```text
columns = floor(max_texture / cell_width)
rows = floor(max_texture / cell_height)
capacity = columns * rows
```

例如 48 帧、最低单格 640×640 px 时，4096 纹理只能容纳 6×6=36 帧，不能做成
一张图集。改成 7×7 时单格最多约 585×585 px；使用 576 px 只有在实际显示尺寸
乘 DPR 不超过 576 时才成立，不能为了塞进一张图而牺牲已确认的清晰度。

同理，16×14 排列能否放进一张图只取决于单格尺寸：宽最多 256 px，高最多约
292 px。帧数很多的图集能放进一张图，靠的是更小的单格，不是绕过了浏览器纹理上限。

当前运行时只接受一张主图集。圆环或一维时间轴超出单图集预算时自动选择
`chroma-video`；真正的二维参数仍需要 `alpha-atlas`，超预算时降低参数采样密度、
拆分独立状态或拆分参数轴后重新预算。不要自行实现未经过预算和预加载验收的多图集切换。

## 4. 控制器选择

控制器只由合同中的 `time_control` 决定：

| `time_control` | `runtime.controller` |
|---|---|
| `scrub` | `frame-scrub` |
| `segment-play` | `segment-playback` |
| `autonomous` | `autonomous-playback` |

`delivery.selected` 可以与任一合理控制器组合。例如视频既可以逐帧 scrub，也可以按片段正常播放；图集也可以按时间自动播放。

## 超预算处理

- `alpha-atlas` 超预算：降低采样密度、拆分独立状态，或在用户已确认的显示范围内重新预算；不得偷降清晰度。
- `chroma-video` 被选中：只保留 QA 帧和静态 Alpha 降级，不再生成大型 Alpha 图集。
- `baked-video` 被选中：不得加入抠色、色键 Shader 或页面背景合成。
- 源素材低于最大 CSS 尺寸乘 DPR：重新生成或调整已确认的显示目标，不从低清网页资产反向放大。

任何调整后都重新运行预算，旧报告失效。

### 母版像素不足时的显示预算

视频的可用分辨率见 [prompting.md](prompting.md#分辨率和时长)。预算使用探测到的实际
像素尺寸，通过 `--source WIDTHxHEIGHT` 传入；不能把分辨率标签或放大后的尺寸当作源尺寸。
同时核对宽高与最终裁切，目标 DPR 不得超过
`min(源宽 / CSS 宽, 源高 / CSS 高)`。

例如只有 `1344×768` 母版、最大显示为 `1280×720` CSS px 时，把原先的高 DPR 目标下调为
`--display 1280x720 --dpr 1.05 --source 1344x768`，所需像素为 `1344×756`，
再按上面的预算命令运行 `--strict` 并重写 `build/motion-budget.json`。若保留 DPR `2`，
则把 16:9 显示目标缩小到最多 `672×378` CSS px。编译资源宽度不得超过母版可用宽度。

降低目标 DPR 是素材清晰度取舍，不改变设备的真实 DPR，也不代表在高 DPR 屏幕上达到
原来的清晰度。将调整同步到合同的 `destination` 与 Brief 的 `quality_target`、
`pixel_dimensions`，按新目标重新验收；不得只改预算数值而仍在更大的容器中显示。

## 后续路由

- `alpha-atlas`：读 [alpha-atlas.md](alpha-atlas.md)。
- `chroma-video`：读 [chroma-video.md](chroma-video.md)。
- `baked-video`：读 [baked-video.md](baked-video.md)。
- 控制器实现：读 [runtime.md](runtime.md)。

````

<!-- ===== FILE: references/explainer.md ===== -->
````md
# 动画原理展示页

需要把“母版视频如何变成可交互动画”讲清楚时，使用
`scripts/create_explainer.py` 生成独立 HTML。不要复制某个项目的角色、文案或布局；
页面只读取图集结构和驱动配置。

## 页面包含

- 左侧完整雪碧图，可缩放、拖拽，并高亮右侧真正渲染的帧。
- 可选“母版视频”Tab，用于对照 AI 视频和编译后的网页资产。
- 右侧实时动画、帧号、行列位置和输入映射公式。
- 桌面端 2:1 布局，移动端自动上下排列。
- 图集解码完成后才显示，避免首帧闪烁。

## 驱动方式

| `--driver` | 输入 | 适用素材 |
|---|---|---|
| `pointer-angle` | 指针相对主体的方向 | 环形方向、朝向、旋钮 |
| `pointer-x` | 指针在预览区的横向位置 | 线性姿态、前后对比 |
| `drag` | 横向拖拽距离 | 可抓取产品、逐帧检查 |
| `scroll` | 页面滚动进度 | 章节转场、产品拆解、一镜到底 |
| `autoplay` | 时间 | 待机、循环动作、无需操作的展示 |

`pointer-angle` 使用首尾相连和最短环形距离。其余交互默认是有起止点的线性序列。
自动播放支持 `loop`、`pingpong` 和 `once`。

滚动模式生成前先按 [delivery-selection.md](delivery-selection.md) 运行预算，并传
`--scroll-pages`。预算默认要求每屏至少 24 帧；帧数不够时，长滚动会出现明显的换帧
阶梯，不能只靠调小 `smooth-time` 掩盖。

## 生成

图集 URL 和视频 URL 最终写入 HTML，均以输出 HTML 的目录为基准。manifest 是生成
时读取的本地 JSON，不会在浏览器运行时请求。

```bash
python3 "$OIL_MOTION/scripts/create_explainer.py" \
  --title "一张图，240 个方向。" \
  --manifest final/motion.json \
  --atlas-url ../final/motion.webp \
  --video-url ../source/master.mp4 \
  --driver pointer-angle \
  --output motion-explainer.html
```

没有 manifest 时直接给出网格参数：

```bash
python3 "$OIL_MOTION/scripts/create_explainer.py" \
  --atlas-url ./motion.webp \
  --frames 96 \
  --columns 12 \
  --rows 8 \
  --cell-width 320 \
  --cell-height 320 \
  --driver scroll \
  --scroll-pages 4 \
  --output scroll-explainer.html
```

自动播放：

```bash
python3 "$OIL_MOTION/scripts/create_explainer.py" \
  --atlas-url ./idle.webp \
  --frames 48 --columns 8 --rows 6 \
  --driver autoplay \
  --autoplay-fps 18 \
  --autoplay-mode pingpong \
  --output autoplay-explainer.html
```

输出已存在时脚本默认停止；确认目标后再传 `--force`。

## 验收

1. 通过本地 HTTP 服务打开页面，不只用 `file://`。
2. 检查右侧当前帧与左侧高亮格严格一致。
3. 检查首帧、尾帧、快速反向和环形接缝。
4. 切换视频 Tab 后能播放，切回图集时视频暂停。
5. 滚动模式页面确实有滚动距离，进度能完整覆盖 0 到 1。
6. 在 0%、50%、100% 三个位置检查右侧帧号与左侧高亮严格一致，并快速反向滚动确认没有漏帧或明显阶梯。
7. 在移动端检查布局、触摸拖拽和 reduced-motion 静态降级。

````

<!-- ===== FILE: references/license.md ===== -->
````md
MIT License

Copyright (c) 2026 Lin Zhihuang

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

````

<!-- ===== FILE: references/motion-patterns.md ===== -->
````md
# 网页动效参考模式

## 目录

- [使用方法](#使用方法)
- [按表达目的选方向](#按表达目的选方向)
- [模式卡](#模式卡)
- [把模式编成可验收的方向](#把模式编成可验收的方向)
- [参考采纳门槛](#参考采纳门槛)

## 使用方法

这些模式提供创意参照，不是必须使用的风格或已经交付的运行时能力。只读与当前表达目的相关的两三张卡。

参考资料分为三类证据：**交互实测**指操作过公开页面；**预览观察**指观看过展示录像；**页面说明**指作者或策展页面的描述。录像里的指针、滚动条和按钮不等于能操作的真实页面。案例会更新，复用前重新核对链接与版本；实现建议是模式转译，不代表原站源码。

先分清动作发生在哪一层：

| 层 | 回答的问题 | 生产方式 |
| --- | --- | --- |
| 素材语义 | 身体、结构、材质、遮挡或场景实际发生什么变化？ | 需要生成时，沿现有关键帧、Pilot、媒体预算与时间轴流程执行 |
| 容器编排 | 哪张图成为焦点，窗口怎样放大，文字何时让位？ | 程序控制位移、比例、透视、遮罩和层级；不为这些动作额外生成视频 |
| UI 状态 | 选中了什么，操作处在哪一步，用户能否取消？ | 程序维护真实状态、文本、焦点与事件；动画表现状态，不替代状态 |

只涉及后两层的方向交给普通前端实现，不进入本 Skill 的生图、生视频或 `motion_budget.py`。混合方案只让语义素材进入媒体流水线；没有新增 `delivery.selected` 或控制器枚举。二维模拟、实时三维和语音处理也不能因为有参考案例就宣称现有素材控制器已支持。

## 按表达目的选方向

| 主要目的 | 优先模式 | 主要驱动 | 成本来源 |
| --- | --- | --- | --- |
| 解释同一产品的不同能力 | 01 材质章节、02 表面进入内部 | scroll / state | 关键帧连续性与产品保真 |
| 把注意力交给一个对象 | 03 小窗扩展、04 多图汇聚、06 透视归正 | scroll | DOM 编排、媒体加载 |
| 把零散内容组织成关系 | 05 散点成序、09 关系星图 | scroll / state | 稳定对象标识与阅读顺序 |
| 鼓励主动探索 | 07 贴纸舞台、08 就地预览、12 内容空间 | pointer / drag | 命中、遮挡与移动端替代 |
| 展示多个可比较的选择 | 10 压缩展开 | state / touch | 可读布局与键盘焦点 |
| 让过程和累计变化可感知 | 11 语音状态体、13 使用痕迹 | audio / data / state | 真实数据和状态反馈 |
| 让模式切换具有连续性 | 14 图标共享形态 | state | 语义清晰与精确几何 |

## 模式卡

### 01 同一产品，材质与场景按章节变化

- **参考**：[MotionSites / Cordex](https://motionsites.ai/?prompt=cordex)，预览观察：同一条管状产品以大比例展示，编织材质、应用场景和参数卡发生切换。
- **转译**：把“多个卖点”变成同一对象的多种可见状态，例如外壳保护、内部结构、不同环境适配。机位、主轴和产品轮廓是视觉锚点。
- **输入与状态**：有因果顺序的章节可用 `scroll + scrub + linear`；独立型号选择属于 `state + discrete`，不能假设任意两个型号都有连续视频过渡。
- **制作分工**：AI 素材承担材质、结构和环境变化；型号、参数和选项用 DOM。纯换色能准确计算时直接用程序或真实三维。
- **验收重点**：停在中间也看得懂；参数只随已确认状态切换；反向滚动不把 A 型号说明留在 B 型号画面上。触屏提供章节入口，静态替代展示产品与相应参数。

### 02 从表面进入内部，再回到可解释的整体

- **参考**：[MotionSites / Alethia](https://motionsites.ai/?prompt=alethia)，预览观察：岩石状主体及蓝色表面结构在近景、整体与不同构图间变化。
- **转译**：借鉴“整体—细节”的尺度关系，不复制岩石皮肤。可用于材料孔隙、产品内部或概念系统；真实结构需要原始资料约束。
- **输入与状态**：有起止的推进用 `scroll + scrub + linear`。自由观察或任意绕行则需要二维/三维表示，不能伪装成一条视频。
- **制作分工**：先选始终可辨认的纹理或部件作锚点；生成整体、过渡入口、内部三个关键状态；精确标签由程序跟随已标定位置。
- **验收重点**：微观细节与原对象有可解释的关系，回退能找回原位置；新内容出现前给出阅读空间。移动端可以缩短路径并直接展示局部放大图。

### 03 小窗口扩展成主舞台

- **参考**：[21st / Scroll media expansion hero](https://21st.dev/@arunachalam/components/scroll-expansion-hero)、[Hero Scroll Video Pin Reveal](https://21st.dev/@ajith66310/components/hero-scroll-video-pin-reveal)，公开预览与页面说明。
- **转译**：先让人认出对象，再让媒体窗口扩展，正文随后出现。适合产品演示、案例影片和局部特写进入全景。
- **输入与状态**：窗口尺寸跟随局部滚动；窗口里的视频可以独立按时间播放，也可以另有随动时间轴，两者分别定义。
- **制作分工**：窗口、圆角、文字位移与遮罩由程序处理；已有图像或视频通常足够。镜头真正穿越物体时才进入语义素材生成。
- **验收重点**：扩展前后主体裁切可接受；文字让出焦点；结束后自然接回正文；反向操作恢复原窗口。减少动态效果时直接给最终窗口与正文。

### 04 多图换位，汇聚成一个焦点

- **参考**：[21st / Scroll Choreography](https://21st.dev/@componentry/components/scroll-choreography)，交互实测：四图随滚动改变位置，最后一图覆盖视口，回滚恢复多图布局。
- **转译**：用多个输入汇聚为一个结果，或从候选案例中突出一个主案例。图像的身份连续比路径炫技更重要。
- **输入与状态**：局部 `scroll` 控制“展开—换位—汇聚—突出”；版式有二维坐标，不意味着需要二维视频采样。
- **制作分工**：使用独立图片与 DOM 变换，保留稳定对象标识；最终焦点可接入一段生成的语义动作。
- **验收重点**：突出的是哪张图始终明确；回滚回到各自原位；源图足够清晰；小屏减少同时出现的图数。不要把所有图与文字烘焙进一段视频。

### 05 散点成序：散开、围合、展开为可读路径

- **参考**：[21st / Scroll Morph Hero](https://21st.dev/@prashantsom75/components/scroll-morph-hero)，页面说明：散乱布局变成圆形，再形成滚动驱动的弧形排列。
- **转译**：表现收集、归纳与组织，把原本零散的信息排成有意义的顺序。圆形只是中间构图，不是目的。
- **输入与状态**：可用进入时的一次聚合，加滚动控制的排列变化；先交代自动段何时交还控制权，避免一开始滚动却等动画播完。
- **制作分工**：坐标、角度、缩放、透明度由程序生成；保持每个对象的身份与最终读序。无需为规则排列调用视频模型。
- **验收重点**：聚合后的组织关系比起点更清楚；对象不突然替换；自动引入可跳过；小屏直接呈现有序列表。

### 06 透视陈列归正为可阅读界面

- **参考**：[21st / Container Scroll Animation](https://21st.dev/@manuarora700/components/container-scroll-animation)，页面说明与使用代码：滚动改变容器的三维朝向，内容可是一张界面截图。
- **转译**：开场展示产品的形象，继续浏览时把界面转正，交给用户阅读。适合桌面软件、控制台或设计工具介绍。
- **输入与状态**：局部滚动控制有限角度的透视与比例；这不是产品全周自转，也不是头部注视。
- **制作分工**：CSS 透视和 DOM 变换；界面截图或真实 UI 保持准确。只有设备开合、连接或接触关系真的变化时才增加语义素材。
- **验收重点**：最终正视状态足够长且足够清晰；文字不能永远倾斜；触屏直接展示正视界面，保证后续操作区域的命中正确。

### 07 贴纸舞台与可探索的边缘区域

- **参考**：[MotionSites / Orbit Stickers](https://motionsites.ai/?prompt=orbit-stickers)，预览观察：太空主题贴纸从页脚边缘进入、层叠并改变位置，链接区保持留白。
- **转译**：把品牌资产做成可挑选、可拖动的小物件，用于页脚、空状态或轻量入门。借鉴层次与探索感，不默认继承太空主题。
- **输入与状态**：整片贴纸拖动适合 `drag` 的二维坐标；点击让某个角色发生短语义动作时，角色内部可单独用 `segment-play`。
- **制作分工**：透明静态贴纸配程序变换；只有角色肢体或真实材质发生变化时才生成对应动作。需要碰撞时另外实现物理模拟。
- **验收重点**：装饰不遮挡链接和焦点；拖动能取消、复位；触屏不会把正常页面滚动误当拖拽；静态贴纸组合仍成立。录像没有证明原站物理引擎的存在。

### 08 在探索位置给出预览或光照反馈

- **参考**：[21st / Hover Preview](https://21st.dev/@minhxthanh/components/hover-preview) 的页面说明为文字链接悬停预览；[Spotlight Card](https://21st.dev/@jahed/components/spotlight-card) 提供指针相关视觉反馈的公开演示。
- **转译**：列表保持紧凑，用户关注某项时才显示局部图像；高光用于指出可操作区域或当前观察位置。
- **输入与状态**：指针位置是二维数据，选中的条目是离散状态。不要把二者强行塞进同一个视频进度。
- **制作分工**：预览图、遮罩、高光和避让由程序控制；可搭配已生成的短素材，但不能让浮层接管链接本身的输入。
- **验收重点**：靠近屏幕边缘时不越界；键盘聚焦与触屏点击也能看到同等信息；纯装饰高光关闭后功能完整。

### 09 关系星图：用选择揭示关联

- **参考**：[21st / Radial Orbital Timeline](https://21st.dev/@jatin-yadav05/components/radial-orbital-timeline)，交互实测：选中节点显示状态、说明和关联节点入口，点击关联项能切换详情。
- **转译**：将系统能力、流程阶段或生态连接显性化。轨道布置承担空间组织，选择状态承担信息揭示。
- **输入与状态**：选择节点属于 `state + discrete`；即使节点沿圆周排布，也不能据此设置素材 `parameter_space: circular`。
- **制作分工**：数据节点、连线、标签和焦点由程序维护；中心的品牌物体可独立使用生成素材。真实流程状态来自业务数据。
- **验收重点**：选择后对象易追踪，详情不会随自动公转逃走；关系可被文字或列表表达；小屏有顺序明确的节点列表。不要照搬演示中的随机能量数值。

### 10 压缩邻项，展开当前选择

- **参考**：[21st / Squeeze Carousel](https://21st.dev/@yura/components/carousel-squeeze)，页面说明与使用代码：一项宽幅展示，其他项收为细条；演示配置关闭自动轮播。
- **转译**：在有限空间里保留“还有哪些选项”的空间线索，同时集中展示当前产品或案例。
- **输入与状态**：点击、触屏或键盘选择离散项；布局动画跟随所选项，不让自动轮播擅自改变正在阅读的内容。
- **制作分工**：DOM 布局与裁切；只有当前项需要动态展示时才加载素材。主体定位按每张图片单独设定。
- **验收重点**：压缩后仍可识别和选择；焦点不因宽度变化丢失；小屏用可读标签或列表替代极细点击条；减少动态效果时直接换布局。

### 11 语音状态体：把真实输入转成反馈

- **参考**：[21st / Voice Powered Orb](https://21st.dev/@isaiahbjork/components/voice-powered-orb)，作者说明与使用代码：WebGL 球体按音频强度改变视觉表现；真实麦克风链路需另行验证。
- **转译**：为语音助手区分空闲、聆听、处理中、输出和错误。音量只能表达输入活动，不能冒充任务完成进度。
- **输入与状态**：业务状态决定模式，音频包络影响有限的强度参数。拒绝授权、静音和断流都必须有明确状态。
- **制作分工**：信号处理、颜色、强度或 shader 由程序执行；生成素材仅用于有意义的形体状态，不尝试预烘焙任意频谱。
- **验收重点**：无声音时不假装收到输入；用户启动后才请求麦克风；停止后结束采集；文本状态在无动画时依然可读。参考组件存在不等于已支持整条语音链路。

### 12 把内容集合变成空间，再回到具体任务

- **参考**：[Cosmos 官网](https://www.cosmos.so/)，当前页面观察：图片围绕首屏文案分布，后续章节介绍集合、颜色搜索、相似图与来源信息；[Godly 历史收录](https://godly.website/website/cosmos-978) 仅作出处线索。
- **转译**：用内容对象本身建立空间感，然后让它们服务于搜索、归类或溯源。适合素材库、知识库和研究工具。
- **输入与状态**：首屏可有轻量自动运动；关键交互使用真实搜索或明确标为演示的输入。滚动负责章节揭示，不能伪造真实搜索结果。
- **制作分工**：图片卡与 UI 用程序；可把一张选中的图接入语义动画，但不需要把整个内容库做成视频。
- **验收重点**：标题、搜索与 CTA 保持稳定；背景卡片不抢焦点；产品能力在静态页面中也说得清。历史收录和现行官网不是同一版本证据。

### 13 使用痕迹：累计行为变成可见材质

- **参考**：[Recent / Aging Button](https://recent.design/i/a06z03e-aging-button-microinteraction)，策展说明与预览：按钮随着点击次数增加出现磨损和脏污。
- **转译**：把次数、使用历程或里程碑变成对象状态，例如徽章抛光、工具磨损或植物成长；只用于变化具有产品意义的地方。
- **输入与状态**：输入是累计数据，状态映射必须可复现；不是“等待越久随机变脏”。跨次访问是否保留由业务需求决定。
- **制作分工**：简单纹理混合用程序；复杂生长或老化可生成少量明确关键状态与相邻转场。数值、历史与重置由程序管理。
- **验收重点**：磨损不影响按钮文字和可用性，不使人误以为损坏或禁用；清楚区分“保存成功”与“累计变化”。普通高频操作不必每次演出。

### 14 共享几何形态，让状态切换有来有去

- **参考**：[Recent / 3-in-1 Icon Morph](https://recent.design/i/t36wysw-3-in-1-icon-morph)，预览观察：多个状态图形的线、点和轮廓重组成一个符号；策展账号标签不视为原作者证明。
- **转译**：为展开/收起、组合/拆开或模式切换保留共同几何锚点，让用户看出新状态从何而来。
- **输入与状态**：业务事件选择目标状态；快速反向应从当前几何状态继续，不先跳回起点重播。
- **制作分工**：SVG 或 DOM 精确控制线段、点和遮罩；功能图标与文字不交给视频模型绘制。语义完全不同的状态可以直接替换，不强求变形。
- **验收重点**：最终符号没有丢失必要状态信息；读屏名称同步更新；缩小后仍清晰；减少动态效果时直接切换到最终符号。

## 把模式编成可验收的方向

方向卡的格式以 [concepts.md](concepts.md) 的“方向卡”为准，最多提出三个方向。借用本库的模式时，在卡上补一项“参考与证据”：案例链接、实际看到的现象，以及哪些只是建议或推测。

把节奏写进 Brief 现有的 `storyboard` 与 `rest_state`；运行时规则仍以 [runtime.md](runtime.md) 为准。不要从参考卡增加一套重复的合同、时间轴或预算字段。

## 参考采纳门槛

- 先认出对象，再发生变化；一次转场只突出一个主要结果。文案需要阅读时，为主动作安排可读状态，不机械套用某个网站的固定秒数。
- 至少比较静态初始态、变化中、静态结束态。连续输入还要检查停手与反向；只看开场录像不足以证明交互成立。
- 参考提炼为“输入—视觉回应—信息作用”，再替换题材；不把霓虹、玻璃、粒子或巨大文字当成创意本身。
- 原站源码、访问权限或性能数据不可见时，不推断其生成模型、框架、内存占用或移动端质量。安装组件前另查当前依赖与具体许可。
- 不照搬参考提示词中的整页滚动映射、固定帧数、固定 DPR 或强制滚动锁定；这些选择回到用户的内容、宿主容器与现有预算流程。
- 素材首次就绪前保留可读页面；加载交接保持同一视觉状态；装饰失败不能阻断导航。

素材质量与连续性验收仍使用 [qa.md](qa.md)。本参考库的作用是帮助选对方向，不替代 Pilot 或目标设备验证。

````

<!-- ===== FILE: references/optimization.md ===== -->
````md
# 帧策略与图集压缩

本文件是 `frame_policy` 和图集清晰度预算的唯一事实源。先验收动作母版，再决定是否插帧；插帧不是默认正确答案。

## 选择帧策略

使用 `native`：

- 源帧率已经满足最终正常播放；
- 原始节奏、停顿或逐帧绘制感属于视觉设计；
- 插帧会产生重影、双轮廓、线稿扭曲或结构错误。

使用 `interpolate`：

- scrub 的参数采样明显不足；
- 目标播放速度下原始帧率可见跳步；
- 插帧结果通过自动比较和人工接触表验收。

把决定写入 Motion Brief：

```yaml
frame_policy: native | interpolate
target_fps: <native 使用源帧率；interpolate 必须高于源帧率>
```

## 插帧流程

只有 `frame_policy=interpolate` 时执行：

```bash
python3 "$OIL_MOTION/scripts/optimize_motion.py" interpolate \
  "$SOURCE_VIDEO" "$OUTPUT_DIRECTORY" \
  --fps "$TARGET_FPS" \
  --key "$KEY_MODE"
```

同时检查原始与插帧接触表。新增重影、双轮廓、边缘撕裂、部件穿插、结构扭曲、亮度闪帧或中心突变时，插帧失败；改用合格的原始帧，或重新生成母版，不得把插帧伪影带入编译。

`frame_policy=native` 仍需输出原始帧接触表和分析报告，只是不生成虚构中间帧。视频路线由 `compile_scroll_video.py --frame-policy` 统一执行对应分支；图集路线的原始帧提取见 [alpha-atlas.md](alpha-atlas.md)。

## 裁剪与拼接

- 裁剪只删除确实无变化的重复区，不改变已验收动作的终点。
- 每次裁剪或拼接后，重新检查所有新产生的相邻帧。
- 不能删除一段缓慢变化，再把远处最终帧直接接回；需要保留到终点的连续采样。
- 时间轴锚点和 `hold` 必须从最终保留帧重新生成。

## 图集压缩

只有预算选择 `alpha-atlas` 时执行：

```bash
python3 "$OIL_MOTION/scripts/optimize_motion.py" atlas "$FINAL_FRAMES" \
  --output "$OUTPUT_ATLAS" \
  --target-mb "$TARGET_MIB" \
  --display "$DISPLAY_SIZE" \
  --dpr "$TARGET_DPR" \
  --cell-width "$CELL_WIDTH" \
  --cell-height "$CELL_HEIGHT" \
  --columns "$COLUMNS"
```

工具先按“最大 CSS 尺寸 × DPR”计算最低单帧像素，再在不低于该尺寸的前提下搜索压缩质量。`clarityMet` 必须为 `true`；`targetMet=false` 时回到 [delivery-selection.md](delivery-selection.md) 重新预算，不继续降低清晰度。

## 验收

- `native`：接触表、相邻帧分析和最终播放均通过。
- `interpolate`：原始与插帧接触表均通过，且插帧没有新增结构或边缘缺陷。
- 最大显示尺寸和目标 DPR 未确认前，不执行最终压缩。
- 文件体积、解码内存和纹理尺寸同时满足目标设备预算。

````

<!-- ===== FILE: references/prompting.md ===== -->
````md
# 关键帧与视频提示词（Open Design 适配）

使用当前宿主的图片／视频工具，不要求 ZenMux，不调用外部凭据页或上游 image_job/video_job 脚本。已有视频或序列帧跳过生成。先检查工具是否支持参考图、首尾帧、透明通道和所需画幅；不支持时不能假装约束已满足。

按任务的真实容器锁定比例、尺寸和裁切策略；用已验收 K0/K1 约束一段连续变化。每段只承担一种主要变化。连续片段的第二段起使用上一段实际尾帧，并保留任务元数据。用实际解码结果核对时长、分辨率与帧数，不把请求值当作结果。先把第一段放入真实页面检查，再批量生产；宿主不允许额外验证时记录未验证项。

生成调用的字段、模型和权限遵循当前宿主工具定义，以下是可移植的构图与动作提示词，不是服务 API 参数。

## 通用身份锁定段

有角色时，先把 Identity Bible 的身份锚点（脸型五官、发型发色、服装配色、标志物、
体型比例、风格线条）写进这段，再放在动作描述前，并替换尖括号：

```text
Use the supplied first and last frames as the exact identity and design
references for <SUBJECT>. Preserve the same silhouette, anatomy, face, clothing or product
geometry, colors, line work, texture, and proportions in every frame. The
subject remains the same size and at the same anchored position throughout the
shot. Do not add, remove, duplicate, or redesign any body part, accessory,
feature, logo, control, or prop.
```

如果主体是插画，补充：

```text
Preserve the original illustration style exactly. Keep line thickness,
halftone texture, flat color regions, and edge sharpness consistent. Do not
turn the subject into volumetric CGI, photorealistic, painterly, or glossy imagery.
```

## 固定镜头段

```text
Locked camera and locked framing. No camera pan, tilt, zoom, orbit, shake,
reframing, perspective change, lens change, depth of field, or lighting change.
The body and contact point remain fixed. Only <ALLOWED_PARTS> may move.
```

只有镜头运动本身需要被滚动控制时才删除这段，并明确描述镜头轨迹。

## 场景背景段（baked 路线）

仅当 Concept Contract 锁定 `background_owner: video` 时使用。场景、环境光、地面
接触和景深就是要烧进视频的内容，必须明确锁定，保证多段之间连续：

```text
The scene is <SCENE_ANCHOR> with <LIGHTING> and <GROUND_CONTACT>. Keep the
environment, light direction, color temperature, ground contact, shadows, and
depth of field identical and continuous across the entire shot. The background
is part of the final picture: no chroma key, no flat color backdrop, no
background replacement, and no transparency.
```

多段叙事时，这一段在每条提示词中原样复用，并把上一段验收后的实际尾帧作为下一段
首帧输入。

## 视频色键段（page 路线）

仅当 Concept Contract 锁定 `background_owner: page` 时追加到视频提示词，图集和色键视频两条路线都用它。
首尾关键帧先由宿主支持透明输出的图片工具生成透明 PNG，再由
`composite_alpha_keyframe.py` 合成为视频输入；不要把这段用于图片提示词。默认 `#00FF00`，主体含绿色时改用 `#FF00FF`。

```text
The entire background is one perfectly uniform flat chroma-key <KEY_COLOR>
rectangle in every frame. No gradient, texture, noise, floor plane, horizon,
shadow, reflection, glow, particles, color variation, or lighting falloff on
the background. Keep the subject fully separated from all image borders with
generous padding. No cast shadow. No green/magenta object or reflected spill on
the subject. No text, subtitle, watermark, border, or UI.
```

模型未必严格生成指定色值，所以最重要的是四周和时间维度保持均匀。后续脚本会从边缘采样真实背景色。

## 转动与视向提示词

先按 [concepts.md](concepts.md) 的四种类型确认要转的是什么，再选下面的写法。

### 圆周注视

脸始终朝向镜头，视线沿屏幕前方的一圈顺时针移动，不能转出后脑勺：

```text
Create one continuous clockwise head and gaze rotation cycle. The face and eyes
of <SUBJECT> remain oriented toward the camera at all times; do not rotate around
to show the back of the head. An invisible target moves smoothly clockwise in a
circle on the front screen plane (12 o'clock looking up, 3 o'clock looking
right, 6 o'clock looking down, 9 o'clock looking left, returning cleanly to 12
o'clock). <SUBJECT> follows the target smoothly within a natural cone of vision,
tilting and rolling its head without leaving the front-facing half-sphere. Pass
through every intermediate angle at a constant rate without pausing or snapping.
End exactly at the first frame pose for a seamless loop. Keep torso and position
completely stationary. No blinking, idle sway, or deformation.
```

运行时用 `atan2(y, x)` 把指针方向映射到角度。

### 二维注视

见下文[指针二维动画](#指针二维动画)的二维采样。

### 水平摆头

只绕竖直轴转，不闭环：

```text
Move once continuously from looking left (-60 degrees) through center to
looking right (+60 degrees). Do not loop, do not return to start, and do not
pause at intermediate angles. Head turns only on the horizontal yaw axis; locked
vertical pitch, locked camera, locked scale, locked center anchor.
```

### 展台自转

真实产品的侧面和背面不能交给模型猜。先用产品参考图生成 0°、90°、180°、270° 四张关键帧，
再按 `K0 → K1 → K2 → K3 → K0` 分四段生成，每段转 90°：

```text
Use the supplied first and last frames as the exact geometry, material, color,
logo, control, and proportion references. Rotate the product clockwise around
its vertical center from the angle of the first frame to the angle of the last
frame at a constant angular speed. Locked orthographic-like camera, fixed scale,
fixed center, fixed lighting, no perspective breathing, no added details, no
deformation, no text changes, no logo changes.
```

只有背面不重要的小型物件，才用一张正面图配 `--loop-frame` 一次转完。

## 一镜到底连续镜头提示词

范式和交接关键帧的定法见 [concepts.md](concepts.md)。每段只负责一级变化，首尾帧就是交接关键帧。
所有范式共用一个骨架，只替换镜头句和范式句：

```text
Use the supplied first and last frames as exact composition anchors.
<CAMERA_CLAUSE> <PARADIGM_CLAUSE> No cuts, dissolves, jump pans, rotational
drift, or sudden speed changes. Arrive exactly at the framing, scale, and
alignment of the last frame. Every intermediate frame must read clearly when
playback stops.
```

镜头句：推进用 `The camera moves forward in one uninterrupted dolly at a steady speed toward <TARGET>.`；
机位不动用 `The camera stays completely locked.`

| 范式 | `<PARADIGM_CLAUSE>` |
|---|---|
| 尺度穿透 | `The center subject <TARGET> stays exactly at the center while the surroundings expand past the frame edges, passing through <INTERMEDIATE_LAYERS>.` |
| 遮挡转场 | `A large foreground <OCCLUDER> crosses the lens and fills the entire frame by the last frame. Exposure stays constant.` |
| 形状匹配 | `The <SHAPE> outline keeps exactly the same screen position and size while its surface transforms from <SUBJECT_A> into <SUBJECT_B>.` |
| 时间流转 | `Only materials and lighting change, continuously from <STATE_A> to <STATE_B>; silhouette, geometry, and perspective never change.` |
| 倒影穿越 | `The camera pushes into the reflection on <REFLECTIVE_SURFACE>; the reflected scene grows sharper until it fills the frame as the real scene of the last frame.` |
| 剖切穿墙 | `As the camera reaches the wall of <STRUCTURE>, the surface dissolves into a clean cutaway that reveals <INTERIOR>, without slowing down.` |

## 产品拆解与爆炸图

先根据真实产品参考图分别生成完整态和爆炸态图片。两张图都通过人工验收后，再作为精确首尾帧；
不要让视频模型凭文字发明最终结构。

```text
Use the supplied first and last frames as exact geometry, identity, material,
logo, component-count, alignment, camera, lighting, and composition references.
Create one continuous transformation from the fully assembled <PRODUCT> to the
approved exploded view. Separate the existing shell, display, battery, boards,
connectors, cameras, and fasteners only along their physically plausible axes.
Preserve every component's exact shape, scale, orientation, color, and relative
order. Keep all parts readable and non-overlapping at the final state. No new,
missing, duplicated, melted, or redesigned components. No cuts, camera changes,
scale breathing, motion blur, labels, or unrelated motion. Every intermediate
frame must be a stable reversible assembly state suitable for scroll scrubbing.
```

爆炸方向、间距、部件数量和最终构图必须先在尾帧图片中确定。视频负责从完整态连续过渡到
该尾帧；文字标注、数字和部件高亮在生成后由程序覆盖，避免 AI 视频生成不稳定文字。

## 镜头穿越

镜头运动本身是交互内容时，不使用固定镜头段，改为明确一条可逆轨迹：

```text
Create one continuous forward camera move from <START_VIEW> to <END_VIEW>.
Follow the supplied path through <ORDERED_LANDMARKS> without cuts, orbiting,
sideways drift, speed jumps, focus pumping, or lens changes. Keep product
geometry, lighting, scale relationships, and landmark positions consistent.
Every frame must remain sharp and readable when scroll playback stops. The
reverse frame order must also form a natural backward move.
```

长距离穿越不要只给起点和终点。先生成路径上的中间关键帧，保证主体、空间地标、比例和风格
一致，再把相邻关键帧分别生成短视频。

## 多段关键帧串联

先建立 `K0 → K1 → K2…Kn`：

- 第 `i` 段以 `Ki` 为首帧、`Ki+1` 为尾帧；`chain` 模式下第 2 段起的首帧换成上一段的实际尾帧。
- 所有关键帧复用同一组参考图、画幅、风格约束、主体比例和场景设定。
- 每段只写一个主要变化。
- 拼接后逐帧检查接缝；若接缝不稳，重做对应短片，不重做整条时间轴。

实际尾帧接力、SHA-256 校验和误差累积处理按 [qa.md](qa.md) 的“连续帧链”执行。

## 指针二维动画

二维输入不能只靠一条左右转头视频准确表达。优先选择以下方案：

### 方案 A：角度足够

指针远近不影响姿态时，用[圆周注视](#圆周注视)生成完整方向环。距离只影响平滑速度或回正强度。

### 方案 B：二维采样

生成固定网格中的多个短片或关键姿态，例如：

```text
Generate the same subject and framing for target position <X_POSITION>,
<Y_POSITION>. Keep the exact body anchor, subject scale, lighting, style, and
background used in every other grid sample. Move only <ALLOWED_PARTS> toward
that target and settle naturally. No entrance or exit motion.
```

二维网格至少覆盖左上、上、右上、左、中、右、左下、下、右下。用程序统一锚点和尺寸，再做双线性邻域选择或插值。不要要求模型在一条视频中遍历网格后直接随机访问。

## 逐帧 scrub 时间轴

适合产品拆解、页面叙事、图表展开和场景变换：

```text
Create a single continuous transformation designed for frame-by-frame scroll
scrubbing. At frame 0, <START_STATE>. Over the shot, <ORDERED_CHANGES>. At the
last frame, <END_STATE>. Every intermediate frame must be a meaningful stable
progress state. Use constant visual continuity with no cuts, dissolves, sudden
jumps, duplicated holds, camera shake, motion blur, or unrelated motion. Keep
the composition readable when playback is stopped on any frame.
```

把多个变化写成相对进度阶段，例如 `0–35%` 完成第一阶段、`35–80%` 推进主要关系、
`80–100%` 到达最终状态。要求每个阶段持续变化，并明确禁止模型在前段快速完成主要
动作、后段只保留近重复帧。百分比用于约束节奏，不要求模型输出精确帧编号；实际节奏
仍需通过接触表检查，必要时裁剪或重定时。

scrub 序列的目标帧率由帧密度和画质验收决定。优先生成清晰的语义关键阶段，再按
[optimization.md](optimization.md) 选择保留原帧或插帧。

## 分段播放转场

适合输入触发后按时间完成、并在状态锚点停住的片段：

```text
Create one uninterrupted transition from the exact provided first frame to the
exact provided last frame. Begin the intended motion immediately, preserve all
identity, structure, framing, background, and lighting constraints throughout,
and reach the final state only at the end. No cut, dissolve, unrelated idle
motion, early completion, long final hold, or return motion.
```

每段只描述一个方向的主要变化。运行时反向通常复用同一段；只有倒放违反物理或叙事规律时，才另外生成反向片段。

## 离散状态动画

每个状态单独生成，不让一个长视频同时包含 hover、点击、成功和失败：

```text
Create a short transition from the exact neutral pose to the exact <STATE>
pose. The first frame must match the shared neutral reference exactly. Hold the
final pose only briefly. No camera movement, no unrelated idle motion, and no
return transition.
```

反向状态优先用程序倒放；只有倒放不符合物理规律时再单独生成。

## 失败修复提示词

一次只修一个问题，同时重申所有不变量：

```text
Keep the subject identity, design, style, camera, framing, scale, anchor,
background, lighting, and correct motion unchanged. Fix only this issue:
<ONE_PRECISE_ISSUE>. Do not add any new motion or detail.
```

常见修复：

- `Keep every approved component unchanged; remove the duplicated connector.`
- `Keep the body fixed; eliminate scale pulsing and center drift.`
- `Remove the one-frame brightness flash; lighting is identical in every frame.`
- `Continue through the angle without pausing or snapping.`
- `Make the last frame match the first frame exactly for a seamless loop.`

## 负面约束

按需要加入，不必机械复制全部：

```text
No cuts, morphing, identity drift, scale breathing, position drift, duplicated
limbs, missing limbs, extra objects, blinking, idle sway, motion blur, ghosting,
frame blending, lighting flicker, shadows on the background, camera movement,
text, watermark, border, style change, unnecessary sci-fi circuitry, or plastic AI clutter.
```

用户没有要求科幻题材时，不写 `cyberpunk`、`neon glow`、`intricate circuitry`、
`hyperdetailed 8k` 这类套路词，也不要用满画面的细碎发光线条充当细节。画面冲击力来自镜头、
形态对比和干净的轮廓；细节只服务于叙事焦点，非焦点区域保持干净。需要时追加：

```text
No unnecessary sci-fi circuitry, generic cyberpunk neon clutter, plastic AI
noise, over-detailed artificial lines, or visual noise.
```

````

<!-- ===== FILE: references/qa.md ===== -->
````md
# 质量检查与生产硬门

本文档是 Pilot、连续帧链和最终验收的唯一事实源。检查顺序固定为：用户意图 → 关键帧 → 母版 → 帧准备 → 媒体编译 → 时间轴 → 真实页面运行时。上游失败时停止，不在下游掩盖。

## Concept Contract 回归

每次验收先逐项对照合同：

- 主体数量、身份和关系一致。
- 风格、情绪、动作和叙事形式保持用户原意。
- `background_owner=video` 的成品没有抠色；`page` 的成品没有烧入页面背景。
- `driver`、`time_control` 和 `navigation` 分别符合要求。
- `clip_continuity` 与 Pilot 批准一致。

任一项偏离都属于需求级错误，必须返工；不接受“差不多”。

## Identity Bible

有角色或稳定身份对象时，逐张关键帧和逐段母版检查：

- 同脸或同一识别特征；
- 发型、服装、材质和配色一致；
- 配饰、标记、零件和道具不增不减不错位；
- 比例、锚点和主要轮廓没有无意漂移。

## 透明关键帧

`background_owner=page` 时，原始关键帧必须是直接生成的真实 Alpha PNG：四角透明，没有实体底色或棋盘格，主体边缘在浅色和深色测试底上均干净。宿主图片工具返回结果后，实际检查 Alpha 通道、四角和可见主体；边缘质量仍要放在测试底上看。

视频模型需要色键时，只能从已验收透明源确定性合成副本，并保留源文件对应关系。不得生成色底图片再反向抠图。

## Pilot 硬门

批量生成前必须具备：第一组关键帧、第一段短视频、真实页面最终位置挂载、明确的视觉验收结论。通过后生成 `pilot/approval.json`：

```bash
python3 "$OIL_MOTION/scripts/production_gate.py" approve-pilot \
  --contract source/concept-contract.yaml \
  --identity-bible source/identity-bible.md \
  --first-frame "$FIRST_FRAME" \
  --last-frame "$LAST_FRAME" \
  --video "$PILOT_VIDEO" \
  --page-evidence "$PAGE_EVIDENCE" \
  --reviewer "$REVIEWER" \
  --decision pass \
  --output pilot/approval.json
```

批准文件记录工件 SHA-256 和合同中的连续模式。生产阶段必须验证批准文件与工件未变化；任何变更都会使批准失效。

## 连续帧链

`clip_continuity=chain` 必须通过两道不同硬门。

### 1. 生成输入接力

上一段验收后的实际尾帧必须作为下一段首帧的原文件：

```bash
python3 "$OIL_MOTION/scripts/production_gate.py" verify-chain \
  --previous-tail "$PREVIOUS_TAIL" \
  --next-first "$NEXT_FIRST_INPUT" \
  --segment-index "$SEGMENT_INDEX" \
  --manifest qa/frame-chain.json
```

这一步验证生成请求没有换图，但不能证明模型输出首帧没有重绘。

### 2. 成片输出接缝

下一段生成完成后，再比较上一段成片解码尾帧与下一段成片解码首帧：

```bash
python3 "$OIL_MOTION/scripts/production_gate.py" verify-output-chain \
  --previous-video "$PREVIOUS_VIDEO" \
  --next-video "$NEXT_VIDEO" \
  --segment-index "$SEGMENT_INDEX" \
  --manifest qa/frame-chain.json \
  --evidence-dir qa/frame-chain-evidence
```

自动相似度通过后仍要查看证据帧，确认身份、构图、光线和背景没有可见跳变。再把实际尾帧与计划关键帧比较；偏差超限时重做当前段或更新后续约束，不允许误差逐段累积。

## 母版

- 完整观看，不只看首尾截图。
- 主体身份、结构、颜色和数量稳定。
- 动作没有硬切、无意反向、长时间待机或错误终点。
- 镜头、透视、光线和接触关系符合合同。
- 闭环素材首尾真实连续。
- `page` 路线的色键背景均匀；烘焙路线的背景与主体一起连续。

## 帧准备

`frame_policy=native`：

- 查看原始接触表和相邻帧分析。
- 在目标播放速度下确认节奏和清晰度。

`frame_policy=interpolate`：

- 同时查看原始与插帧接触表。
- 插帧不得新增重影、双轮廓、边缘撕裂、结构扭曲、穿插或闪帧。
- 失败时回到合格原始帧或重新生成，不把插帧当成强制交付条件。

任何裁剪和拼接都必须检查新产生的相邻帧；不能用远距离末帧替代被删除的缓慢变化。

## 媒体编译

- 输出像素至少覆盖最大 CSS 尺寸乘目标 DPR，不超过母版可用分辨率。
- 图集帧数、行列和实际文件一致。
- 视频帧率、帧数、全关键帧状态和 `compile.json` 一致。
- 色键路线按 [chroma-video.md](chroma-video.md) 验收编码后抠色和多底色矩阵。
- 烘焙路线按 [baked-video.md](baked-video.md) 验收完整画面，不得出现色键处理。

## 时间轴

`timeline.json` 必须由最终编译结果生成，并验证：

- [runtime.md](runtime.md) 定义的时间轴硬性语义全部通过。
- 页面状态 ID、顺序和 `timeline.json.states` 完全一致；缺失、重复或错序时初始化失败。
- 重新裁剪、拼接或编码后旧时间轴失效。
- 播放曲线参数来自清单，页面没有第二份常量。

## 运行时验收

所有模式都检查：

- 冷缓存、慢网、资源失败和 `prefers-reduced-motion`。
- 目标 CSS 尺寸、DPR、浏览器 100% 缩放和移动端。
- 窗口变化、页面切后台再恢复、快速连续输入。
- 媒体节点不重复创建，降级时不露出色键或半成品。

`frame-scrub`：

- 慢速、快速、跳转和连续反向都能到达正确帧。
- 输入停止时画面停在对应位置，不粘滞、不越界。

`segment-playback`：

- 输入发生后立即开始，不等待页面导航结束。
- 连续链使用同一媒体实例，不在状态间换源。
- 反向输入从当前画面撤回。
- 每段停在 `hold`，没有越过目标后回跳。
- 快速重复输入只执行最新目标，旧播放已取消。
- 同一次惯性手势不会连续跳过多个状态；程序化页面滚动不会反向触发媒体控制器。
- 首尾边界按 `gesture_policy.boundary` 停止或闭环，不产生空状态。

`autonomous-playback`：

- 浏览器阻止自动播放时有明确降级或启动手势。
- 只有通过闭环验收的素材才循环。

## 故障定位

- **闪帧或切帧**：依次检查母版、裁剪接缝、成片输出接缝、`hold/endExclusive`、旧媒体层和资源解码。
- **动作粘滞**：检查是否重复平滑、目标是否及时更新、seek 是否串行堆积。
- **停下后回跳**：检查是否用 `timeupdate` 判断、是否停在 `endExclusive`、是否先越界再回设。
- **新版本变糊**：检查母版分辨率、插帧伪影、重复缩放、图集单元格和有损压缩。
- **色键残留**：检查母版和编码后实际帧；不得先扩大运行时阈值。

````

<!-- ===== FILE: references/runtime.md ===== -->
````md
# 运行时控制

本文档是时间控制、输入映射、预加载和运行时性能的唯一事实源。媒体格式由
[delivery-selection.md](delivery-selection.md) 决定；两者独立。

## 先读预算结果

`build/motion-budget.json` 必须分别给出：

- `delivery.selected`：使用哪种媒体和渲染器。
- `runtime.controller`：输入如何控制媒体时间。

| `time_control` | `runtime.controller` | 行为 |
|---|---|---|
| `scrub` | `frame-scrub` | 输入值持续映射到帧或时间 |
| `segment-play` | `segment-playback` | 输入选择相邻状态，片段按时间播放 |
| `autonomous` | `autonomous-playback` | 媒体时间自行推进 |

不要根据 `scroll`、分页布局或视频格式猜控制器。滚动既可以 scrub，也可以触发片段播放。

## 时间轴清单

所有控制器只读取编译生成的 `build/timeline.json`，页面中不得维护第二份时间常量。

```yaml
schemaVersion: 1
fps: <实际编码帧率>
frameDuration: <1 / fps>
initialState: <稳定状态 ID>
states:
  - id: <页面与运行时共同使用的状态 ID>
    hold: <该状态的停帧时间>
segments:
  - id: <稳定标识>
    from: <起点状态 ID>
    to: <终点状态 ID>
    start: <本段第一张可见帧的时间，包含>
    hold: <本段结束后应停留的最后可见帧时间>
    endExclusive: <本段编码边界，不包含>
    curve:
      type: constant | edge-mid-edge
      rate: <constant 使用>
      edgeRate: <edge-mid-edge 使用>
      midRate: <edge-mid-edge 使用>
```

硬性语义：

- `start <= hold < endExclusive`。
- 停止播放时只能落在 `hold`，不能落在 `endExclusive`。
- `states` 顺序必须与片段的 `from → to` 一致；页面状态直接使用这些 ID，不另建索引映射表。
- 所有时间都来自最终编码后的实际帧，不从生成时长或原始素材手工推算。
- 裁剪、拼接或重新编码后必须重新生成清单。

## frame-scrub

适用于“输入停在哪里，画面就停在哪里”的交互。使用
[assets/interactive-motion.ts](../assets/interactive-motion.ts) 的
`createFrameAnimator` 管理目标帧、阻尼和反向。

一维映射：

```text
progress = clamp((value - start) / (end - start), 0, 1)
targetFrame = progress * (frameCount - 1)
```

环形输入使用最短环形距离；二维输入使用二维采样网格，不能压成一维进度。输入事件只更新目标值，实际渲染集中在 `requestAnimationFrame`。

视频 scrub 每次只提交最新整数目标帧，丢弃过时 seek。需要随机访问或快速反向时使用全关键帧视频，并验收 seek 延迟。

## segment-playback

适用于“输入选择下一状态，动作随后自行完成”的交互。使用
[assets/interactive-motion.ts](../assets/interactive-motion.ts) 的
`createSegmentPlayer`，不要在页面重新实现播放状态机。

必须满足：

1. 生产时可以分段生成，但连续链交付前必须合并；运行时使用一个持续存在的媒体实例，切换状态不替换 `src`、视频节点或图片层。
2. 输入一发生就启动媒体；页面导航或其他几何动画可以并行，不等待动作结束。
3. 反向输入先取消当前播放，再从当前 `currentTime` 向上一状态撤回。
4. 前进可以使用用户输入触发的 `video.play()`。反向不能依赖浏览器支持负 `playbackRate`，由共享控制器按时间轴回放。
5. 使用 `requestVideoFrameCallback`，无支持时回退 `requestAnimationFrame`；不得用低频 `timeupdate` 判断停帧。
6. 接近目标时先暂停，再精确设到 `hold`，避免越过目标后回跳。
7. 播放速率曲线属于时间轴清单。需要两端快、中间慢时使用 `edge-mid-edge`；正放与倒放读取同一曲线。
8. 快速连续输入只保留最新目标，旧任务必须可取消。

桌面与移动媒体版本在初始化时选择。普通 resize 不换源；确需重载另一版本时，恢复到当前状态的 `hold` 后再继续。

分页导航只负责选择目标状态 ID。它不能把分段时间轴改成多个互不相关的视频，也不能用页面切换遮盖媒体接缝。

### 分步手势策略

`segment-playback` 与分页导航组合时，必须从 Motion Brief 读取 `gesture_policy`：

- `one-gesture-one-step`：把同一次滚轮或触控板惯性序列合并成一个方向意图，不能按每个原始事件连续跳状态。
- `while_active`：明确新输入是重定向、排队还是忽略；默认需要可反向的交互使用 `retarget`。
- `boundary`：首尾状态执行 `clamp` 或合同明确的 `loop`，不能越界创建空状态。
- `programmatic_navigation=ignore`：页面自身的平滑滚动和位置校正不得再次触发媒体状态变化。
- 页面元素的状态 ID 必须直接匹配 `timeline.json.states[].id`；找不到、重复或顺序不一致时在初始化阶段失败。

从 [assets/step-gesture.ts](../assets/step-gesture.ts) 的 `createStepGestureAdapter` 开始实现。滚轮、触控板或触摸层只把方向增量送入该适配器；手势阈值、惯性结束判定和程序化导航锁不得在页面监听、媒体控制器和分页组件中各写一份。

## autonomous-playback

适用于待机、循环或进入可见区域后自行播放的动画。浏览器允许时使用 `muted playsinline`；需要声音或浏览器阻止自动播放时，等待明确用户手势。循环只在素材本身通过首尾接缝验收时启用。

## 渲染器

### Alpha 图集

- 单元格尺寸统一，并至少覆盖最大 CSS 尺寸乘目标 DPR。
- 清单保存帧数、行列、单元格尺寸和参数映射。
- 切帧只更新 `background-position`，不创建多张透明图片交叉淡化。
- 默认单张纹理不超过 4096；超预算回到自动路线选择。

### Chroma 视频

- 视频保留均匀色键，由 `chroma-video-renderer.ts` 绘制透明 Canvas。
- 页面背景、文字和其他视觉层位于 Canvas 外部。
- 运行时从 `compile.json.runtime.keying` 读取全部参数，不在页面另写阈值。
- WebGL 或视频失败时显示静态 Alpha 降级图，不能露出色键母版。

### Baked 视频

- 视频本身包含完整画面，不做抠色、色键或背景合成。
- 可由视频元素直接显示，也可绘制到 Canvas。
- 失败时显示普通 `poster.png`。

## 输入、布局与生命周期

- `pointermove`、`scroll` 和触摸事件只记录输入，不在事件回调中反复写 DOM。
- 布局变化后重新读取主体位置；不要永久缓存 `getBoundingClientRect()`。
- 使用 `IntersectionObserver` 暂停离屏计算，使用 `ResizeObserver` 更新布局。
- 手机方向权限必须由用户手势请求；拒绝或不可用时回退触摸或静态状态。
- 页面切后台时暂停；恢复后以最新目标和当前媒体时间继续。

## 预加载与降级

- 图集预加载清单、静态帧和图集，并等待 `Image.decode()`。
- 视频预加载静态降级、元数据和首个需要的媒体；`loadedmetadata` 前不得 seek 或播放。
- 加载完成前只显示一张静态降级图或简洁加载层。
- 资源失败时解除页面锁定并回退静态画面，不让次要动画阻塞页面。
- `prefers-reduced-motion` 使用合同指定的静态状态，不自动播放或连续 scrub。

## 性能验收

- 每个动画帧最多一次 DOM 写入；目标未变化时不重复渲染。
- 离屏或状态稳定时停止 `requestAnimationFrame`。
- 不同时渲染两张大图做“平滑”。
- 在冷缓存、弱网、低端移动设备、快速反向和连续输入下检查。

````

<!-- ===== FILE: scripts/chroma_key.py ===== -->
````py
"""绿幕视频编译与 WebGL 运行时共享的 dominance-v2 色键规范。"""

from __future__ import annotations

from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

import numpy as np
from PIL import Image


@dataclass(frozen=True)
class ChromaKeyParameters:
    algorithm: str
    mode: str
    key_color: tuple[int, int, int]
    similarity: float = 0.12
    smoothness: float = 0.06
    dominance_start: float = 0.0
    dominance_end: float = 0.12
    spill_start: float = -0.005
    spill_end: float = 0.06
    spill: float = 1.0

    def manifest(self) -> dict[str, Any]:
        data = asdict(self)
        return {
            "algorithm": data["algorithm"],
            "mode": data["mode"],
            "keyColor": list(data["key_color"]),
            "similarity": data["similarity"],
            "smoothness": data["smoothness"],
            "dominanceStart": data["dominance_start"],
            "dominanceEnd": data["dominance_end"],
            "spillStart": data["spill_start"],
            "spillEnd": data["spill_end"],
            "spill": data["spill"],
        }


def key_mode(key: tuple[int, int, int]) -> str:
    red, green, blue = key
    if green >= red + 40 and green >= blue + 40:
        return "green"
    if red >= green + 40 and blue >= green + 40:
        return "magenta"
    raise ValueError("色键不是可识别的绿色或洋红色")


def default_parameters(key: tuple[int, int, int]) -> ChromaKeyParameters:
    return ChromaKeyParameters(
        algorithm="dominance-v2",
        mode=key_mode(key),
        key_color=key,
    )


def _smoothstep(edge0: float, edge1: float, value: np.ndarray) -> np.ndarray:
    width = max(0.0001, edge1 - edge0)
    normalized = np.clip((value - edge0) / width, 0.0, 1.0)
    return normalized * normalized * (3.0 - 2.0 * normalized)


def _chroma(colors: np.ndarray) -> np.ndarray:
    luminance = (
        colors[..., 0] * 0.299
        + colors[..., 1] * 0.587
        + colors[..., 2] * 0.114
    )
    return np.stack(
        (colors[..., 2] - luminance, colors[..., 0] - luminance),
        axis=-1,
    )


def _dominance(colors: np.ndarray, mode: str) -> np.ndarray:
    if mode == "green":
        return colors[..., 1] - np.maximum(colors[..., 0], colors[..., 2])
    return np.minimum(colors[..., 0], colors[..., 2]) - colors[..., 1]


def apply_key(
    rgb: np.ndarray,
    parameters: ChromaKeyParameters,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """返回去溢色 RGB、Alpha 和原始色键通道优势，数值范围均为 0..1。"""
    colors = np.asarray(rgb, dtype=np.float32)
    if colors.size and float(colors.max()) > 1.0:
        colors = colors / 255.0
    key = np.asarray(parameters.key_color, dtype=np.float32) / 255.0
    distance = np.linalg.norm(_chroma(colors) - _chroma(key), axis=-1)
    distance_alpha = _smoothstep(
        parameters.similarity,
        parameters.similarity + parameters.smoothness,
        distance,
    )
    dominance = _dominance(colors, parameters.mode)
    dominance_mask = _smoothstep(
        parameters.dominance_start,
        parameters.dominance_end,
        dominance,
    )
    alpha = np.minimum(distance_alpha, 1.0 - dominance_mask)
    dominance_spill = _smoothstep(
        parameters.spill_start,
        parameters.spill_end,
        dominance,
    )
    spill_mask = np.clip(
        np.maximum(dominance_spill, (1.0 - alpha) * parameters.spill),
        0.0,
        1.0,
    )
    output = colors.copy()
    if parameters.mode == "green":
        neutral = np.maximum(colors[..., 0], colors[..., 2])
        output[..., 1] = colors[..., 1] * (1.0 - spill_mask) + neutral * spill_mask
    else:
        neutral = colors[..., 1]
        output[..., 0] = colors[..., 0] * (1.0 - spill_mask) + neutral * spill_mask
        output[..., 2] = colors[..., 2] * (1.0 - spill_mask) + neutral * spill_mask
    return np.clip(output, 0.0, 1.0), np.clip(alpha, 0.0, 1.0), dominance


def key_image(
    source: Path,
    output: Path,
    parameters: ChromaKeyParameters,
) -> dict[str, int]:
    rgb = np.asarray(Image.open(source).convert("RGB"), dtype=np.float32) / 255.0
    color, alpha, _ = apply_key(rgb, parameters)
    rgba = np.dstack(
        (
            np.rint(color * 255).astype(np.uint8),
            np.rint(alpha * 255).astype(np.uint8),
        )
    )
    output.parent.mkdir(parents=True, exist_ok=True)
    Image.fromarray(rgba, "RGBA").save(output)
    return {
        "transparentPixels": int(np.count_nonzero(alpha <= 0.01)),
        "partialPixels": int(np.count_nonzero((alpha > 0.01) & (alpha < 0.99))),
    }


def analyze_frame(
    source: Path,
    parameters: ChromaKeyParameters,
) -> dict[str, float | int]:
    rgb = np.asarray(Image.open(source).convert("RGB"), dtype=np.float32) / 255.0
    output, alpha, dominance = apply_key(rgb, parameters)
    key_like = dominance > 0.02
    visible_key = key_like & (alpha > 0.01)
    opaque_key = key_like & (alpha > 0.5)
    border = np.zeros(alpha.shape, dtype=bool)
    band = max(2, min(alpha.shape) // 80)
    border[:band] = True
    border[-band:] = True
    border[:, :band] = True
    border[:, -band:] = True
    edge = (alpha > 0.02) & (alpha < 0.98)
    output_dominance = _dominance(output, parameters.mode)

    def percentile(values: np.ndarray, quantile: float) -> float:
        return float(np.quantile(values, quantile)) if values.size else 0.0

    key_count = max(1, int(np.count_nonzero(key_like)))
    return {
        "keyLikePixels": int(np.count_nonzero(key_like)),
        "keyLikeAlphaP99": percentile(alpha[key_like], 0.99),
        "visibleKeyPixelRatio": float(np.count_nonzero(visible_key) / key_count),
        "opaqueKeyPixelRatio": float(np.count_nonzero(opaque_key) / key_count),
        "borderAlphaP99": percentile(alpha[border], 0.99),
        "edgeKeyDominanceP95": max(0.0, percentile(output_dominance[edge], 0.95)),
        "meanAlpha": float(alpha.mean()),
    }

````

<!-- ===== FILE: scripts/compile_scroll_video.py ===== -->
````py
#!/usr/bin/env python3
"""把动作母版编译为可精确控制的全关键帧 MP4。

适合一维连续时间轴的大尺寸动画，支持逐帧、分段和自主播放，以及两种背景归属：

- `--background-owner page`（chroma 路线）：保留均匀色键背景，网页使用
  WebGL 实时抠色；编译前逐帧模拟同一套 shader 参数，检查主体内部绿块、边缘溢色
  和压缩脏边，并输出多种测试底色上的抠色合成图供验收。
- `--background-owner video`（baked 路线）：背景与主体在同一视频中烘焙生成，
  不做任何抠色；视频本身就是最终画面。
"""

from __future__ import annotations

import argparse
import bisect
import json
import shutil
import subprocess
import sys
from pathlib import Path
from statistics import median
from typing import Any

from PIL import Image, ImageDraw

from chroma_key import (
    ChromaKeyParameters,
    analyze_frame,
    default_parameters,
    key_image,
    key_mode,
)

SCRIPT_DIR = Path(__file__).resolve().parent
PIPELINE = SCRIPT_DIR / "motion_pipeline.py"
CLEANUP = SCRIPT_DIR / "loop_cleanup.py"
OPTIMIZE = SCRIPT_DIR / "optimize_motion.py"

POST_ENCODE_LIMITS = {
    "keyLikeAlphaP99": 0.01,
    "visibleKeyPixelRatio": 0.01,
    "opaqueKeyPixelRatio": 0.005,
    "edgeKeyDominanceP95": 0.02,
}


def run(command: list[str]) -> None:
    print("+ " + " ".join(command), flush=True)
    subprocess.run(command, check=True)


def require_command(name: str) -> None:
    if shutil.which(name) is None:
        raise RuntimeError(f"找不到 {name}，请先安装 ffmpeg")


def probe(path: Path) -> dict[str, Any]:
    completed = subprocess.run(
        [
            "ffprobe",
            "-v",
            "error",
            "-show_streams",
            "-show_format",
            "-of",
            "json",
            str(path),
        ],
        check=True,
        capture_output=True,
        text=True,
    )
    return json.loads(completed.stdout)


def video_stream(report: dict[str, Any]) -> dict[str, Any]:
    for stream in report.get("streams", []):
        if stream.get("codec_type") == "video":
            return stream
    raise ValueError("输入文件没有视频流")


def parse_rate(value: str | None) -> float | None:
    if not value or value in {"0/0", "N/A"}:
        return None
    if "/" in value:
        numerator, denominator = value.split("/", 1)
        denominator_value = float(denominator)
        return float(numerator) / denominator_value if denominator_value else None
    return float(value)


def parse_segment_specs(values: list[str]) -> list[dict[str, int | str]]:
    segments: list[dict[str, int | str]] = []
    identifiers: set[str] = set()
    for raw in values:
        try:
            identifier, frames = raw.split("=", 1)
            start_text, hold_text, end_text = frames.split(":", 2)
            start, hold, end_exclusive = (
                int(start_text),
                int(hold_text),
                int(end_text),
            )
        except ValueError as error:
            raise ValueError(
                "--segment 必须写成 DESTINATION_STATE_ID=START:HOLD:END_EXCLUSIVE"
            ) from error
        identifier = identifier.strip()
        if not identifier or identifier in identifiers:
            raise ValueError(f"片段 ID 为空或重复：{identifier or raw}")
        if not 0 <= start <= hold < end_exclusive:
            raise ValueError(f"片段 {identifier} 必须满足 START <= HOLD < END_EXCLUSIVE")
        identifiers.add(identifier)
        segments.append(
            {
                "id": identifier,
                "start": start,
                "hold": hold,
                "endExclusive": end_exclusive,
            }
        )
    return segments


def build_timeline(
    specs: list[dict[str, int | str]],
    kept_source_indices: list[int],
    raw_count: int,
    fps: float,
    curve: dict[str, float | str],
    initial_state_id: str = "state-0",
) -> dict[str, Any]:
    final_count = len(kept_source_indices)
    if not specs:
        specs = [
            {
                "id": "state-1",
                "start": 0,
                "hold": raw_count - 1,
                "endExclusive": raw_count,
            }
        ]
    initial_state_id = initial_state_id.strip()
    if not initial_state_id:
        raise ValueError("--initial-state-id 不能为空")
    destination_ids = {str(spec["id"]) for spec in specs}
    if initial_state_id in destination_ids:
        raise ValueError("初始状态 ID 不能与目标状态 ID 重复")
    segments: list[dict[str, Any]] = []
    states: list[dict[str, Any]] = []
    previous_end = 0
    previous_state_id = initial_state_id
    for spec in specs:
        source_start = int(spec["start"])
        source_hold = int(spec["hold"])
        source_end = int(spec["endExclusive"])
        if source_end > raw_count:
            raise ValueError(
                f"片段 {spec['id']} 的 END_EXCLUSIVE 超出源帧数 {raw_count}"
            )
        start = bisect.bisect_left(kept_source_indices, source_start)
        hold = bisect.bisect_right(kept_source_indices, source_hold) - 1
        end_exclusive = bisect.bisect_left(kept_source_indices, source_end)
        if not 0 <= start <= hold < end_exclusive <= final_count:
            raise ValueError(f"片段 {spec['id']} 在清理后没有有效连续帧")
        if start < previous_end:
            raise ValueError(f"片段 {spec['id']} 与上一片段重叠")
        destination_state_id = str(spec["id"])
        if not states:
            states.append(
                {
                    "id": initial_state_id,
                    "frame": start,
                    "hold": start / fps,
                }
            )
        segments.append(
            {
                "id": f"{previous_state_id}->{destination_state_id}",
                "from": previous_state_id,
                "to": destination_state_id,
                "sourceFrames": {
                    "start": source_start,
                    "hold": source_hold,
                    "endExclusive": source_end,
                },
                "frames": {
                    "start": start,
                    "hold": hold,
                    "endExclusive": end_exclusive,
                },
                "start": start / fps,
                "hold": hold / fps,
                "endExclusive": end_exclusive / fps,
                "curve": curve,
            }
        )
        states.append(
            {
                "id": destination_state_id,
                "frame": hold,
                "hold": hold / fps,
            }
        )
        previous_end = end_exclusive
        previous_state_id = destination_state_id
    return {
        "schemaVersion": 1,
        "fps": fps,
        "frameDuration": 1 / fps,
        "frameCount": final_count,
        "initialState": initial_state_id,
        "states": states,
        "segments": segments,
    }


def dimensions_for_width(
    requested_width: int,
    source_width: int,
    source_height: int,
    allow_upscale: bool,
) -> tuple[int, int]:
    width = requested_width
    if width > source_width and not allow_upscale:
        width = source_width
        print(
            f"提示：请求宽度 {requested_width}px 超过母版，自动限制为 {source_width}px",
            flush=True,
        )
    width = max(2, width - width % 2)
    height = round(width * source_height / source_width)
    height = max(2, height - height % 2)
    return width, height


def image_frames(directory: Path) -> list[Path]:
    return sorted(directory.glob("frame_*.png"))


def representative_frames(paths: list[Path], limit: int = 48) -> list[Path]:
    if limit < 1:
        raise ValueError("代表帧数量必须大于 0")
    if len(paths) <= limit:
        return paths
    if limit == 1:
        return [paths[0]]
    return [
        paths[round(index * (len(paths) - 1) / (limit - 1))]
        for index in range(limit)
    ]


def representative_indices(count: int, limit: int = 48) -> list[int]:
    if count < 1:
        raise ValueError("帧数必须大于 0")
    if limit < 1:
        raise ValueError("代表帧数量必须大于 0")
    if count <= limit:
        return list(range(count))
    if limit == 1:
        return [0]
    return [
        round(index * (count - 1) / (limit - 1))
        for index in range(limit)
    ]


def border_samples(path: Path) -> list[tuple[int, int, int]]:
    with Image.open(path) as opened:
        image = opened.convert("RGB")
    width, height = image.size
    band = max(1, min(width, height, 6))
    step = max(1, min(width, height) // 256)
    pixels = image.load()
    samples: list[tuple[int, int, int]] = []
    for x in range(0, width, step):
        for offset in range(band):
            samples.append(pixels[x, offset])
            samples.append(pixels[x, height - 1 - offset])
    for y in range(0, height, step):
        for offset in range(band):
            samples.append(pixels[offset, y])
            samples.append(pixels[width - 1 - offset, y])
    return samples


def sample_key_color(path: Path) -> tuple[int, int, int]:
    samples = border_samples(path)
    return tuple(
        int(round(median(sample[channel] for sample in samples)))
        for channel in range(3)
    )


def sample_key_color_many(paths: list[Path]) -> tuple[int, int, int]:
    if not paths:
        raise ValueError("没有可用于采样色键的帧")
    per_frame = [sample_key_color(path) for path in paths]
    return tuple(
        int(round(median(color[channel] for color in per_frame)))
        for channel in range(3)
    )


def key_color_hex(key: tuple[int, int, int]) -> str:
    return f"#{key[0]:02X}{key[1]:02X}{key[2]:02X}"


def validate_key_source(
    paths: list[Path],
    key: tuple[int, int, int],
) -> dict[str, object]:
    try:
        kind = key_mode(key)
    except ValueError as error:
        raise ValueError("母版边缘不是可识别的绿色或洋红色键背景") from error
    checked = representative_frames(paths)
    worst_spread = 0
    for path in checked:
        spreads = sorted(
            max(abs(color[channel] - key[channel]) for channel in range(3))
            for color in border_samples(path)
        )
        spread_p95 = spreads[round((len(spreads) - 1) * 0.95)]
        worst_spread = max(worst_spread, spread_p95)
        if spread_p95 > 32:
            raise ValueError(
                f"母版色键边缘不均匀：{path.name} 的 95% 色差范围为 "
                f"{spread_p95}，上限 32"
            )
    return {
        "kind": kind,
        "borderSpreadP95Max": worst_spread,
        "checkedFrames": len(checked),
    }


def decode_video_frames(
    video: Path,
    output: Path,
    indices: list[int],
) -> dict[int, Path]:
    if not indices:
        raise ValueError("至少需要解码一帧")
    output.mkdir(parents=True, exist_ok=True)
    expression = "+".join(f"eq(n\\,{index})" for index in indices)
    run(
        [
            "ffmpeg",
            "-hide_banner",
            "-loglevel",
            "warning",
            "-y",
            "-i",
            str(video),
            "-vf",
            f"select={expression}",
            "-fps_mode",
            "vfr",
            str(output / "frame_%05d.png"),
        ]
    )
    decoded = image_frames(output)
    if len(decoded) != len(indices):
        raise RuntimeError(
            f"编码后抽帧数量错误：期望 {len(indices)}，实际 {len(decoded)}"
        )
    return dict(zip(indices, decoded, strict=True))


def parse_anchors(values: list[str]) -> dict[str, int]:
    anchors: dict[str, int] = {}
    for value in values:
        if "=" not in value:
            raise ValueError("--anchor 格式必须是 NAME=SOURCE_FRAME")
        name, raw_frame = value.split("=", 1)
        name = name.strip()
        if not name or not name.replace("-", "_").isidentifier():
            raise ValueError(f"无效锚点名称：{name or value}")
        if name in anchors:
            raise ValueError(f"锚点名称重复：{name}")
        try:
            source_frame = int(raw_frame)
        except ValueError as error:
            raise ValueError(f"锚点帧必须是整数：{value}") from error
        if source_frame < 0:
            raise ValueError(f"锚点帧不能小于 0：{value}")
        anchors[name] = source_frame
    return anchors


def map_source_frame(source_frame: int, kept_source_indices: list[int]) -> int:
    if not kept_source_indices:
        raise ValueError("清理报告没有保留帧")
    return min(
        range(len(kept_source_indices)),
        key=lambda index: (abs(kept_source_indices[index] - source_frame), index),
    )


def create_background_matrix(alpha_frames: list[Path], output: Path) -> None:
    selected = representative_frames(alpha_frames, limit=6)
    if not selected:
        raise ValueError("没有可生成背景验收矩阵的 Alpha 帧")
    thumb_width = 160
    with Image.open(selected[0]) as opened:
        thumb_height = max(1, round(thumb_width * opened.height / opened.width))
    backgrounds = [
        (255, 255, 255),
        (8, 8, 10),
        (245, 24, 88),
        (0, 112, 255),
    ]
    gutter = 8
    label_height = 18
    width = gutter + len(selected) * (thumb_width + gutter)
    height = gutter + len(backgrounds) * (thumb_height + label_height + gutter)
    sheet = Image.new("RGB", (width, height), (32, 32, 34))
    draw = ImageDraw.Draw(sheet)
    for row, background_color in enumerate(backgrounds):
        y = gutter + row * (thumb_height + label_height + gutter)
        draw.text((gutter, y + thumb_height + 2), f"BG {row + 1}", fill=(230, 230, 230))
        for column, path in enumerate(selected):
            with Image.open(path) as opened:
                foreground = opened.convert("RGBA")
            foreground.thumbnail(
                (thumb_width, thumb_height),
                Image.Resampling.LANCZOS,
            )
            background = Image.new(
                "RGBA",
                (thumb_width, thumb_height),
                (*background_color, 255),
            )
            x = gutter + column * (thumb_width + gutter)
            paste_x = (thumb_width - foreground.width) // 2
            paste_y = (thumb_height - foreground.height) // 2
            background.alpha_composite(foreground, (paste_x, paste_y))
            sheet.paste(background.convert("RGB"), (x, y))
    output.parent.mkdir(parents=True, exist_ok=True)
    sheet.save(output, quality=90)


def analyze_encoded_frames(
    name: str,
    decoded: dict[int, Path],
    alpha_output: Path,
    parameters: ChromaKeyParameters,
    qa: Path,
    contact_columns: int,
) -> dict[str, Any]:
    alpha_output.mkdir(parents=True, exist_ok=True)
    records: list[dict[str, Any]] = []
    for sequence, (frame_index, source) in enumerate(decoded.items(), start=1):
        alpha_path = alpha_output / f"frame_{sequence:05d}.png"
        key_image(source, alpha_path, parameters)
        records.append(
            {
                "frame": frame_index,
                "file": source.name,
                **analyze_frame(source, parameters),
            }
        )
    maxima = {
        metric: max(float(record[metric]) for record in records)
        for metric in POST_ENCODE_LIMITS
    }
    violations = [
        {
            "metric": metric,
            "actual": maxima[metric],
            "limit": limit,
        }
        for metric, limit in POST_ENCODE_LIMITS.items()
        if maxima[metric] > limit
    ]
    run(
        [
            sys.executable,
            str(PIPELINE),
            "contact",
            str(alpha_output),
            "--output",
            str(qa / f"{name}-alpha-contact.jpg"),
            "--columns",
            str(contact_columns),
        ]
    )
    create_background_matrix(
        image_frames(alpha_output),
        qa / f"{name}-background-matrix.jpg",
    )
    return {
        "passed": not violations,
        "checkedFrames": len(records),
        "limits": POST_ENCODE_LIMITS,
        "maxima": maxima,
        "violations": violations,
        "frames": records,
    }
def load_budget_report(
    path: Path,
    expected: str = "chroma-video",
) -> dict[str, Any]:
    if not path.is_file():
        raise FileNotFoundError(f"找不到预算报告：{path}")
    report = json.loads(path.read_text(encoding="utf-8"))
    delivery = report.get("delivery", {})
    if delivery.get("selected") != expected:
        raise ValueError(
            f"预算报告没有选择 {expected}，禁止执行视频编译路线"
        )
    if not report.get("passes"):
        raise ValueError("预算报告存在阻断项，禁止执行视频编译路线")
    return report


def require_frame_preparation_pass(path: Path) -> dict[str, Any]:
    report = json.loads(path.read_text(encoding="utf-8"))
    verdict = report.get("verdict", {})
    if not verdict.get("passedAutomaticChecks"):
        raise RuntimeError("帧准备自动检查未通过，禁止继续编码视频")
    return report


def encode_all_intra(
    frames: Path,
    output: Path,
    fps: float,
    width: int,
    height: int,
    crf: int,
) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)
    run(
        [
            "ffmpeg",
            "-hide_banner",
            "-loglevel",
            "warning",
            "-y",
            "-framerate",
            str(fps),
            "-start_number",
            "1",
            "-i",
            str(frames / "frame_%05d.png"),
            "-vf",
            f"scale={width}:{height}:flags=lanczos,setsar=1",
            "-c:v",
            "libx264",
            "-preset",
            "slow",
            "-crf",
            str(crf),
            "-g",
            "1",
            "-keyint_min",
            "1",
            "-sc_threshold",
            "0",
            "-pix_fmt",
            "yuv420p",
            "-an",
            "-movflags",
            "+faststart",
            str(output),
        ]
    )


def all_frames_are_keyframes(path: Path) -> bool:
    completed = subprocess.run(
        [
            "ffprobe",
            "-v",
            "error",
            "-select_streams",
            "v:0",
            "-show_entries",
            "frame=key_frame",
            "-of",
            "csv=p=0",
            str(path),
        ],
        check=True,
        capture_output=True,
        text=True,
    )
    values = [
        line.strip().split(",", 1)[0]
        for line in completed.stdout.splitlines()
        if line.strip()
    ]
    return bool(values) and all(value == "1" for value in values)


def safe_prepare_output(output: Path, force: bool) -> None:
    output = output.resolve()
    if output == Path(output.anchor) or output == Path.home().resolve():
        raise ValueError("输出目录不能是磁盘根目录或用户主目录")
    if output.exists() and any(output.iterdir()):
        if not force:
            raise FileExistsError(f"输出目录非空：{output}；确认后使用 --force")
        for item in output.iterdir():
            if item.is_dir() and not item.is_symlink():
                shutil.rmtree(item)
            else:
                item.unlink()
    output.mkdir(parents=True, exist_ok=True)


def compile_motion(args: argparse.Namespace) -> int:
    require_command("ffmpeg")
    require_command("ffprobe")

    source = Path(args.source).expanduser().resolve()
    output = Path(args.output_dir).expanduser().resolve()
    budget_path = Path(args.budget_report).expanduser().resolve()
    if not source.is_file():
        raise FileNotFoundError(f"找不到视频：{source}")
    background_owner = args.background_owner
    expected_delivery = (
        "baked-video" if background_owner == "video" else "chroma-video"
    )
    budget_report = load_budget_report(budget_path, expected_delivery)
    if args.loop and args.end_reference:
        raise ValueError("--loop 与 --end-reference 不能同时使用")
    if args.fps is not None and args.fps <= 0:
        raise ValueError("--fps 必须大于 0")
    if args.desktop_width < 2 or args.mobile_width < 2:
        raise ValueError("输出宽度必须至少为 2")
    if not 0 <= args.desktop_crf <= 51 or not 0 <= args.mobile_crf <= 51:
        raise ValueError("CRF 必须在 0–51 之间")
    if args.seam_window < 1:
        raise ValueError("--seam-window 必须至少为 1")
    if args.duplicate_threshold < 0:
        raise ValueError("--duplicate-threshold 不能小于 0")
    if args.contact_columns < 1:
        raise ValueError("--contact-columns 必须至少为 1")
    for name, value in (
        ("--playback-rate", args.playback_rate),
        ("--edge-rate", args.edge_rate),
        ("--mid-rate", args.mid_rate),
    ):
        if value <= 0:
            raise ValueError(f"{name} 必须大于 0")
    if args.poster_source_frame < 0:
        raise ValueError("--poster-source-frame 不能小于 0")
    anchor_sources = parse_anchors(args.anchor)
    segment_specs = parse_segment_specs(args.segment)
    safe_prepare_output(output, args.force)

    source_probe = probe(source)
    source_video = video_stream(source_probe)
    source_width = int(source_video["width"])
    source_height = int(source_video["height"])
    source_fps = (
        parse_rate(source_video.get("avg_frame_rate"))
        or parse_rate(source_video.get("r_frame_rate"))
        or 24.0
    )
    if args.frame_policy == "native":
        if args.fps is not None and abs(args.fps - source_fps) > 0.01:
            raise ValueError("frame-policy=native 时 --fps 必须省略或等于源帧率")
        args.fps = source_fps
    else:
        args.fps = args.fps or 48.0
        if args.fps <= source_fps:
            raise ValueError("frame-policy=interpolate 时 --fps 必须高于源帧率")

    preparation = output / "frame-preparation"
    raw_frames = preparation / "frames"
    cleaned_frames = output / "frames" / "final"
    post_encode_frames = output / "post-encode-frames"
    qa = output / "qa"
    final = output / "final"
    qa.mkdir(parents=True, exist_ok=True)
    final.mkdir(parents=True, exist_ok=True)

    if args.frame_policy == "interpolate":
        run(
            [
                sys.executable,
                str(OPTIMIZE),
                "interpolate",
                str(source),
                str(preparation),
                "--fps",
                str(args.fps),
                "--key",
                "none",
            ]
        )
        frame_report_path = preparation / "interpolation-report.json"
    else:
        run(
            [
                sys.executable,
                str(PIPELINE),
                "extract",
                str(source),
                str(raw_frames),
                "--fps",
                str(args.fps),
                "--key",
                "none",
            ]
        )
        native_qa = preparation / "qa"
        native_qa.mkdir(parents=True, exist_ok=True)
        analysis_path = native_qa / "analysis-native.json"
        run(
            [
                sys.executable,
                str(PIPELINE),
                "analyze",
                str(raw_frames),
                "--output",
                str(analysis_path),
            ]
        )
        run(
            [
                sys.executable,
                str(PIPELINE),
                "contact",
                str(raw_frames),
                "--output",
                str(native_qa / "contact-sheet-native.jpg"),
                "--columns",
                str(args.contact_columns),
            ]
        )
        frame_report_path = preparation / "frame-preparation-report.json"
        frame_report_path.write_text(
            json.dumps(
                {
                    "type": "motion-frame-preparation-report",
                    "policy": "native",
                    "sourceFps": source_fps,
                    "targetFps": args.fps,
                    "analysis": str(analysis_path),
                    "verdict": {
                        "passedAutomaticChecks": True,
                        "manualReviewRequired": True,
                    },
                },
                ensure_ascii=False,
                indent=2,
            ),
            encoding="utf-8",
        )
    frame_report = require_frame_preparation_pass(frame_report_path)
    raw_count = len(image_frames(raw_frames))
    if raw_count < 3:
        raise RuntimeError("母版切帧后少于 3 帧")
    requested_source_frames = {
        "poster": args.poster_source_frame,
        **anchor_sources,
    }
    for name, source_frame in requested_source_frames.items():
        if source_frame >= raw_count:
            raise ValueError(
                f"{name} 源帧 {source_frame} 超出插帧范围 0..{raw_count - 1}"
            )

    cleanup_report_path = qa / "cleanup.json"
    if args.loop or args.end_reference:
        cleanup_command = [
            sys.executable,
            str(CLEANUP),
            str(raw_frames),
            str(cleaned_frames),
            "--seam-window",
            str(args.seam_window),
            "--duplicate-threshold",
            str(args.duplicate_threshold),
            "--report",
            str(cleanup_report_path),
        ]
        if args.end_reference:
            cleanup_command.extend(
                [
                    "--end-reference",
                    str(Path(args.end_reference).expanduser().resolve()),
                ]
            )
        run(cleanup_command)
        final_frames = cleaned_frames
        cleanup_data = json.loads(cleanup_report_path.read_text(encoding="utf-8"))
        kept_source_indices = [
            int(index) for index in cleanup_data["keptSourceIndices"]
        ]
    else:
        final_frames = raw_frames
        kept_source_indices = list(range(raw_count))
        print("提示：未传 --loop 或 --end-reference，使用全部准备帧", flush=True)

    final_frame_paths = image_frames(final_frames)
    if not final_frame_paths:
        raise RuntimeError("清理后没有可编码帧")
    final_count = len(final_frame_paths)
    if final_count != len(kept_source_indices):
        raise RuntimeError("清理报告帧数与最终帧目录不一致")
    anchor_manifest = {
        name: {
            "sourceFrame": source_frame,
            "finalFrame": map_source_frame(source_frame, kept_source_indices),
        }
        for name, source_frame in anchor_sources.items()
    }
    poster_final_frame = map_source_frame(
        args.poster_source_frame,
        kept_source_indices,
    )
    curve = (
        {"type": "constant", "rate": args.playback_rate}
        if args.playback_curve == "constant"
        else {
            "type": "edge-mid-edge",
            "edgeRate": args.edge_rate,
            "midRate": args.mid_rate,
        }
    )
    timeline = build_timeline(
        segment_specs,
        kept_source_indices,
        raw_count,
        args.fps,
        curve,
        args.initial_state_id,
    )
    timeline_path = Path(args.timeline_output).expanduser().resolve()
    if timeline_path.exists() and not args.force:
        raise FileExistsError(f"时间轴已存在：{timeline_path}；确认后使用 --force")
    source_key_color: str | None = None
    source_key_validation: dict[str, object] | None = None
    if background_owner == "page":
        source_key = sample_key_color_many(
            representative_frames(final_frame_paths)
        )
        source_key_color = key_color_hex(source_key)
        source_key_validation = validate_key_source(
            final_frame_paths,
            source_key,
        )
    else:
        shutil.copy2(final_frame_paths[poster_final_frame], final / "poster.png")
        run(
            [
                sys.executable,
                str(PIPELINE),
                "contact",
                str(final_frames),
                "--output",
                str(qa / "contact-sheet.jpg"),
                "--columns",
                str(args.contact_columns),
            ]
        )

    desktop_size = dimensions_for_width(
        args.desktop_width,
        source_width,
        source_height,
        args.allow_upscale,
    )
    mobile_size = dimensions_for_width(
        args.mobile_width,
        source_width,
        source_height,
        args.allow_upscale,
    )
    asset_kind = "chroma" if background_owner == "page" else "baked"
    desktop_output = final / f"motion-{asset_kind}-desktop.mp4"
    mobile_output = final / f"motion-{asset_kind}-mobile.mp4"
    encode_all_intra(
        final_frames,
        desktop_output,
        args.fps,
        desktop_size[0],
        desktop_size[1],
        args.desktop_crf,
    )
    encode_all_intra(
        final_frames,
        mobile_output,
        args.fps,
        mobile_size[0],
        mobile_size[1],
        args.mobile_crf,
    )

    desktop_all_intra = all_frames_are_keyframes(desktop_output)
    mobile_all_intra = all_frames_are_keyframes(mobile_output)
    if not desktop_all_intra or not mobile_all_intra:
        raise RuntimeError("最终 MP4 不是全关键帧编码，禁止交付")

    qa_indices: list[int] = []
    runtime_key_color: str | None = None
    keying_parameters: ChromaKeyParameters | None = None
    post_encode_qa_path: Path | None = None
    post_encode_qa: dict[str, Any] | None = None
    if background_owner == "page":
        qa_indices = sorted(
            set(representative_indices(final_count) + [poster_final_frame])
        )
        desktop_decoded = decode_video_frames(
            desktop_output,
            post_encode_frames / "desktop" / "source",
            qa_indices,
        )
        mobile_decoded = decode_video_frames(
            mobile_output,
            post_encode_frames / "mobile" / "source",
            qa_indices,
        )
        runtime_key = sample_key_color_many(
            list(desktop_decoded.values()) + list(mobile_decoded.values())
        )
        runtime_key_color = key_color_hex(runtime_key)
        keying_parameters = default_parameters(runtime_key)
        desktop_keying_qa = analyze_encoded_frames(
            "desktop",
            desktop_decoded,
            post_encode_frames / "desktop" / "alpha",
            keying_parameters,
            qa,
            args.contact_columns,
        )
        mobile_keying_qa = analyze_encoded_frames(
            "mobile",
            mobile_decoded,
            post_encode_frames / "mobile" / "alpha",
            keying_parameters,
            qa,
            args.contact_columns,
        )
        post_encode_qa = {
            "passed": (
                desktop_keying_qa["passed"] and mobile_keying_qa["passed"]
            ),
            "algorithm": keying_parameters.algorithm,
            "runtimeKeyColor": runtime_key_color,
            "parameters": keying_parameters.manifest(),
            "frameIndices": qa_indices,
            "desktop": desktop_keying_qa,
            "mobile": mobile_keying_qa,
        }
        post_encode_qa_path = qa / "post-encode-keying.json"
        post_encode_qa_path.write_text(
            json.dumps(post_encode_qa, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        if not post_encode_qa["passed"]:
            raise RuntimeError(
                f"编码后色键检查未通过，请查看 {post_encode_qa_path}"
            )
        key_image(
            desktop_decoded[poster_final_frame],
            final / "poster-alpha.png",
            keying_parameters,
        )

    desktop_probe = probe(desktop_output)
    mobile_probe = probe(mobile_output)
    manifest = {
        "source": {
            "path": str(source),
            "width": source_width,
            "height": source_height,
            "probe": source_probe,
        },
        "compile": {
            "backgroundOwner": background_owner,
            "framePolicy": args.frame_policy,
            "sourceKeyColor": source_key_color,
            "runtimeKeyColor": runtime_key_color,
            "sourceKeyValidation": source_key_validation,
            "fps": args.fps,
            "rawFrameCount": raw_count,
            "finalFrameCount": final_count,
            "alphaQaFrameCount": len(qa_indices),
            "duration": final_count / args.fps,
            "cleanup": (
                "loop"
                if args.loop
                else "end-reference"
                if args.end_reference
                else "none"
            ),
            "duplicateThreshold": args.duplicate_threshold,
            "seamWindow": args.seam_window,
            "framePreparationReport": str(frame_report_path),
            "framePreparationVerdict": frame_report["verdict"],
            "budgetReport": str(budget_path),
            "selection": budget_report["delivery"],
            "timeline": str(timeline_path),
            "postEncodeKeyingReport": (
                str(post_encode_qa_path) if post_encode_qa_path else None
            ),
            "postEncodeKeyingPassed": (
                post_encode_qa["passed"] if post_encode_qa else None
            ),
            "intermediateFramesRetained": args.keep_frames,
        },
        "runtime": {
            "type": "chroma-video" if background_owner == "page" else "baked-video",
            "frameCount": final_count,
            "fps": args.fps,
            "keying": keying_parameters.manifest() if keying_parameters else None,
            "anchors": anchor_manifest,
            "posterFrame": poster_final_frame,
            "assets": {
                "poster": (
                    "final/poster-alpha.png"
                    if background_owner == "page"
                    else "final/poster.png"
                ),
                "desktop": f"final/motion-{asset_kind}-desktop.mp4",
                "mobile": f"final/motion-{asset_kind}-mobile.mp4",
                "timeline": str(timeline_path),
            },
        },
        "outputs": {
            "poster": {
                "path": str(
                    final / "poster-alpha.png"
                    if background_owner == "page"
                    else final / "poster.png"
                ),
                "alpha": background_owner == "page",
                "sourceFrame": args.poster_source_frame,
                "finalFrame": poster_final_frame,
            },
            "desktop": {
                "path": str(desktop_output),
                "width": desktop_size[0],
                "height": desktop_size[1],
                "bytes": desktop_output.stat().st_size,
                "allFramesAreKeyframes": desktop_all_intra,
                "probe": desktop_probe,
            },
            "mobile": {
                "path": str(mobile_output),
                "width": mobile_size[0],
                "height": mobile_size[1],
                "bytes": mobile_output.stat().st_size,
                "allFramesAreKeyframes": mobile_all_intra,
                "probe": mobile_probe,
            },
        },
    }
    timeline_path.parent.mkdir(parents=True, exist_ok=True)
    timeline_path.write_text(
        json.dumps(timeline, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    manifest_path = output / "compile.json"
    manifest_path.write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    if not args.keep_frames:
        for directory in (raw_frames, preparation, cleaned_frames, post_encode_frames):
            if directory.is_dir():
                shutil.rmtree(directory)
        frames_root = output / "frames"
        if frames_root.is_dir() and not any(frames_root.iterdir()):
            frames_root.rmdir()
    print(f"编译完成：{manifest_path}", flush=True)
    return 0


def parser() -> argparse.ArgumentParser:
    result = argparse.ArgumentParser(
        description=(
            "按帧策略准备动作母版，并编译为桌面与移动端全关键帧视频；"
            "chroma 路线供 WebGL 实时抠色，baked 路线直接呈现烘焙场景"
        )
    )
    result.add_argument(
        "source",
        help="MiniMax 生成的动作母版 MP4（chroma 路线必须为均匀色键背景）",
    )
    result.add_argument("output_dir", help="新的构建目录")
    result.add_argument(
        "--background-owner",
        choices=("page", "video"),
        required=True,
        help=(
            "page：色键母版，编译前逐帧模拟运行时抠色并检查残留，供 WebGL 实时抠色；"
            "video：背景已烘焙进视频，不做抠色。必须显式传入，禁止静默回退绿幕"
        ),
    )
    result.add_argument(
        "--budget-report",
        required=True,
        help=(
            "motion_budget.py 生成的 JSON 报告；page 要求选择 chroma-video，"
            "video 要求选择 baked-video"
        ),
    )
    mode = result.add_mutually_exclusive_group()
    mode.add_argument("--loop", action="store_true", help="按闭环首帧裁掉尾部停顿")
    mode.add_argument("--end-reference", help="单向转场目标尾帧，用于裁掉尾部停顿")
    result.add_argument(
        "--frame-policy",
        choices=("native", "interpolate"),
        required=True,
        help="native 保留源帧；interpolate 补到更高目标帧率",
    )
    result.add_argument(
        "--fps",
        type=float,
        help="目标帧率；native 默认源帧率，interpolate 默认 48",
    )
    result.add_argument(
        "--timeline-output",
        required=True,
        help="编译生成的时间轴 JSON 路径，例如 build/timeline.json",
    )
    result.add_argument(
        "--segment",
        action="append",
        default=[],
        metavar="DESTINATION_STATE_ID=START:HOLD:END_EXCLUSIVE",
        help="按目标状态 ID 和帧准备后的源帧索引定义片段；可重复传入",
    )
    result.add_argument(
        "--initial-state-id",
        default="state-0",
        help="时间轴初始状态的稳定 ID，默认 state-0",
    )
    result.add_argument(
        "--playback-curve",
        choices=("constant", "edge-mid-edge"),
        default="constant",
    )
    result.add_argument("--playback-rate", type=float, default=1.0)
    result.add_argument("--edge-rate", type=float, default=1.6)
    result.add_argument("--mid-rate", type=float, default=1.0)
    result.add_argument(
        "--desktop-width",
        type=int,
        default=1920,
        help="桌面资源像素宽度，通常为最大 CSS 宽度 × DPR；默认 1920",
    )
    result.add_argument(
        "--mobile-width",
        type=int,
        default=1280,
        help="移动端资源像素宽度，通常为最大 CSS 宽度 × DPR；默认 1280",
    )
    result.add_argument("--desktop-crf", type=int, default=12)
    result.add_argument("--mobile-crf", type=int, default=14)
    result.add_argument("--seam-window", type=int, default=40)
    result.add_argument("--duplicate-threshold", type=float, default=0.003)
    result.add_argument("--contact-columns", type=int, default=8)
    result.add_argument(
        "--anchor",
        action="append",
        default=[],
        metavar="NAME=SOURCE_FRAME",
        help="记录清理前插帧序列中的语义锚点，可重复传入",
    )
    result.add_argument(
        "--poster-source-frame",
        type=int,
        default=0,
        help="静态降级图对应的清理前插帧索引；默认 0",
    )
    result.add_argument(
        "--allow-upscale",
        action="store_true",
        help="允许输出宽度超过母版；默认自动限制为母版宽度",
    )
    result.add_argument(
        "--keep-frames",
        action="store_true",
        help="保留帧准备和清理帧用于调试；默认成功后删除中间 PNG",
    )
    result.add_argument("--force", action="store_true")
    return result


if __name__ == "__main__":
    try:
        raise SystemExit(compile_motion(parser().parse_args()))
    except (
        FileNotFoundError,
        FileExistsError,
        RuntimeError,
        ValueError,
        subprocess.CalledProcessError,
    ) as error:
        print(f"错误：{error}", file=sys.stderr)
        raise SystemExit(1) from error

````

<!-- ===== FILE: scripts/compose_travel_frames.py ===== -->
````py
#!/usr/bin/env python3
"""把同一透明角色层精确放到轨道顶部和底部，生成一致的首尾帧。"""

from __future__ import annotations

import argparse
from pathlib import Path

from PIL import Image, ImageDraw


def parse_size(raw: str) -> tuple[int, int]:
    try:
        width, height = raw.lower().split("x", 1)
        return int(width), int(height)
    except (ValueError, AttributeError) as error:
        raise ValueError("--size 必须是 WIDTHxHEIGHT") from error


def build(args: argparse.Namespace) -> int:
    source = Path(args.source).expanduser().resolve()
    first_output = Path(args.first_output).expanduser().resolve()
    last_output = Path(args.last_output).expanduser().resolve()
    width, height = parse_size(args.size)

    image = Image.open(source).convert("RGBA")
    bbox = image.getbbox()
    if not bbox:
        raise ValueError("输入没有可见像素")
    subject = image.crop(bbox)

    target_height = round(height * args.subject_height)
    scale = target_height / subject.height
    target_width = round(subject.width * scale)
    if target_width > width * args.max_subject_width:
        scale = (width * args.max_subject_width) / subject.width
        target_width = round(subject.width * scale)
        target_height = round(subject.height * scale)
    subject = subject.resize((target_width, target_height), Image.Resampling.LANCZOS)

    pole_x = round(width * args.pole_x)
    anchor_x = round(subject.width * args.subject_anchor_x)
    subject_x = pole_x - anchor_x
    start_y = round(height * args.top_margin)
    end_y = height - round(height * args.bottom_margin) - subject.height
    if end_y <= start_y:
        raise ValueError("角色过高，没有足够的上下移动空间")

    def compose(y: int) -> Image.Image:
        canvas = Image.new("RGB", (width, height), args.key_color)
        draw = ImageDraw.Draw(canvas)
        outline = max(2, round(width * args.pole_outline_ratio))
        pole_width = max(outline + 2, round(width * args.pole_width_ratio))
        draw.rectangle(
            (
                pole_x - pole_width // 2 - outline,
                0,
                pole_x + pole_width // 2 + outline,
                height,
            ),
            fill=args.pole_outline,
        )
        draw.rectangle(
            (
                pole_x - pole_width // 2,
                0,
                pole_x + pole_width // 2,
                height,
            ),
            fill=args.pole_fill,
        )
        canvas.paste(subject, (subject_x, y), subject)
        return canvas

    first_output.parent.mkdir(parents=True, exist_ok=True)
    last_output.parent.mkdir(parents=True, exist_ok=True)
    compose(start_y).save(first_output)
    compose(end_y).save(last_output)
    print(
        {
            "source": str(source),
            "subjectSize": [subject.width, subject.height],
            "canvas": [width, height],
            "poleX": pole_x,
            "subjectX": subject_x,
            "startY": start_y,
            "endY": end_y,
            "first": str(first_output),
            "last": str(last_output),
        }
    )
    return 0


def parser() -> argparse.ArgumentParser:
    result = argparse.ArgumentParser(
        description="用同一透明主体生成沿竖直轨道移动的首帧和尾帧"
    )
    result.add_argument("source", help="已抠图的 RGBA PNG")
    result.add_argument("--first-output", required=True)
    result.add_argument("--last-output", required=True)
    result.add_argument("--size", default="864x1536")
    result.add_argument("--key-color", default="#00FF00")
    result.add_argument("--pole-x", type=float, default=0.5)
    result.add_argument("--pole-fill", default="#B8B8B2")
    result.add_argument("--pole-outline", default="#181818")
    result.add_argument("--pole-width-ratio", type=float, default=0.012)
    result.add_argument("--pole-outline-ratio", type=float, default=0.004)
    result.add_argument("--subject-height", type=float, default=0.36)
    result.add_argument("--max-subject-width", type=float, default=0.84)
    result.add_argument(
        "--subject-anchor-x",
        type=float,
        default=0.535,
        help="透明主体中应与轨道重合的横向比例",
    )
    result.add_argument("--top-margin", type=float, default=0.045)
    result.add_argument("--bottom-margin", type=float, default=0.045)
    return result


if __name__ == "__main__":
    try:
        raise SystemExit(build(parser().parse_args()))
    except (FileNotFoundError, ValueError) as error:
        raise SystemExit(f"错误：{error}") from error

````

<!-- ===== FILE: scripts/composite_alpha_keyframe.py ===== -->
````py
#!/usr/bin/env python3
"""Composite a native-transparent keyframe onto a uniform video chroma backdrop."""

from __future__ import annotations

import argparse
import re
from pathlib import Path

from PIL import Image


def parse_color(value: str) -> tuple[int, int, int, int]:
    if not re.fullmatch(r"#[0-9a-fA-F]{6}", value):
        raise SystemExit(f"invalid key color: {value}; expected #RRGGBB")
    return tuple(int(value[index : index + 2], 16) for index in (1, 3, 5)) + (255,)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", help="Accepted native-transparent keyframe PNG")
    parser.add_argument("output", help="RGB PNG for the video model")
    parser.add_argument("--key-color", default="#00FF00")
    args = parser.parse_args()

    source = Path(args.source).expanduser().resolve()
    output = Path(args.output).expanduser().resolve()
    if source == output:
        raise SystemExit("source and output must differ; preserve the native-transparent keyframe")

    with Image.open(source) as opened:
        if "A" not in opened.getbands():
            raise SystemExit("source has no alpha channel; regenerate it with native transparency")
        foreground = opened.convert("RGBA")
    alpha_min, alpha_max = foreground.getchannel("A").getextrema()
    if alpha_min > 16 or alpha_max <= 16:
        raise SystemExit("source must contain both transparent background and visible subject pixels")

    background = Image.new("RGBA", foreground.size, parse_color(args.key_color))
    background.alpha_composite(foreground)
    output.parent.mkdir(parents=True, exist_ok=True)
    background.convert("RGB").save(output)
    print(output)


if __name__ == "__main__":
    main()

````

<!-- ===== FILE: scripts/create_explainer.py ===== -->
````py
#!/usr/bin/env python3
"""从通用模板生成独立的动画原理展示页。"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
from typing import Any


SKILL_ROOT = Path(__file__).resolve().parent.parent
TEMPLATE_PATH = SKILL_ROOT / "assets" / "motion-explainer-template.html"
CONFIG_PLACEHOLDER = "__MOTION_EXPLAINER_CONFIG__"
DRIVERS = ("pointer-angle", "pointer-x", "drag", "scroll", "autoplay")
PLAY_MODES = ("loop", "pingpong", "once")


def positive_int(value: str) -> int:
    number = int(value)
    if number <= 0:
        raise argparse.ArgumentTypeError("必须是正整数")
    return number


def positive_float(value: str) -> float:
    number = float(value)
    if number <= 0:
        raise argparse.ArgumentTypeError("必须大于 0")
    return number


def load_manifest(path: Path | None) -> dict[str, Any]:
    if path is None:
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        raise SystemExit(f"无法读取 manifest：{error}") from error
    if not isinstance(data, dict):
        raise SystemExit("manifest 顶层必须是 JSON 对象")
    return data


def first_value(
    explicit: Any,
    manifest: dict[str, Any],
    *keys: str,
    default: Any = None,
) -> Any:
    if explicit is not None:
        return explicit
    for key in keys:
        if key in manifest and manifest[key] is not None:
            return manifest[key]
    return default


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="生成带雪碧图、母版视频和实时帧高亮的独立 HTML 展示页。"
    )
    parser.add_argument("--title", default="一张图，很多种运动。")
    parser.add_argument(
        "--atlas-url",
        required=True,
        help="HTML 中使用的图集 URL；相对地址以输出 HTML 所在目录为基准。",
    )
    parser.add_argument(
        "--video-url",
        help="可选母版视频 URL；不传时隐藏视频 Tab。",
    )
    parser.add_argument("--manifest", type=Path, help="可选本地图集 manifest。")
    parser.add_argument("--frames", type=positive_int)
    parser.add_argument("--columns", type=positive_int)
    parser.add_argument("--rows", type=positive_int)
    parser.add_argument("--cell-width", type=positive_int)
    parser.add_argument("--cell-height", type=positive_int)
    parser.add_argument("--rest-frame", type=int)
    parser.add_argument("--driver", choices=DRIVERS, default="pointer-angle")
    parser.add_argument("--angle-start-deg", type=float)
    parser.add_argument("--smooth-time", type=positive_float, default=0.11)
    parser.add_argument("--max-frame-speed", type=positive_float)
    parser.add_argument("--autoplay-fps", type=positive_float, default=24)
    parser.add_argument(
        "--autoplay-mode",
        choices=PLAY_MODES,
        default="loop",
    )
    parser.add_argument("--scroll-pages", type=positive_float, default=3)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--force", action="store_true")
    return parser.parse_args()


def build_config(args: argparse.Namespace) -> dict[str, Any]:
    manifest = load_manifest(args.manifest)
    frame_count = int(
        first_value(args.frames, manifest, "frameCount", "frames", default=0)
    )
    columns = int(first_value(args.columns, manifest, "columns", default=0))
    rows = int(first_value(args.rows, manifest, "rows", default=0))
    cell_width = int(
        first_value(args.cell_width, manifest, "cellWidth", default=1)
    )
    cell_height = int(
        first_value(args.cell_height, manifest, "cellHeight", default=1)
    )

    if frame_count <= 0 or columns <= 0 or rows <= 0:
        raise SystemExit(
            "缺少图集尺寸：请提供 --frames、--columns、--rows，或传入包含这些字段的 manifest。"
        )
    if columns * rows < frame_count:
        raise SystemExit(
            f"图集网格只有 {columns * rows} 个格子，无法容纳 {frame_count} 帧。"
        )
    if cell_width <= 0 or cell_height <= 0:
        raise SystemExit("cellWidth 和 cellHeight 必须大于 0。")

    rest_frame = int(
        first_value(
            args.rest_frame,
            manifest,
            "initialFrame",
            "restFrame",
            default=0,
        )
    )
    if not 0 <= rest_frame < frame_count:
        raise SystemExit(
            f"rest frame 必须位于 0 到 {frame_count - 1} 之间。"
        )

    manifest_angle = manifest.get("startAngleRadians")
    if args.angle_start_deg is not None:
        angle_start_deg = args.angle_start_deg
    elif manifest_angle is not None:
        angle_start_deg = math.degrees(float(manifest_angle))
    else:
        angle_start_deg = -135

    max_frame_speed = (
        args.max_frame_speed
        if args.max_frame_speed is not None
        else max(60.0, frame_count * 2.0)
    )

    return {
        "title": args.title,
        "atlasUrl": args.atlas_url,
        "videoUrl": args.video_url or "",
        "frameCount": frame_count,
        "columns": columns,
        "rows": rows,
        "cellWidth": cell_width,
        "cellHeight": cell_height,
        "restFrame": rest_frame,
        "driver": args.driver,
        "angleStartDeg": angle_start_deg,
        "smoothTime": args.smooth_time,
        "maxFrameSpeed": max_frame_speed,
        "autoplayFps": args.autoplay_fps,
        "autoplayMode": args.autoplay_mode,
        "scrollPages": args.scroll_pages,
    }


def main() -> None:
    args = parse_args()
    if args.output.exists() and not args.force:
        raise SystemExit(
            f"输出已存在：{args.output}。确认后使用 --force 覆盖。"
        )
    if not TEMPLATE_PATH.exists():
        raise SystemExit(f"找不到模板：{TEMPLATE_PATH}")

    template = TEMPLATE_PATH.read_text(encoding="utf-8")
    if template.count(CONFIG_PLACEHOLDER) != 1:
        raise SystemExit("模板配置占位符缺失或不唯一。")

    config = build_config(args)
    embedded = json.dumps(
        config,
        ensure_ascii=False,
        separators=(",", ":"),
    ).replace("</", "<\\/")
    output = template.replace(CONFIG_PLACEHOLDER, embedded)

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(output, encoding="utf-8")
    print(f"已生成：{args.output.resolve()}")
    print(
        "配置："
        f"{config['frameCount']} 帧，"
        f"{config['columns']}×{config['rows']}，"
        f"driver={config['driver']}"
    )


if __name__ == "__main__":
    main()

````

<!-- ===== FILE: scripts/loop_cleanup.py ===== -->
````py
#!/usr/bin/env python3
"""清理 AI 闭环视频切帧中的重复帧和尾部停帧。"""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

from PIL import Image, ImageChops, ImageStat


IMAGE_SUFFIXES = {".png", ".webp", ".jpg", ".jpeg"}


def difference(left: Path, right: Path, sample_size: int = 128) -> float:
    with Image.open(left) as first, Image.open(right) as second:
        def visible_rgb(image: Image.Image) -> Image.Image:
            if "A" not in image.getbands():
                return image.convert("RGB")
            rgba = image.convert("RGBA")
            background = Image.new("RGBA", rgba.size, (255, 255, 255, 255))
            return Image.alpha_composite(background, rgba).convert("RGB")

        first_rgb = visible_rgb(first)
        second_rgb = visible_rgb(second)
        first_rgb.thumbnail((sample_size, sample_size), Image.Resampling.LANCZOS)
        second_rgb.thumbnail((sample_size, sample_size), Image.Resampling.LANCZOS)
        if first_rgb.size != second_rgb.size:
            second_rgb = second_rgb.resize(first_rgb.size, Image.Resampling.LANCZOS)
        means = ImageStat.Stat(ImageChops.difference(first_rgb, second_rgb)).mean
        return sum(means) / (3 * 255)


def frames_in(directory: Path) -> list[Path]:
    return sorted(
        path
        for path in directory.iterdir()
        if path.is_file() and path.suffix.lower() in IMAGE_SUFFIXES
    )


def clean(args: argparse.Namespace) -> int:
    source = Path(args.source).expanduser().resolve()
    output = Path(args.output).expanduser().resolve()
    report_path = (
        Path(args.report).expanduser().resolve()
        if args.report
        else output.parent / f"{output.name}-cleanup.json"
    )
    frames = frames_in(source)
    if len(frames) < 3:
        raise ValueError("至少需要 3 帧")
    if output.exists() and any(output.iterdir()) and not args.force:
        raise FileExistsError(f"输出目录非空：{output}；确认后使用 --force")
    output.mkdir(parents=True, exist_ok=True)
    if args.force:
        for item in output.iterdir():
            if item.is_file() or item.is_symlink():
                item.unlink()
            elif item.is_dir():
                shutil.rmtree(item)

    seam_window_start = max(1, len(frames) - args.seam_window)
    end_reference = (
        Path(args.end_reference).expanduser().resolve()
        if args.end_reference
        else frames[0]
    )
    seam_candidates = [
        (index, difference(end_reference, frames[index]))
        for index in range(seam_window_start, len(frames))
    ]
    seam_index, seam_difference = min(seam_candidates, key=lambda item: item[1])

    kept = [0]
    dropped: list[dict[str, float | int | str]] = []
    for index in range(1, seam_index):
        delta = difference(frames[kept[-1]], frames[index])
        if delta < args.duplicate_threshold:
            dropped.append(
                {
                    "index": index,
                    "file": frames[index].name,
                    "difference": round(delta, 8),
                }
            )
            continue
        kept.append(index)
    if kept[-1] != seam_index:
        kept.append(seam_index)

    digits = max(5, len(str(len(kept))))
    for output_index, source_index in enumerate(kept, start=1):
        source_path = frames[source_index]
        target = output / f"frame_{output_index:0{digits}d}{source_path.suffix.lower()}"
        shutil.copy2(source_path, target)

    report = {
        "source": str(source),
        "output": str(output),
        "inputFrameCount": len(frames),
        "outputFrameCount": len(kept),
        "seamWindow": args.seam_window,
        "endReference": str(end_reference),
        "seamSourceIndex": seam_index,
        "seamDifference": round(seam_difference, 8),
        "duplicateThreshold": args.duplicate_threshold,
        "keptSourceIndices": kept,
        "droppedNearDuplicates": dropped,
        "trimmedTailSourceIndices": list(range(seam_index + 1, len(frames))),
    }
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(
        json.dumps(report, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0


def parser() -> argparse.ArgumentParser:
    result = argparse.ArgumentParser(
        description="选择最接近首帧的尾部接缝，并删除视觉近重复帧"
    )
    result.add_argument("source")
    result.add_argument("output")
    result.add_argument(
        "--seam-window",
        type=int,
        default=24,
        help="只在最后 N 帧中寻找最接近首帧的接缝",
    )
    result.add_argument(
        "--end-reference",
        help="单向转场的目标尾帧；省略时使用首帧，适合闭环",
    )
    result.add_argument(
        "--duplicate-threshold",
        type=float,
        default=0.003,
        help="与上一保留帧的归一化 RGB 差异低于此值时删除",
    )
    result.add_argument("--report")
    result.add_argument("--force", action="store_true")
    return result


if __name__ == "__main__":
    try:
        raise SystemExit(clean(parser().parse_args()))
    except (FileNotFoundError, FileExistsError, ValueError) as error:
        raise SystemExit(f"错误：{error}") from error

````

<!-- ===== FILE: scripts/media_edges.py ===== -->
````py
#!/usr/bin/env python3
"""确定性提取视频首帧与实际尾帧。"""

from __future__ import annotations

import subprocess
from pathlib import Path


def extract_edge_frame(video: str | Path, output: str | Path, edge: str) -> None:
    source = Path(video).expanduser().resolve()
    target = Path(output).expanduser().resolve()
    if not source.is_file():
        raise FileNotFoundError(f"视频不存在：{source}")
    if edge not in {"head", "tail"}:
        raise ValueError("edge 必须是 head 或 tail")
    target.parent.mkdir(parents=True, exist_ok=True)
    command = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-y"]
    if edge == "tail":
        command.extend(["-sseof", "-3", "-i", str(source), "-update", "1"])
    else:
        command.extend(["-i", str(source), "-frames:v", "1"])
    command.append(str(target))
    completed = subprocess.run(command, capture_output=True, text=True)
    if completed.returncode != 0 or not target.is_file() or target.stat().st_size == 0:
        raise RuntimeError(
            f"无法提取视频{edge}帧：{completed.stderr.strip() or source}"
        )


def extract_first_frame(video: str | Path, output: str | Path) -> None:
    extract_edge_frame(video, output, "head")


def extract_last_frame(video: str | Path, output: str | Path) -> None:
    extract_edge_frame(video, output, "tail")

````

<!-- ===== FILE: scripts/motion_budget.py ===== -->
````py
#!/usr/bin/env python3
"""根据交互方式、显示尺寸和资源预算自动选择网页动画交付方案。"""

from __future__ import annotations

import argparse
import json
import math
import sys
from dataclasses import asdict, dataclass
from pathlib import Path


def parse_size(value: str) -> tuple[int, int]:
    normalized = value.lower().replace("×", "x").strip()
    try:
        width_text, height_text = normalized.split("x", 1)
        width, height = int(width_text), int(height_text)
    except (ValueError, AttributeError) as exc:
        raise argparse.ArgumentTypeError("尺寸必须写成 WIDTHxHEIGHT") from exc
    if width <= 0 or height <= 0:
        raise argparse.ArgumentTypeError("宽高必须大于 0")
    return width, height


@dataclass(frozen=True)
class SizeCheck:
    width: int
    height: int
    required_width: int
    required_height: int
    width_ratio: float
    height_ratio: float
    passes: bool


def check_size(size: tuple[int, int], required: tuple[int, int]) -> SizeCheck:
    width, height = size
    required_width, required_height = required
    return SizeCheck(
        width=width,
        height=height,
        required_width=required_width,
        required_height=required_height,
        width_ratio=round(width / required_width, 3),
        height_ratio=round(height / required_height, 3),
        passes=width >= required_width and height >= required_height,
    )


def resolve_access(args: argparse.Namespace) -> str:
    if args.access != "auto":
        return args.access
    if args.time_control in {"segment-play", "autonomous"}:
        return "sequential"
    if args.parameter_space == "linear" and args.driver in {
        "scroll",
        "audio",
    }:
        return "sequential"
    return "random"


def select_delivery(
    args: argparse.Namespace,
    capacity: int,
    sheets: int | None,
    decoded_mib: float,
    access: str,
) -> dict[str, object]:
    atlas_within_budget = (
        capacity > 0
        and sheets is not None
        and sheets == 1
        and decoded_mib <= args.atlas_max_memory_mib
    )
    reason_codes: list[str] = []

    if args.background_owner == "video":
        selected = "baked-video"
        reason_codes.append("background-baked-into-video")
        if args.parameter_space in {"2d", "discrete"}:
            reason_codes.append("baked-video-needs-independent-clips")
        if (
            access == "sequential"
            and args.parameter_space == "linear"
            and args.frames >= args.linear_video_min_frames
        ):
            reason_codes.append("long-linear-sequence")
    elif args.parameter_space == "2d":
        selected = "alpha-atlas"
        reason_codes.append("two-dimensional-parameter-needs-discrete-frames")
        if not atlas_within_budget:
            reason_codes.append("atlas-needs-budget-optimization")
    elif args.parameter_space == "discrete":
        selected = "alpha-atlas"
        reason_codes.append("discrete-states-need-independent-assets")
        if not atlas_within_budget:
            reason_codes.append("states-need-separate-budgets")
    elif access == "random" and atlas_within_budget:
        selected = "alpha-atlas"
        reason_codes.append("random-access-fits-atlas-budget")
    elif (
        access == "sequential"
        and args.parameter_space == "linear"
        and args.frames >= args.linear_video_min_frames
    ):
        selected = "chroma-video"
        reason_codes.append("long-linear-sequence")
    elif not atlas_within_budget:
        selected = "chroma-video"
        reason_codes.append("atlas-budget-exceeded")
    else:
        selected = "alpha-atlas"
        reason_codes.append("small-asset-fits-atlas-budget")

    return {
        "selected": selected,
        "reasonCodes": reason_codes,
        "atlasWithinBudget": atlas_within_budget,
        "thresholds": {
            "atlasMaxSheets": 1,
            "atlasMaxDecodedMemoryMiB": args.atlas_max_memory_mib,
            "linearVideoMinFrames": args.linear_video_min_frames,
        },
    }


def build_report(args: argparse.Namespace) -> dict[str, object]:
    display_width, display_height = args.display
    required = (
        math.ceil(display_width * args.dpr),
        math.ceil(display_height * args.dpr),
    )
    required_width, required_height = required
    max_columns = args.max_texture // required_width
    max_rows = args.max_texture // required_height
    capacity = max_columns * max_rows
    sheets = math.ceil(args.frames / capacity) if capacity else None
    decoded_mib = (
        required_width * required_height * args.frames * 4 / 1024 / 1024
    )
    access = resolve_access(args)
    delivery = select_delivery(args, capacity, sheets, decoded_mib, access)
    runtime = {
        "renderer": {
            "alpha-atlas": "css-alpha-atlas",
            "chroma-video": "webgl-chroma-video",
            "baked-video": "baked-video",
        }[str(delivery["selected"])],
        "controller": {
            "scrub": "frame-scrub",
            "segment-play": "segment-playback",
            "autonomous": "autonomous-playback",
        }[args.time_control],
    }

    failures: list[str] = []
    source_check = check_size(args.source, required) if args.source else None
    cell_check = check_size(args.cell, required) if args.cell else None
    if source_check and not source_check.passes:
        failures.append("源素材低于最终显示所需像素")
    if (
        cell_check
        and delivery["selected"] == "alpha-atlas"
        and not cell_check.passes
    ):
        failures.append("图集单帧低于最终显示所需像素")
    if delivery["selected"] == "alpha-atlas" and capacity == 0:
        failures.append("单帧已超过纹理尺寸上限")
    if (
        delivery["selected"] == "baked-video"
        and args.parameter_space in {"2d", "discrete"}
    ):
        failures.append(
            "烘焙视频是一条线性时间轴，二维或离散参数必须拆成多条独立片段分别预算"
        )
    if (
        delivery["selected"] == "alpha-atlas"
        and not delivery["atlasWithinBudget"]
    ):
        if args.parameter_space == "discrete":
            failures.append("离散状态合并后超预算，需要拆成独立状态或转场并分别预算")
        else:
            failures.append(
                "二维 Alpha 图集超出单图集或内存预算，需要降低参数采样密度、"
                "拆分参数轴，或在用户确认的显示范围内重新预算"
            )

    temporal_check = None
    if args.scroll_pages is not None:
        required_frames = math.ceil(args.scroll_pages * args.frames_per_page)
        frames_per_page = args.frames / args.scroll_pages
        temporal_check = {
            "scrollPages": args.scroll_pages,
            "framesPerPage": round(frames_per_page, 2),
            "targetFramesPerPage": args.frames_per_page,
            "requiredFrames": required_frames,
            "passes": args.frames >= required_frames,
        }
        if not temporal_check["passes"]:
            failures.append(
                f"滚动采样密度不足：需要至少 {required_frames} 帧"
            )

    return {
        "display": {
            "width": display_width,
            "height": display_height,
            "dpr": args.dpr,
        },
        "requiredCell": {
            "width": required_width,
            "height": required_height,
        },
        "frames": args.frames,
        "texture": {
            "maxSize": args.max_texture,
            "columnsPerSheet": max_columns,
            "rowsPerSheet": max_rows,
            "framesPerSheet": capacity,
            "sheetCount": sheets,
        },
        "decodedFrameMemoryMiB": round(decoded_mib, 1),
        "sourceCheck": asdict(source_check) if source_check else None,
        "cellCheck": asdict(cell_check) if cell_check else None,
        "temporalCheck": temporal_check,
        "driver": args.driver,
        "parameterSpace": args.parameter_space,
        "timeControl": args.time_control,
        "access": access,
        "backgroundOwner": args.background_owner,
        "delivery": delivery,
        "runtime": runtime,
        "failures": failures,
        "passes": not failures,
    }


def print_human(report: dict[str, object]) -> None:
    display = report["display"]
    required = report["requiredCell"]
    texture = report["texture"]
    print(
        f"显示尺寸：{display['width']}×{display['height']} CSS px，"
        f"DPR {display['dpr']}"
    )
    print(f"最低单帧：{required['width']}×{required['height']} px")
    print(
        f"纹理预算：每片最多 {texture['columnsPerSheet']}×"
        f"{texture['rowsPerSheet']} 帧，共需 {texture['sheetCount']} 片"
    )
    print(f"全部帧解码内存理论值：{report['decodedFrameMemoryMiB']} MiB")
    delivery = report["delivery"]
    runtime = report["runtime"]
    print(
        f"背景归属：{report['backgroundOwner']}；"
        f"媒体：{delivery['selected']}；"
        f"控制器：{runtime['controller']}；渲染器：{runtime['renderer']}"
    )
    print("选择依据：" + "、".join(delivery["reasonCodes"]))

    for label, key in (("源素材", "sourceCheck"), ("当前单帧", "cellCheck")):
        check = report[key]
        if check:
            status = "通过" if check["passes"] else "不通过"
            print(
                f"{label}：{check['width']}×{check['height']} px，{status}"
                f"（宽 {check['width_ratio']}×，高 {check['height_ratio']}×）"
            )

    temporal = report["temporalCheck"]
    if temporal:
        status = "通过" if temporal["passes"] else "不通过"
        print(
            f"滚动采样：{temporal['framesPerPage']} 帧/屏，{status}"
            f"（目标 {temporal['targetFramesPerPage']} 帧/屏，"
            f"至少 {temporal['requiredFrames']} 帧）"
        )

    failures = report["failures"]
    if failures:
        print("阻断项：")
        for failure in failures:
            print(f"- {failure}")
    else:
        print("结果：通过")


def main() -> int:
    parser = argparse.ArgumentParser(
        description=(
            "根据 Concept Contract 的背景归属、交互参数、CSS 尺寸、DPR、帧数和纹理预算"
            "自动选择烘焙场景视频、Alpha 图集或绿幕视频。"
        )
    )
    parser.add_argument("--frames", type=int, required=True, help="总帧数")
    parser.add_argument(
        "--display", type=parse_size, required=True, help="最终 CSS 尺寸，如 268x468"
    )
    parser.add_argument("--dpr", type=float, default=2.0, help="目标设备 DPR")
    parser.add_argument(
        "--max-texture", type=int, default=4096, help="保守纹理边长上限"
    )
    parser.add_argument(
        "--driver",
        choices=(
            "pointer",
            "scroll",
            "drag",
            "touch",
            "orientation",
            "audio",
            "data",
            "state",
            "time",
        ),
        default="scroll",
        help="Motion Brief 中的交互驱动，默认 scroll",
    )
    parser.add_argument(
        "--parameter-space",
        choices=("linear", "circular", "2d", "discrete"),
        default="linear",
        help="Motion Brief 中的参数空间，默认 linear",
    )
    parser.add_argument(
        "--time-control",
        choices=("scrub", "segment-play", "autonomous"),
        required=True,
        help="Concept Contract 中的时间控制方式，必须显式传入",
    )
    parser.add_argument(
        "--access",
        choices=("auto", "random", "sequential"),
        default="auto",
        help="运行时主要访问方式；默认根据 driver 与 parameter-space 自动推断",
    )
    parser.add_argument(
        "--background-owner",
        choices=("page", "video"),
        required=True,
        help=(
            "背景归属，来自 Concept Contract：video 表示背景与主体在同一视频中"
            "烘焙生成（baked-video，默认场景路线）；page 表示主体需要透明复用，"
            "由预算在 alpha-atlas 与 chroma-video 之间选择。必须显式传入，"
            "禁止因遗漏参数而静默回退到绿幕路线"
        ),
    )
    parser.add_argument(
        "--atlas-max-memory-mib",
        type=float,
        default=192.0,
        help="自动优先选择 Alpha 图集时允许的理论解码内存，默认 192 MiB",
    )
    parser.add_argument(
        "--linear-video-min-frames",
        type=int,
        default=180,
        help="一维顺序动画自动优先视频的帧数门槛，默认 180",
    )
    parser.add_argument("--source", type=parse_size, help="源视频或母版帧尺寸")
    parser.add_argument("--cell", type=parse_size, help="当前图集单帧尺寸")
    parser.add_argument(
        "--scroll-pages",
        type=float,
        help="滚动驱动覆盖的视口屏数；传入后同时检查时间采样密度",
    )
    parser.add_argument(
        "--frames-per-page",
        type=float,
        default=24.0,
        help="每屏目标帧数，默认 24",
    )
    parser.add_argument("--json", action="store_true", help="输出 JSON")
    parser.add_argument("--report", type=Path, help="同时把完整 JSON 报告写入指定路径")
    parser.add_argument(
        "--strict", action="store_true", help="存在阻断项时返回非零退出码"
    )
    args = parser.parse_args()

    if args.frames <= 0:
        parser.error("--frames 必须大于 0")
    if args.dpr <= 0:
        parser.error("--dpr 必须大于 0")
    if args.max_texture <= 0:
        parser.error("--max-texture 必须大于 0")
    if args.atlas_max_memory_mib <= 0:
        parser.error("--atlas-max-memory-mib 必须大于 0")
    if args.linear_video_min_frames <= 0:
        parser.error("--linear-video-min-frames 必须大于 0")
    if args.scroll_pages is not None and args.scroll_pages <= 0:
        parser.error("--scroll-pages 必须大于 0")
    if args.frames_per_page <= 0:
        parser.error("--frames-per-page 必须大于 0")

    report = build_report(args)
    if args.report:
        report_path = args.report.expanduser().resolve()
        report_path.parent.mkdir(parents=True, exist_ok=True)
        report_path.write_text(
            json.dumps(report, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
    if args.json:
        print(json.dumps(report, ensure_ascii=False, indent=2))
    else:
        print_human(report)
    return 2 if args.strict and not report["passes"] else 0


if __name__ == "__main__":
    sys.exit(main())

````

<!-- ===== FILE: scripts/motion_pipeline.py ===== -->
````py
#!/usr/bin/env python3
"""Deterministic media pipeline for interactive motion assets.

Commands:
  probe      Inspect video metadata with ffprobe.
  extract    Extract ordered frames and optionally remove a uniform key color.
  normalize  Correct small scale/anchor drift in fixed-subject transparent frames.
  analyze    Detect blank, duplicate, scale, center, and brightness anomalies.
  contact    Build a numbered checkerboard contact sheet.
  atlas      Pack ordered frames into a PNG/WebP atlas and JSON manifest.
  build      Run extract, optional normalize, analyze, contact, and atlas.
"""

from __future__ import annotations

import argparse
import json
import math
import re
import shutil
import subprocess
import tempfile
from pathlib import Path
from statistics import median
from typing import Any, Iterable

from PIL import Image, ImageChops, ImageDraw, ImageFont, ImageStat


IMAGE_SUFFIXES = {".png", ".webp", ".jpg", ".jpeg"}
ALPHA_NOISE_FLOOR = 8
KEY_DOMINANCE_THRESHOLD = 16


def natural_key(path: Path) -> list[Any]:
    return [
        int(part) if part.isdigit() else part.lower()
        for part in re.split(r"(\d+)", path.name)
    ]


def frame_files(path: Path) -> list[Path]:
    return sorted(
        (
            item
            for item in path.iterdir()
            if item.is_file() and item.suffix.lower() in IMAGE_SUFFIXES
        ),
        key=natural_key,
    )


def require_tool(name: str) -> str:
    resolved = shutil.which(name)
    if not resolved:
        raise SystemExit(f"Required tool not found: {name}")
    return resolved


def run(command: list[str]) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        command,
        check=True,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(value, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )


def prepare_output_directory(path: Path, force: bool) -> None:
    if path.exists() and any(path.iterdir()):
        if not force:
            raise SystemExit(
                f"Output directory is not empty: {path}. Use --force only for a disposable build target."
            )
        shutil.rmtree(path)
    path.mkdir(parents=True, exist_ok=True)


def parse_hex_color(value: str) -> tuple[int, int, int]:
    normalized = value.strip().lower().replace("0x", "").lstrip("#")
    if len(normalized) == 3:
        normalized = "".join(character * 2 for character in normalized)
    if len(normalized) != 6 or any(
        character not in "0123456789abcdef" for character in normalized
    ):
        raise SystemExit(f"Invalid key color: {value}")
    return tuple(
        int(normalized[index : index + 2], 16) for index in (0, 2, 4)
    )


def clamp_byte(value: float) -> int:
    return max(0, min(255, int(round(value))))


def color_distance(
    color: tuple[int, int, int],
    key: tuple[int, int, int],
) -> int:
    return max(abs(color[index] - key[index]) for index in range(3))


def smoothstep(value: float) -> float:
    normalized = max(0.0, min(1.0, value))
    return normalized * normalized * (3.0 - 2.0 * normalized)


def distance_alpha(
    distance: int,
    transparent_threshold: float,
    opaque_threshold: float,
) -> int:
    if distance <= transparent_threshold:
        return 0
    if distance >= opaque_threshold:
        return 255
    ratio = (distance - transparent_threshold) / (
        opaque_threshold - transparent_threshold
    )
    return clamp_byte(255 * smoothstep(ratio))


def key_channels(key: tuple[int, int, int]) -> list[int]:
    strongest = max(key)
    if strongest < 128:
        return []
    return [
        index
        for index, value in enumerate(key)
        if value >= strongest - 16 and value >= 128
    ]


def key_dominance(
    color: tuple[int, int, int],
    key: tuple[int, int, int],
) -> int:
    selected = key_channels(key)
    if not selected:
        return 0
    other = [index for index in range(3) if index not in selected]
    key_strength = min(color[index] for index in selected)
    other_strength = max((color[index] for index in other), default=0)
    return key_strength - other_strength


def dominance_alpha(
    color: tuple[int, int, int],
    key: tuple[int, int, int],
) -> int:
    selected = key_channels(key)
    if not selected:
        return 255
    other = [index for index in range(3) if index not in selected]
    key_strength = min(color[index] for index in selected)
    other_strength = max((color[index] for index in other), default=0)
    dominance = key_strength - other_strength
    if dominance <= 0:
        return 255
    denominator = max(1, max(key) - other_strength)
    return clamp_byte(255 * (1 - min(1.0, dominance / denominator)))


def looks_key_colored(
    color: tuple[int, int, int],
    key: tuple[int, int, int],
    distance: int,
) -> bool:
    if distance <= 32:
        return True
    if not key_channels(key):
        return True
    return key_dominance(color, key) >= KEY_DOMINANCE_THRESHOLD


def despill(
    color: tuple[int, int, int],
    key: tuple[int, int, int],
    alpha: int,
) -> tuple[int, int, int]:
    if alpha >= 252:
        return color
    selected = key_channels(key)
    other = [index for index in range(3) if index not in selected]
    if not selected or not other:
        return color
    channels = list(color)
    neutral_edge = max(channels[index] for index in other)
    for index in selected:
        channels[index] = min(channels[index], neutral_edge)
    return channels[0], channels[1], channels[2]


def sample_border_key(image: Image.Image) -> tuple[int, int, int]:
    rgba = image.convert("RGBA")
    pixels = rgba.load()
    width, height = rgba.size
    band = max(1, min(width, height, 6))
    step = max(1, min(width, height) // 256)
    samples: list[tuple[int, int, int]] = []
    for x in range(0, width, step):
        for offset in range(band):
            samples.append(pixels[x, offset][:3])
            samples.append(pixels[x, height - 1 - offset][:3])
    for y in range(0, height, step):
        for offset in range(band):
            samples.append(pixels[offset, y][:3])
            samples.append(pixels[width - 1 - offset, y][:3])
    return tuple(
        int(round(median(sample[channel] for sample in samples)))
        for channel in range(3)
    )


def remove_key(
    source: Path,
    output: Path,
    key: tuple[int, int, int],
    transparent_threshold: float,
    opaque_threshold: float,
) -> dict[str, int]:
    image = Image.open(source).convert("RGBA")
    pixels = image.load()
    transparent = 0
    partial = 0
    for y in range(image.height):
        for x in range(image.width):
            red, green, blue, source_alpha = pixels[x, y]
            color = (red, green, blue)
            distance = color_distance(color, key)
            key_like = looks_key_colored(color, key, distance)
            alpha = distance_alpha(
                distance,
                transparent_threshold,
                opaque_threshold,
            )
            if key_like:
                alpha = min(alpha, dominance_alpha(color, key))
            alpha = clamp_byte(alpha * (source_alpha / 255))
            if alpha <= ALPHA_NOISE_FLOOR:
                pixels[x, y] = (0, 0, 0, 0)
                transparent += 1
                continue
            if key_like:
                red, green, blue = despill(color, key, alpha)
            pixels[x, y] = (red, green, blue, alpha)
            if alpha < 255:
                partial += 1
    output.parent.mkdir(parents=True, exist_ok=True)
    image.save(output)
    return {"transparentPixels": transparent, "partialPixels": partial}


def probe_video(path: Path) -> dict[str, Any]:
    ffprobe = require_tool("ffprobe")
    result = run(
        [
            ffprobe,
            "-v",
            "error",
            "-show_entries",
            "format=duration,size,bit_rate:stream=index,codec_type,codec_name,width,height,pix_fmt,r_frame_rate,avg_frame_rate,nb_frames",
            "-of",
            "json",
            str(path),
        ]
    )
    return json.loads(result.stdout)


def command_probe(args: argparse.Namespace) -> None:
    source = args.input.expanduser().resolve()
    if not source.is_file():
        raise SystemExit(f"Input video not found: {source}")
    data = probe_video(source)
    if args.output:
        write_json(args.output.expanduser().resolve(), data)
    print(json.dumps(data, ensure_ascii=False, indent=2))


def build_video_filter(args: argparse.Namespace) -> str:
    filters: list[str] = []
    if args.interpolate:
        filters.append(
            "minterpolate="
            f"fps={args.fps}:mi_mode=mci:mc_mode=aobmc:me_mode=bidir:vsbmc=1"
        )
    else:
        filters.append(f"fps={args.fps}")
    if args.width and args.height:
        filters.append(
            f"scale={args.width}:{args.height}:force_original_aspect_ratio=decrease"
        )
        filters.append(
            f"pad={args.width}:{args.height}:(ow-iw)/2:(oh-ih)/2:color=0x00FF00"
        )
    elif args.width:
        filters.append(f"scale={args.width}:-2")
    elif args.height:
        filters.append(f"scale=-2:{args.height}")
    return ",".join(filters)


def extract_frames(args: argparse.Namespace) -> dict[str, Any]:
    source = args.input.expanduser().resolve()
    output = args.output.expanduser().resolve()
    if not source.is_file():
        raise SystemExit(f"Input video not found: {source}")
    if not 0 <= args.transparent_threshold < args.opaque_threshold <= 255:
        raise SystemExit(
            "Thresholds must satisfy 0 <= transparent < opaque <= 255"
        )
    prepare_output_directory(output, args.force)
    ffmpeg = require_tool("ffmpeg")
    key_enabled = args.key.lower() != "none"

    with tempfile.TemporaryDirectory(prefix="oil-motion-raw-") as temp:
        raw = Path(temp) if key_enabled else output
        command = [ffmpeg, "-hide_banner", "-loglevel", "error"]
        if args.start is not None:
            command.extend(["-ss", str(args.start)])
        command.extend(["-i", str(source)])
        if args.duration is not None:
            command.extend(["-t", str(args.duration)])
        command.extend(
            [
                "-an",
                "-vf",
                build_video_filter(args),
                "-fps_mode",
                "passthrough",
                str(raw / "frame_%05d.png"),
            ]
        )
        run(command)
        raw_frames = frame_files(raw)
        if not raw_frames:
            raise SystemExit("ffmpeg produced no frames")

        key: tuple[int, int, int] | None = None
        cutout_stats: dict[str, int] = {
            "transparentPixels": 0,
            "partialPixels": 0,
        }
        if key_enabled:
            with Image.open(raw_frames[0]) as first:
                key = (
                    sample_border_key(first)
                    if args.key.lower() == "auto"
                    else parse_hex_color(args.key)
                )
            for index, frame in enumerate(raw_frames, start=1):
                stats = remove_key(
                    frame,
                    output / f"frame_{index:05d}.png",
                    key,
                    args.transparent_threshold,
                    args.opaque_threshold,
                )
                cutout_stats["transparentPixels"] += stats[
                    "transparentPixels"
                ]
                cutout_stats["partialPixels"] += stats["partialPixels"]

    frames = frame_files(output)
    first_image = Image.open(frames[0])
    width, height = first_image.size
    first_image.close()
    manifest = {
        "source": str(source),
        "frameCount": len(frames),
        "fps": args.fps,
        "width": width,
        "height": height,
        "interpolated": bool(args.interpolate),
        "key": (
            None
            if key is None
            else f"#{key[0]:02X}{key[1]:02X}{key[2]:02X}"
        ),
        "transparentThreshold": (
            args.transparent_threshold if key is not None else None
        ),
        "opaqueThreshold": args.opaque_threshold if key is not None else None,
        "cutout": cutout_stats if key is not None else None,
    }
    write_json(output / "extract.json", manifest)
    return manifest


def command_extract(args: argparse.Namespace) -> None:
    manifest = extract_frames(args)
    print(json.dumps(manifest, ensure_ascii=False, indent=2))


def alpha_bbox(image: Image.Image, threshold: int = 16) -> tuple[int, int, int, int] | None:
    alpha = image.convert("RGBA").getchannel("A")
    mask = alpha.point(lambda value: 255 if value >= threshold else 0)
    return mask.getbbox()


def normalize_frames(args: argparse.Namespace) -> dict[str, Any]:
    source = args.input.expanduser().resolve()
    output = args.output.expanduser().resolve()
    if not source.is_dir():
        raise SystemExit(f"Frame directory not found: {source}")
    frames = frame_files(source)
    if not frames:
        raise SystemExit(f"No frames found: {source}")
    prepare_output_directory(output, args.force)

    measurements: list[dict[str, float | tuple[int, int, int, int] | Path]] = []
    canvas_size: tuple[int, int] | None = None
    for path in frames:
        with Image.open(path) as opened:
            image = opened.convert("RGBA")
        canvas_size = canvas_size or image.size
        if image.size != canvas_size:
            raise SystemExit("All frames must share one canvas size")
        bbox = alpha_bbox(image, args.alpha_threshold)
        if bbox is None:
            raise SystemExit(f"Cannot normalize blank frame: {path}")
        left, top, right, bottom = bbox
        measurements.append(
            {
                "path": path,
                "bbox": bbox,
                "width": right - left,
                "height": bottom - top,
                "centerX": (left + right) / 2,
                "centerY": (top + bottom) / 2,
                "bottom": bottom,
            }
        )

    target_height = median(float(item["height"]) for item in measurements)
    target_center_x = median(
        float(item["centerX"]) for item in measurements
    )
    target_center_y = median(
        float(item["centerY"]) for item in measurements
    )
    target_bottom = median(float(item["bottom"]) for item in measurements)
    assert canvas_size is not None

    applied_scales: list[float] = []
    for index, item in enumerate(measurements, start=1):
        path = item["path"]
        bbox = item["bbox"]
        assert isinstance(path, Path)
        assert isinstance(bbox, tuple)
        with Image.open(path) as opened:
            image = opened.convert("RGBA")
        crop = image.crop(bbox)
        raw_scale = target_height / max(1.0, float(item["height"]))
        scale = max(
            1 - args.max_scale_change,
            min(1 + args.max_scale_change, raw_scale),
        )
        applied_scales.append(scale)
        resized = crop.resize(
            (
                max(1, round(crop.width * scale)),
                max(1, round(crop.height * scale)),
            ),
            Image.Resampling.LANCZOS,
        )
        if args.anchor == "bottom":
            left = round(target_center_x - resized.width / 2)
            top = round(target_bottom - resized.height)
        else:
            left = round(target_center_x - resized.width / 2)
            top = round(target_center_y - resized.height / 2)
        canvas = Image.new("RGBA", canvas_size, (0, 0, 0, 0))
        canvas.paste(resized, (left, top), resized)
        canvas.save(output / f"frame_{index:05d}.png")

    manifest = {
        "source": str(source),
        "frameCount": len(frames),
        "anchor": args.anchor,
        "targetHeight": target_height,
        "targetCenterX": target_center_x,
        "targetCenterY": target_center_y,
        "targetBottom": target_bottom,
        "maxScaleChange": args.max_scale_change,
        "minAppliedScale": min(applied_scales),
        "maxAppliedScale": max(applied_scales),
    }
    write_json(output / "normalize.json", manifest)
    return manifest


def command_normalize(args: argparse.Namespace) -> None:
    manifest = normalize_frames(args)
    print(json.dumps(manifest, ensure_ascii=False, indent=2))


def flatten_for_difference(image: Image.Image, size: int = 96) -> Image.Image:
    rgba = image.convert("RGBA")
    background = Image.new("RGBA", rgba.size, (255, 255, 255, 255))
    background.alpha_composite(rgba)
    return background.convert("RGB").resize(
        (size, size),
        Image.Resampling.BILINEAR,
    )


def visible_luminance(image: Image.Image) -> float:
    rgba = image.convert("RGBA")
    gray = rgba.convert("L")
    alpha = rgba.getchannel("A")
    if not alpha.getbbox():
        return 0.0
    return float(ImageStat.Stat(gray, alpha).mean[0]) / 255


def mean_difference(first: Image.Image, second: Image.Image) -> float:
    difference = ImageChops.difference(first, second)
    means = ImageStat.Stat(difference).mean
    return float(sum(means) / len(means)) / 255


def analyze_directory(
    source: Path,
    alpha_threshold: int,
    duplicate_threshold: float,
    brightness_jump: float,
    scale_jump: float,
    center_jump: float,
) -> dict[str, Any]:
    frames = frame_files(source)
    if not frames:
        raise SystemExit(f"No frames found: {source}")
    frame_data: list[dict[str, Any]] = []
    warnings: list[dict[str, Any]] = []
    previous_flat: Image.Image | None = None
    previous: dict[str, Any] | None = None
    canvas_size: tuple[int, int] | None = None

    for index, path in enumerate(frames):
        with Image.open(path) as opened:
            image = opened.convert("RGBA")
        canvas_size = canvas_size or image.size
        if image.size != canvas_size:
            warnings.append(
                {
                    "frame": index,
                    "type": "canvas-size",
                    "message": f"{path.name} has size {image.size}, expected {canvas_size}",
                }
            )
        bbox = alpha_bbox(image, alpha_threshold)
        item: dict[str, Any] = {
            "index": index,
            "file": path.name,
            "width": image.width,
            "height": image.height,
            "bbox": list(bbox) if bbox else None,
            "luminance": visible_luminance(image),
        }
        if bbox:
            left, top, right, bottom = bbox
            item.update(
                {
                    "subjectWidthRatio": (right - left) / image.width,
                    "subjectHeightRatio": (bottom - top) / image.height,
                    "centerX": ((left + right) / 2) / image.width,
                    "centerY": ((top + bottom) / 2) / image.height,
                    "occupancy": (
                        ((right - left) * (bottom - top))
                        / (image.width * image.height)
                    ),
                }
            )
        else:
            warnings.append(
                {
                    "frame": index,
                    "type": "blank",
                    "message": f"{path.name} has no visible alpha content",
                }
            )

        flat = flatten_for_difference(image)
        if previous_flat is not None:
            difference = mean_difference(previous_flat, flat)
            item["differenceFromPrevious"] = difference
            if difference < duplicate_threshold:
                warnings.append(
                    {
                        "frame": index,
                        "type": "near-duplicate",
                        "value": difference,
                        "message": f"{path.name} is very similar to its previous frame",
                    }
                )
        if previous and bbox and previous.get("bbox"):
            luminance_delta = abs(item["luminance"] - previous["luminance"])
            scale_delta = abs(
                item["subjectHeightRatio"] - previous["subjectHeightRatio"]
            )
            center_delta = math.hypot(
                item["centerX"] - previous["centerX"],
                item["centerY"] - previous["centerY"],
            )
            if luminance_delta > brightness_jump:
                warnings.append(
                    {
                        "frame": index,
                        "type": "brightness-jump",
                        "value": luminance_delta,
                        "message": f"{path.name} changes brightness abruptly",
                    }
                )
            if scale_delta > scale_jump:
                warnings.append(
                    {
                        "frame": index,
                        "type": "scale-jump",
                        "value": scale_delta,
                        "message": f"{path.name} changes subject scale abruptly",
                    }
                )
            if center_delta > center_jump:
                warnings.append(
                    {
                        "frame": index,
                        "type": "center-jump",
                        "value": center_delta,
                        "message": f"{path.name} moves the subject center abruptly",
                    }
                )
        frame_data.append(item)
        previous_flat = flat
        previous = item

    subject_heights = [
        item["subjectHeightRatio"]
        for item in frame_data
        if "subjectHeightRatio" in item
    ]
    centers_x = [item["centerX"] for item in frame_data if "centerX" in item]
    centers_y = [item["centerY"] for item in frame_data if "centerY" in item]
    differences = [
        item["differenceFromPrevious"]
        for item in frame_data
        if "differenceFromPrevious" in item
    ]
    return {
        "source": str(source),
        "frameCount": len(frames),
        "canvas": list(canvas_size) if canvas_size else None,
        "summary": {
            "medianSubjectHeightRatio": (
                median(subject_heights) if subject_heights else None
            ),
            "subjectHeightRange": (
                [min(subject_heights), max(subject_heights)]
                if subject_heights
                else None
            ),
            "centerXRange": (
                [min(centers_x), max(centers_x)] if centers_x else None
            ),
            "centerYRange": (
                [min(centers_y), max(centers_y)] if centers_y else None
            ),
            "medianFrameDifference": (
                median(differences) if differences else None
            ),
            "warningCount": len(warnings),
        },
        "warnings": warnings,
        "frames": frame_data,
    }


def command_analyze(args: argparse.Namespace) -> None:
    source = args.input.expanduser().resolve()
    if not source.is_dir():
        raise SystemExit(f"Frame directory not found: {source}")
    report = analyze_directory(
        source,
        args.alpha_threshold,
        args.duplicate_threshold,
        args.brightness_jump,
        args.scale_jump,
        args.center_jump,
    )
    if args.output:
        write_json(args.output.expanduser().resolve(), report)
    print(json.dumps(report["summary"], ensure_ascii=False, indent=2))


def checkerboard(size: tuple[int, int], square: int = 12) -> Image.Image:
    image = Image.new("RGB", size, "#f7f7f7")
    draw = ImageDraw.Draw(image)
    for y in range(0, size[1], square):
        for x in range(0, size[0], square):
            if (x // square + y // square) % 2:
                draw.rectangle(
                    (x, y, x + square - 1, y + square - 1),
                    fill="#dfdfdf",
                )
    return image


def create_contact_sheet(
    source: Path,
    output: Path,
    columns: int,
    thumb_width: int,
) -> dict[str, Any]:
    frames = frame_files(source)
    if not frames:
        raise SystemExit(f"No frames found: {source}")
    with Image.open(frames[0]) as first:
        ratio = first.height / first.width
    thumb_height = max(1, round(thumb_width * ratio))
    label_height = 22
    rows = math.ceil(len(frames) / columns)
    sheet = Image.new(
        "RGB",
        (columns * thumb_width, rows * (thumb_height + label_height)),
        "#ffffff",
    )
    draw = ImageDraw.Draw(sheet)
    font = ImageFont.load_default()
    for index, path in enumerate(frames):
        with Image.open(path) as opened:
            frame = opened.convert("RGBA")
        frame.thumbnail((thumb_width, thumb_height), Image.Resampling.LANCZOS)
        background = checkerboard((thumb_width, thumb_height))
        left = (thumb_width - frame.width) // 2
        top = (thumb_height - frame.height) // 2
        background.paste(frame, (left, top), frame)
        column = index % columns
        row = index // columns
        x = column * thumb_width
        y = row * (thumb_height + label_height)
        sheet.paste(background, (x, y))
        draw.rectangle(
            (x, y + thumb_height, x + thumb_width - 1, y + thumb_height + label_height - 1),
            fill="#111111",
        )
        draw.text(
            (x + 5, y + thumb_height + 5),
            f"{index:04d}",
            fill="#ffffff",
            font=font,
        )
    output.parent.mkdir(parents=True, exist_ok=True)
    save_kwargs: dict[str, Any] = {}
    if output.suffix.lower() in {".jpg", ".jpeg"}:
        save_kwargs = {"quality": 88, "optimize": True}
    sheet.save(output, **save_kwargs)
    return {
        "output": str(output),
        "frameCount": len(frames),
        "columns": columns,
        "rows": rows,
        "thumbWidth": thumb_width,
        "thumbHeight": thumb_height,
    }


def command_contact(args: argparse.Namespace) -> None:
    source = args.input.expanduser().resolve()
    if not source.is_dir():
        raise SystemExit(f"Frame directory not found: {source}")
    result = create_contact_sheet(
        source,
        args.output.expanduser().resolve(),
        args.columns,
        args.thumb_width,
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))


def fit_frame_to_cell(
    image: Image.Image,
    cell_width: int,
    cell_height: int,
) -> Image.Image:
    frame = image.convert("RGBA")
    frame.thumbnail((cell_width, cell_height), Image.Resampling.LANCZOS)
    cell = Image.new("RGBA", (cell_width, cell_height), (0, 0, 0, 0))
    left = (cell_width - frame.width) // 2
    top = (cell_height - frame.height) // 2
    cell.alpha_composite(frame, (left, top))
    return cell


def create_atlas(
    source: Path,
    output: Path,
    manifest_path: Path,
    columns: int | None,
    cell_width: int,
    cell_height: int,
    quality: int,
    lossless: bool,
    max_texture: int,
) -> dict[str, Any]:
    frames = frame_files(source)
    if not frames:
        raise SystemExit(f"No frames found: {source}")
    if columns is None:
        columns = max(
            1,
            math.ceil(
                math.sqrt(
                    len(frames) * (cell_height / max(1, cell_width))
                )
            ),
        )
    rows = math.ceil(len(frames) / columns)
    atlas_width = columns * cell_width
    atlas_height = rows * cell_height
    if atlas_width > max_texture or atlas_height > max_texture:
        raise SystemExit(
            f"Atlas would be {atlas_width}x{atlas_height}, exceeding --max-texture {max_texture}. "
            "Reduce the cell size, split the sequence, or use video/sequence-frame playback."
        )
    atlas = Image.new(
        "RGBA",
        (atlas_width, atlas_height),
        (0, 0, 0, 0),
    )
    for index, path in enumerate(frames):
        with Image.open(path) as opened:
            cell = fit_frame_to_cell(opened, cell_width, cell_height)
        atlas.alpha_composite(
            cell,
            (
                (index % columns) * cell_width,
                (index // columns) * cell_height,
            ),
        )
    output.parent.mkdir(parents=True, exist_ok=True)
    if output.suffix.lower() == ".webp":
        atlas.save(
            output,
            format="WEBP",
            quality=quality,
            lossless=lossless,
            method=6,
        )
    elif output.suffix.lower() == ".png":
        atlas.save(output, optimize=True)
    else:
        raise SystemExit("Atlas output must end in .webp or .png")
    manifest = {
        "version": 1,
        "type": "sprite-atlas",
        "asset": output.name,
        "frameCount": len(frames),
        "columns": columns,
        "rows": rows,
        "cellWidth": cell_width,
        "cellHeight": cell_height,
        "atlasWidth": atlas_width,
        "atlasHeight": atlas_height,
        "quality": quality if output.suffix.lower() == ".webp" else None,
        "lossless": lossless if output.suffix.lower() == ".webp" else True,
        "files": [path.name for path in frames],
    }
    write_json(manifest_path, manifest)
    return manifest


def command_atlas(args: argparse.Namespace) -> None:
    source = args.input.expanduser().resolve()
    if not source.is_dir():
        raise SystemExit(f"Frame directory not found: {source}")
    manifest = create_atlas(
        source,
        args.output.expanduser().resolve(),
        args.manifest.expanduser().resolve(),
        args.columns,
        args.cell_width,
        args.cell_height,
        args.quality,
        args.lossless,
        args.max_texture,
    )
    print(json.dumps(manifest, ensure_ascii=False, indent=2))


def command_build(args: argparse.Namespace) -> None:
    work = args.output.expanduser().resolve()
    prepare_output_directory(work, args.force)
    raw_frames = work / "frames" / ("raw" if args.normalize else "final")
    final_frames = work / "frames" / "final"
    raw_frames.parent.mkdir(parents=True, exist_ok=True)

    extract_args = argparse.Namespace(
        input=args.input,
        output=raw_frames,
        fps=args.fps,
        start=args.start,
        duration=args.duration,
        width=args.width,
        height=args.height,
        interpolate=args.interpolate,
        key=args.key,
        transparent_threshold=args.transparent_threshold,
        opaque_threshold=args.opaque_threshold,
        force=False,
    )
    extraction = extract_frames(extract_args)

    normalization = None
    if args.normalize:
        normalization = normalize_frames(
            argparse.Namespace(
                input=raw_frames,
                output=final_frames,
                anchor=args.anchor,
                max_scale_change=args.max_scale_change,
                alpha_threshold=args.alpha_threshold,
                force=False,
            )
        )

    qa = work / "qa"
    final = work / "final"
    qa.mkdir(parents=True, exist_ok=True)
    final.mkdir(parents=True, exist_ok=True)
    analysis = analyze_directory(
        final_frames,
        args.alpha_threshold,
        args.duplicate_threshold,
        args.brightness_jump,
        args.scale_jump,
        args.center_jump,
    )
    write_json(qa / "analysis.json", analysis)
    contact = create_contact_sheet(
        final_frames,
        qa / "contact-sheet.jpg",
        args.contact_columns,
        args.thumb_width,
    )
    atlas = create_atlas(
        final_frames,
        final / "motion.webp",
        final / "motion.json",
        args.columns,
        args.cell_width,
        args.cell_height,
        args.quality,
        args.lossless,
        args.max_texture,
    )
    build_manifest = {
        "source": str(args.input.expanduser().resolve()),
        "extraction": extraction,
        "normalization": normalization,
        "analysisSummary": analysis["summary"],
        "contactSheet": contact,
        "atlas": atlas,
    }
    write_json(work / "build.json", build_manifest)
    print(json.dumps(build_manifest, ensure_ascii=False, indent=2))


def add_extract_options(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--fps", type=float, default=24)
    parser.add_argument("--start", type=float)
    parser.add_argument("--duration", type=float)
    parser.add_argument("--width", type=int)
    parser.add_argument("--height", type=int)
    parser.add_argument(
        "--interpolate",
        action="store_true",
        help="Use ffmpeg motion interpolation instead of simple FPS sampling.",
    )
    parser.add_argument(
        "--key",
        default="auto",
        help="'auto', 'none', or a hex key color such as '#00FF00'.",
    )
    parser.add_argument("--transparent-threshold", type=float, default=12)
    parser.add_argument("--opaque-threshold", type=float, default=220)


def add_analysis_options(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--alpha-threshold", type=int, default=16)
    parser.add_argument("--duplicate-threshold", type=float, default=0.004)
    parser.add_argument("--brightness-jump", type=float, default=0.12)
    parser.add_argument("--scale-jump", type=float, default=0.08)
    parser.add_argument("--center-jump", type=float, default=0.08)


def add_atlas_options(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--columns", type=int)
    parser.add_argument("--cell-width", type=int, required=True)
    parser.add_argument("--cell-height", type=int, required=True)
    parser.add_argument("--quality", type=int, default=88)
    parser.add_argument("--lossless", action="store_true")
    parser.add_argument("--max-texture", type=int, default=4096)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    subparsers = parser.add_subparsers(dest="command", required=True)

    probe = subparsers.add_parser("probe")
    probe.add_argument("input", type=Path)
    probe.add_argument("--output", type=Path)
    probe.set_defaults(function=command_probe)

    extract = subparsers.add_parser("extract")
    extract.add_argument("input", type=Path)
    extract.add_argument("output", type=Path)
    add_extract_options(extract)
    extract.add_argument("--force", action="store_true")
    extract.set_defaults(function=command_extract)

    normalize = subparsers.add_parser("normalize")
    normalize.add_argument("input", type=Path)
    normalize.add_argument("output", type=Path)
    normalize.add_argument("--anchor", choices=["center", "bottom"], default="bottom")
    normalize.add_argument("--max-scale-change", type=float, default=0.08)
    normalize.add_argument("--alpha-threshold", type=int, default=16)
    normalize.add_argument("--force", action="store_true")
    normalize.set_defaults(function=command_normalize)

    analyze = subparsers.add_parser("analyze")
    analyze.add_argument("input", type=Path)
    analyze.add_argument("--output", type=Path)
    add_analysis_options(analyze)
    analyze.set_defaults(function=command_analyze)

    contact = subparsers.add_parser("contact")
    contact.add_argument("input", type=Path)
    contact.add_argument("--output", type=Path, required=True)
    contact.add_argument("--columns", type=int, default=8)
    contact.add_argument("--thumb-width", type=int, default=160)
    contact.set_defaults(function=command_contact)

    atlas = subparsers.add_parser("atlas")
    atlas.add_argument("input", type=Path)
    atlas.add_argument("--output", type=Path, required=True)
    atlas.add_argument("--manifest", type=Path, required=True)
    add_atlas_options(atlas)
    atlas.set_defaults(function=command_atlas)

    build = subparsers.add_parser("build")
    build.add_argument("input", type=Path)
    build.add_argument("output", type=Path)
    add_extract_options(build)
    add_analysis_options(build)
    add_atlas_options(build)
    build.add_argument("--normalize", action="store_true")
    build.add_argument("--anchor", choices=["center", "bottom"], default="bottom")
    build.add_argument("--max-scale-change", type=float, default=0.08)
    build.add_argument("--contact-columns", type=int, default=8)
    build.add_argument("--thumb-width", type=int, default=160)
    build.add_argument("--force", action="store_true")
    build.set_defaults(function=command_build)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if hasattr(args, "fps") and args.fps <= 0:
        raise SystemExit("--fps must be positive")
    if hasattr(args, "quality") and not 0 <= args.quality <= 100:
        raise SystemExit("--quality must be between 0 and 100")
    if hasattr(args, "max_scale_change") and not 0 <= args.max_scale_change <= 0.5:
        raise SystemExit("--max-scale-change must be between 0 and 0.5")
    args.function(args)


if __name__ == "__main__":
    main()

````

<!-- ===== FILE: scripts/optimize_motion.py ===== -->
````py
#!/usr/bin/env python3
"""补帧验收和网页动画资产目标体积压缩工具。"""

from __future__ import annotations

import argparse
import json
import math
import os
import shutil
import subprocess
import tempfile
from collections import Counter
from fractions import Fraction
from pathlib import Path
from typing import Any

import motion_pipeline
import motion_budget
from PIL import Image


MIB = 1024 * 1024


def positive_float(value: str) -> float:
    number = float(value)
    if number <= 0:
        raise argparse.ArgumentTypeError("必须大于 0")
    return number


def unit_float(value: str) -> float:
    number = float(value)
    if not 0 < number <= 1:
        raise argparse.ArgumentTypeError("必须位于 0 到 1 之间")
    return number


def run(command: list[str]) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        command,
        check=True,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )


def ensure_output(path: Path, force: bool, directory: bool = False) -> None:
    if path.exists():
        occupied = path.is_file() or (path.is_dir() and any(path.iterdir()))
        if occupied and not force:
            raise SystemExit(f"输出已存在：{path}。确认后使用 --force。")
        if force:
            if path.is_dir():
                shutil.rmtree(path)
            else:
                path.unlink()
    if directory:
        path.mkdir(parents=True, exist_ok=True)
    else:
        path.parent.mkdir(parents=True, exist_ok=True)


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(value, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )


def size_mb(path: Path) -> float:
    return path.stat().st_size / MIB


def parse_rate(value: str | None) -> float:
    if not value or value == "0/0":
        return 0
    try:
        return float(Fraction(value))
    except (ValueError, ZeroDivisionError):
        return 0


def video_stream(probe: dict[str, Any]) -> dict[str, Any]:
    for stream in probe.get("streams", []):
        if stream.get("codec_type") == "video":
            return stream
    raise SystemExit("输入中没有视频流。")


def audio_stream(probe: dict[str, Any]) -> dict[str, Any] | None:
    for stream in probe.get("streams", []):
        if stream.get("codec_type") == "audio":
            return stream
    return None


def warning_counts(report: dict[str, Any]) -> dict[str, int]:
    return dict(Counter(item["type"] for item in report["warnings"]))


def artifact_warning_count(report: dict[str, Any]) -> int:
    artifact_types = {
        "blank",
        "canvas-size",
        "brightness-jump",
        "scale-jump",
        "center-jump",
    }
    return sum(
        1 for item in report["warnings"] if item["type"] in artifact_types
    )


def analysis_args() -> dict[str, float | int]:
    return {
        "alpha_threshold": 16,
        "duplicate_threshold": 0.004,
        "brightness_jump": 0.12,
        "scale_jump": 0.08,
        "center_jump": 0.08,
    }


def make_extract_args(
    source: Path,
    output: Path,
    fps: float,
    args: argparse.Namespace,
    interpolate: bool,
) -> argparse.Namespace:
    return argparse.Namespace(
        input=source,
        output=output,
        fps=fps,
        start=args.start,
        duration=args.duration,
        width=args.width,
        height=args.height,
        interpolate=interpolate,
        key=args.key,
        transparent_threshold=args.transparent_threshold,
        opaque_threshold=args.opaque_threshold,
        force=False,
    )


def command_interpolate(args: argparse.Namespace) -> None:
    source = args.input.expanduser().resolve()
    output = args.output.expanduser().resolve()
    if not source.is_file():
        raise SystemExit(f"输入视频不存在：{source}")
    ensure_output(output, args.force, directory=True)

    probe = motion_pipeline.probe_video(source)
    stream = video_stream(probe)
    source_fps = (
        parse_rate(stream.get("avg_frame_rate"))
        or parse_rate(stream.get("r_frame_rate"))
        or 24
    )
    if args.fps <= source_fps:
        raise SystemExit(
            f"目标帧率 {args.fps:g} 必须高于源帧率 {source_fps:g}。"
        )

    frames = output / "frames"
    qa = output / "qa"
    qa.mkdir(parents=True, exist_ok=True)
    interpolated_extract = motion_pipeline.extract_frames(
        make_extract_args(source, frames, args.fps, args, True)
    )
    thresholds = analysis_args()
    interpolated_report = motion_pipeline.analyze_directory(
        frames, **thresholds
    )
    motion_pipeline.write_json(
        qa / "analysis-interpolated.json", interpolated_report
    )
    motion_pipeline.create_contact_sheet(
        frames,
        qa / "contact-sheet-interpolated.jpg",
        args.contact_columns,
        args.thumb_width,
    )

    with tempfile.TemporaryDirectory(prefix="oil-motion-original-") as temp:
        original_frames = Path(temp) / "frames"
        original_extract = motion_pipeline.extract_frames(
            make_extract_args(
                source,
                original_frames,
                source_fps,
                args,
                False,
            )
        )
        original_report = motion_pipeline.analyze_directory(
            original_frames, **thresholds
        )
        motion_pipeline.create_contact_sheet(
            original_frames,
            qa / "contact-sheet-original.jpg",
            args.contact_columns,
            args.thumb_width,
        )

    original_artifacts = artifact_warning_count(original_report)
    interpolated_artifacts = artifact_warning_count(interpolated_report)
    original_rate = original_artifacts / max(1, original_report["frameCount"])
    interpolated_rate = interpolated_artifacts / max(
        1, interpolated_report["frameCount"]
    )
    passed = interpolated_rate <= original_rate + args.warning_rate_tolerance

    report = {
        "type": "motion-interpolation-report",
        "source": str(source),
        "sourceFps": source_fps,
        "targetFps": args.fps,
        "original": {
            "extraction": original_extract,
            "summary": original_report["summary"],
            "warningsByType": warning_counts(original_report),
            "artifactWarningRate": original_rate,
        },
        "interpolated": {
            "extraction": interpolated_extract,
            "summary": interpolated_report["summary"],
            "warningsByType": warning_counts(interpolated_report),
            "artifactWarningRate": interpolated_rate,
        },
        "verdict": {
            "passedAutomaticChecks": passed,
            "warningRateTolerance": args.warning_rate_tolerance,
            "manualReviewRequired": True,
            "note": (
                "自动检查只覆盖空帧、亮度、大小和中心跳变；"
                "仍需查看两张接触表确认重影、肢体扭曲和语义错误。"
            ),
        },
    }
    write_json(output / "interpolation-report.json", report)
    print(json.dumps(report["verdict"], ensure_ascii=False, indent=2))
    print(f"补帧序列：{frames}")
    print(f"对比报告：{output / 'interpolation-report.json'}")


def render_atlas_candidate(
    source: Path,
    directory: Path,
    columns: int | None,
    width: int,
    height: int,
    quality: int,
    max_texture: int,
) -> tuple[Path, dict[str, Any]]:
    output = directory / f"atlas-{width}x{height}-q{quality}.webp"
    manifest_path = output.with_suffix(".json")
    manifest = motion_pipeline.create_atlas(
        source,
        output,
        manifest_path,
        columns,
        width,
        height,
        quality,
        False,
        max_texture,
    )
    return output, manifest


def command_atlas(args: argparse.Namespace) -> None:
    source = args.input.expanduser().resolve()
    output = args.output.expanduser().resolve()
    if not source.is_dir() or not motion_pipeline.frame_files(source):
        raise SystemExit(f"找不到帧序列：{source}")
    if output.suffix.lower() != ".webp":
        raise SystemExit("图集输出必须使用 .webp。")
    ensure_output(output, args.force)
    report_path = (
        args.report.expanduser().resolve()
        if args.report
        else output.with_suffix(".optimize.json")
    )
    if report_path.exists() and not args.force:
        raise SystemExit(f"报告已存在：{report_path}。确认后使用 --force。")

    display_width, display_height = args.display
    required_width = math.ceil(display_width * args.dpr)
    required_height = math.ceil(display_height * args.dpr)
    if (
        args.cell_width < required_width
        or args.cell_height < required_height
    ):
        raise SystemExit(
            "清晰度阻断：初始单帧 "
            f"{args.cell_width}×{args.cell_height} px 低于展示所需 "
            f"{required_width}×{required_height} px。"
        )

    frames = motion_pipeline.frame_files(source)
    with Image.open(frames[0]) as first_frame:
        source_width, source_height = first_frame.size
    if source_width < required_width or source_height < required_height:
        raise SystemExit(
            "清晰度阻断：源帧 "
            f"{source_width}×{source_height} px 低于展示所需 "
            f"{required_width}×{required_height} px；禁止放大后交付。"
        )

    target_bytes = int(args.target_mb * MIB)
    trials: list[dict[str, Any]] = []
    chosen: dict[str, Any] | None = None
    best_fallback: dict[str, Any] | None = None
    frame_count = len(frames)
    clarity_scale = max(
        required_width / args.cell_width,
        required_height / args.cell_height,
    )
    minimum_scale = max(args.min_cell_scale, clarity_scale)

    required_columns = args.columns
    if required_columns is None:
        required_columns = max(
            1,
            math.ceil(
                math.sqrt(
                    frame_count
                    * (required_height / max(1, required_width))
                )
            ),
        )
    required_rows = math.ceil(frame_count / required_columns)
    if (
        required_columns * required_width > args.max_texture
        or required_rows * required_height > args.max_texture
    ):
        raise SystemExit(
            "清晰度阻断：满足实际展示尺寸时，单张图集至少为 "
            f"{required_columns * required_width}×"
            f"{required_rows * required_height} px，超过纹理上限 "
            f"{args.max_texture}。请重新运行 motion_budget.py，并执行其自动选择结果。"
        )

    with tempfile.TemporaryDirectory(prefix="oil-motion-atlas-") as temp:
        temp_path = Path(temp)
        scale = 1.0
        while scale + 1e-9 >= minimum_scale:
            width = max(required_width, round(args.cell_width * scale))
            height = max(required_height, round(args.cell_height * scale))
            columns = args.columns
            if columns is None:
                columns = max(
                    1,
                    math.ceil(
                        math.sqrt(frame_count * (height / max(1, width)))
                    ),
                )
            rows = math.ceil(frame_count / columns)
            if (
                columns * width > args.max_texture
                or rows * height > args.max_texture
            ):
                trials.append(
                    {
                        "cellWidth": width,
                        "cellHeight": height,
                        "scale": scale,
                        "targetMet": False,
                        "skipped": "texture-limit",
                        "atlasWidth": columns * width,
                        "atlasHeight": rows * height,
                    }
                )
                scale = round(scale - args.scale_step, 6)
                continue
            low = args.min_quality
            high = args.max_quality
            scale_best: dict[str, Any] | None = None

            while low <= high:
                quality = (low + high) // 2
                candidate, manifest = render_atlas_candidate(
                    source,
                    temp_path,
                    columns,
                    width,
                    height,
                    quality,
                    args.max_texture,
                )
                candidate_bytes = candidate.stat().st_size
                trial = {
                    "cellWidth": width,
                    "cellHeight": height,
                    "scale": scale,
                    "quality": quality,
                    "bytes": candidate_bytes,
                    "sizeMB": candidate_bytes / MIB,
                    "targetMet": candidate_bytes <= target_bytes,
                    "path": str(candidate),
                    "manifest": manifest,
                }
                trials.append(trial)
                if (
                    best_fallback is None
                    or trial["bytes"] < best_fallback["bytes"]
                ):
                    best_fallback = trial
                if candidate_bytes <= target_bytes:
                    scale_best = trial
                    low = quality + 1
                else:
                    high = quality - 1

            if scale_best is not None:
                chosen = scale_best
                break
            scale = round(scale - args.scale_step, 6)

        if chosen is None:
            chosen = best_fallback
        if chosen is None:
            raise SystemExit("没有生成任何图集候选。")

        shutil.copy2(chosen["path"], output)
        final_manifest = dict(chosen["manifest"])
        final_manifest["asset"] = output.name
        final_manifest["targetMB"] = args.target_mb
        final_manifest["targetMet"] = chosen["targetMet"]
        final_manifest["display"] = {
            "width": display_width,
            "height": display_height,
            "dpr": args.dpr,
        }
        final_manifest["requiredCell"] = {
            "width": required_width,
            "height": required_height,
        }
        final_manifest["clarityMet"] = (
            chosen["cellWidth"] >= required_width
            and chosen["cellHeight"] >= required_height
        )
        manifest_path = (
            args.manifest.expanduser().resolve()
            if args.manifest
            else output.with_suffix(".json")
        )
        write_json(manifest_path, final_manifest)

    report = {
        "type": "atlas-optimization-report",
        "source": str(source),
        "output": str(output),
        "targetMB": args.target_mb,
        "resultMB": size_mb(output),
        "targetMet": chosen["targetMet"],
        "clarityMet": True,
        "display": {
            "width": display_width,
            "height": display_height,
            "dpr": args.dpr,
        },
        "requiredCell": {
            "width": required_width,
            "height": required_height,
        },
        "sourceFrame": {
            "width": source_width,
            "height": source_height,
        },
        "selected": {
            key: chosen[key]
            for key in (
                "cellWidth",
                "cellHeight",
                "scale",
                "quality",
                "bytes",
            )
        },
        "trials": [
            {key: value for key, value in trial.items() if key not in {"path", "manifest"}}
            for trial in trials
        ],
    }
    write_json(report_path, report)
    print(json.dumps(report, ensure_ascii=False, indent=2))


def video_filters(args: argparse.Namespace) -> str | None:
    filters: list[str] = []
    if args.max_width and args.max_height:
        filters.append(
            "scale="
            f"'min(iw,{args.max_width})':'min(ih,{args.max_height})':"
            "force_original_aspect_ratio=decrease:"
            "force_divisible_by=2"
        )
    elif args.max_width:
        filters.append(f"scale='min(iw,{args.max_width})':-2")
    elif args.max_height:
        filters.append(f"scale=-2:'min(ih,{args.max_height})'")
    if args.fps:
        filters.append(f"fps={args.fps}")
    return ",".join(filters) or None


def encode_two_pass(
    source: Path,
    output: Path,
    bitrate_kbps: int,
    args: argparse.Namespace,
    passlog: Path,
) -> None:
    ffmpeg = motion_pipeline.require_tool("ffmpeg")
    extension = output.suffix.lower()
    if extension == ".mp4":
        codec = "libx264"
        preset_args = ["-preset", args.preset, "-pix_fmt", "yuv420p"]
        mux = "mp4"
        audio_args = (
            ["-c:a", "aac", "-b:a", f"{args.audio_kbps}k"]
            if args.keep_audio
            else ["-an"]
        )
        final_args = ["-movflags", "+faststart"]
    elif extension == ".webm":
        codec = "libvpx-vp9"
        preset_args = ["-deadline", "good", "-cpu-used", "2"]
        mux = "webm"
        audio_args = (
            ["-c:a", "libopus", "-b:a", f"{args.audio_kbps}k"]
            if args.keep_audio
            else ["-an"]
        )
        final_args = []
    else:
        raise SystemExit("视频输出只支持 .mp4 或 .webm。")

    common = [
        ffmpeg,
        "-hide_banner",
        "-loglevel",
        "error",
        "-y",
        "-i",
        str(source),
    ]
    filters = video_filters(args)
    if filters:
        common.extend(["-vf", filters])
    video_args = [
        "-c:v",
        codec,
        "-b:v",
        f"{bitrate_kbps}k",
        *preset_args,
        "-passlogfile",
        str(passlog),
    ]
    run(
        [
            *common,
            *video_args,
            "-pass",
            "1",
            "-an",
            "-f",
            mux,
            os.devnull,
        ]
    )
    run(
        [
            *common,
            *video_args,
            "-pass",
            "2",
            *audio_args,
            *final_args,
            str(output),
        ]
    )


def command_video(args: argparse.Namespace) -> None:
    source = args.input.expanduser().resolve()
    output = args.output.expanduser().resolve()
    if not source.is_file():
        raise SystemExit(f"输入视频不存在：{source}")
    ensure_output(output, args.force)
    report_path = (
        args.report.expanduser().resolve()
        if args.report
        else output.with_suffix(".optimize.json")
    )
    if report_path.exists() and not args.force:
        raise SystemExit(f"报告已存在：{report_path}。确认后使用 --force。")

    probe = motion_pipeline.probe_video(source)
    stream = video_stream(probe)
    source_width = int(stream.get("width") or 0)
    source_height = int(stream.get("height") or 0)
    source_fps = (
        parse_rate(stream.get("avg_frame_rate"))
        or parse_rate(stream.get("r_frame_rate"))
        or 24
    )
    display_width, display_height = args.display
    required_width = math.ceil(display_width * args.dpr)
    required_height = math.ceil(display_height * args.dpr)
    if source_width < required_width or source_height < required_height:
        raise SystemExit(
            "清晰度阻断：源视频 "
            f"{source_width}×{source_height} px 低于展示所需 "
            f"{required_width}×{required_height} px；禁止放大后交付。"
        )
    args.max_width = args.max_width or required_width
    args.max_height = args.max_height or required_height
    if args.max_width < required_width or args.max_height < required_height:
        raise SystemExit(
            "清晰度阻断：视频输出上限不能低于展示所需 "
            f"{required_width}×{required_height} px。"
        )
    scale = min(
        1.0,
        args.max_width / source_width,
        args.max_height / source_height,
    )
    encoded_width = max(2, math.floor(source_width * scale / 2) * 2)
    encoded_height = max(2, math.floor(source_height * scale / 2) * 2)
    if encoded_width < required_width or encoded_height < required_height:
        raise SystemExit(
            "清晰度阻断：源视频比例放入当前输出框后只能得到 "
            f"{encoded_width}×{encoded_height} px，低于展示所需 "
            f"{required_width}×{required_height} px。请按实际内容比例填写 "
            "--display，或提供更高分辨率源视频。"
        )
    output_fps = args.fps or source_fps
    clarity_kbps = math.ceil(
        encoded_width
        * encoded_height
        * output_fps
        * args.min_bpp
        / 1000
    )
    quality_floor_kbps = max(args.min_video_kbps, clarity_kbps)
    duration = float(probe.get("format", {}).get("duration") or 0)
    if duration <= 0:
        raise SystemExit("无法读取视频时长。")
    has_audio = audio_stream(probe) is not None
    audio_kbps = args.audio_kbps if args.keep_audio and has_audio else 0
    target_bits = args.target_mb * MIB * 8 * 0.97
    bitrate_kbps = max(
        quality_floor_kbps,
        round(target_bits / duration / 1000 - audio_kbps),
    )
    attempts: list[dict[str, Any]] = []

    with tempfile.TemporaryDirectory(prefix="oil-motion-video-") as temp:
        passlog = Path(temp) / "pass"
        for attempt in range(1, 4):
            encode_two_pass(source, output, bitrate_kbps, args, passlog)
            actual_mb = size_mb(output)
            attempts.append(
                {
                    "attempt": attempt,
                    "videoKbps": bitrate_kbps,
                    "sizeMB": actual_mb,
                }
            )
            if actual_mb <= args.target_mb * 1.01:
                break
            ratio = args.target_mb / actual_mb
            bitrate_kbps = max(
                quality_floor_kbps,
                math.floor(bitrate_kbps * ratio * 0.98),
            )

    output_probe = motion_pipeline.probe_video(output)
    output_stream = video_stream(output_probe)
    output_width = int(output_stream.get("width") or 0)
    output_height = int(output_stream.get("height") or 0)
    result_mb = size_mb(output)
    clarity_met = (
        output_width >= required_width
        and output_height >= required_height
    )
    report = {
        "type": "video-optimization-report",
        "source": str(source),
        "output": str(output),
        "targetMB": args.target_mb,
        "resultMB": result_mb,
        "targetMet": result_mb <= args.target_mb * 1.01,
        "clarityMet": clarity_met,
        "display": {
            "width": display_width,
            "height": display_height,
            "dpr": args.dpr,
        },
        "requiredVideo": {
            "width": required_width,
            "height": required_height,
        },
        "encodedVideo": {
            "width": output_width,
            "height": output_height,
            "fps": output_fps,
        },
        "minBitsPerPixelPerFrame": args.min_bpp,
        "qualityFloorKbps": quality_floor_kbps,
        "sourceMB": size_mb(source),
        "compressionRatio": result_mb / max(size_mb(source), 1e-9),
        "audioKept": bool(args.keep_audio and has_audio),
        "attempts": attempts,
        "sourceProbe": probe,
        "outputProbe": output_probe,
    }
    write_json(report_path, report)
    print(
        json.dumps(
            {
                key: report[key]
                for key in (
                    "targetMB",
                    "resultMB",
                    "targetMet",
                    "clarityMet",
                    "sourceMB",
                    "compressionRatio",
                )
            },
            ensure_ascii=False,
            indent=2,
        )
    )


def add_extract_options(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--start", type=float)
    parser.add_argument("--duration", type=positive_float)
    parser.add_argument("--width", type=int)
    parser.add_argument("--height", type=int)
    parser.add_argument(
        "--key",
        default="none",
        help="'auto'、'none' 或十六进制色键。",
    )
    parser.add_argument("--transparent-threshold", type=float, default=12)
    parser.add_argument("--opaque-threshold", type=float, default=220)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    subparsers = parser.add_subparsers(dest="command", required=True)

    interpolate = subparsers.add_parser(
        "interpolate",
        help="光流补帧，并生成原始/补帧异常对比。",
    )
    interpolate.add_argument("input", type=Path)
    interpolate.add_argument("output", type=Path)
    interpolate.add_argument("--fps", type=positive_float, required=True)
    add_extract_options(interpolate)
    interpolate.add_argument("--warning-rate-tolerance", type=float, default=0.02)
    interpolate.add_argument("--contact-columns", type=int, default=8)
    interpolate.add_argument("--thumb-width", type=int, default=160)
    interpolate.add_argument("--force", action="store_true")
    interpolate.set_defaults(function=command_interpolate)

    atlas = subparsers.add_parser(
        "atlas",
        help="按目标体积自动选择图集尺寸和 WebP 质量。",
    )
    atlas.add_argument("input", type=Path)
    atlas.add_argument("--output", type=Path, required=True)
    atlas.add_argument("--target-mb", type=positive_float, required=True)
    atlas.add_argument(
        "--display",
        type=motion_budget.parse_size,
        required=True,
        help="最大实际 CSS 展示尺寸，如 360x360。",
    )
    atlas.add_argument("--dpr", type=positive_float, default=2.0)
    atlas.add_argument("--cell-width", type=int, required=True)
    atlas.add_argument("--cell-height", type=int, required=True)
    atlas.add_argument("--columns", type=int)
    atlas.add_argument("--min-quality", type=int, default=45)
    atlas.add_argument("--max-quality", type=int, default=92)
    atlas.add_argument("--min-cell-scale", type=unit_float, default=0.6)
    atlas.add_argument("--scale-step", type=positive_float, default=0.1)
    atlas.add_argument("--max-texture", type=int, default=4096)
    atlas.add_argument("--manifest", type=Path)
    atlas.add_argument("--report", type=Path)
    atlas.add_argument("--force", action="store_true")
    atlas.set_defaults(function=command_atlas)

    video = subparsers.add_parser(
        "video",
        help="按目标体积两遍编码 MP4/WebM。",
    )
    video.add_argument("input", type=Path)
    video.add_argument("--output", type=Path, required=True)
    video.add_argument("--target-mb", type=positive_float, required=True)
    video.add_argument(
        "--display",
        type=motion_budget.parse_size,
        required=True,
        help="最大实际 CSS 展示尺寸，如 360x360。",
    )
    video.add_argument("--dpr", type=positive_float, default=2.0)
    video.add_argument("--max-width", type=int)
    video.add_argument("--max-height", type=int)
    video.add_argument("--fps", type=positive_float)
    video.add_argument("--keep-audio", action="store_true")
    video.add_argument("--audio-kbps", type=int, default=96)
    video.add_argument("--min-video-kbps", type=int, default=80)
    video.add_argument(
        "--min-bpp",
        type=positive_float,
        default=0.08,
        help="每像素每帧最低码率；目标体积不能突破此清晰度底线。",
    )
    video.add_argument(
        "--preset",
        choices=("medium", "slow", "slower"),
        default="slow",
    )
    video.add_argument("--report", type=Path)
    video.add_argument("--force", action="store_true")
    video.set_defaults(function=command_video)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if hasattr(args, "width") and args.width is not None and args.width <= 0:
        raise SystemExit("--width 必须大于 0。")
    if hasattr(args, "height") and args.height is not None and args.height <= 0:
        raise SystemExit("--height 必须大于 0。")
    if hasattr(args, "min_quality") and not (
        0 <= args.min_quality <= args.max_quality <= 100
    ):
        raise SystemExit("质量范围必须满足 0 <= min <= max <= 100。")
    if hasattr(args, "scale_step") and args.scale_step > 1:
        raise SystemExit("--scale-step 不能大于 1。")
    args.function(args)


if __name__ == "__main__":
    main()

````

<!-- ===== FILE: scripts/production_gate.py ===== -->
````py
#!/usr/bin/env python3
"""为 Pilot 批准与多段视频首尾帧链提供可审计的硬门。"""

from __future__ import annotations

import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
from PIL import Image
import yaml

from media_edges import extract_first_frame, extract_last_frame

PILOT_ARTIFACTS = (
    "conceptContract",
    "firstFrame",
    "lastFrame",
    "pilotVideo",
    "pageEvidence",
)

class UniqueKeyLoader(yaml.SafeLoader):
    """拒绝 YAML 重复键，避免后值静默覆盖已经批准的合同语义。"""


def construct_unique_mapping(
    loader: UniqueKeyLoader,
    node: yaml.nodes.MappingNode,
    deep: bool = False,
) -> dict[Any, Any]:
    loader.flatten_mapping(node)
    mapping: dict[Any, Any] = {}
    for key_node, value_node in node.value:
        key = loader.construct_object(key_node, deep=deep)
        if key in mapping:
            raise ValueError(f"Concept Contract 包含重复字段：{key}")
        mapping[key] = loader.construct_object(value_node, deep=deep)
    return mapping


UniqueKeyLoader.add_constructor(
    yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG,
    construct_unique_mapping,
)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def artifact_record(raw_path: str | Path) -> dict[str, Any]:
    path = Path(raw_path).expanduser().resolve()
    if not path.is_file():
        raise FileNotFoundError(f"验收工件不存在：{path}")
    return {
        "path": str(path),
        "bytes": path.stat().st_size,
        "sha256": sha256_file(path),
    }


def validate_artifact(
    record: dict[str, Any],
    label: str,
    require_exact_hash: bool = True,
    force: bool = False,
) -> None:
    path = Path(str(record.get("path", ""))).expanduser().resolve()
    if not path.is_file():
        raise FileNotFoundError(f"{label} 工件不存在：{path}")
    if path.stat().st_size == 0:
        raise ValueError(f"{label} 工件为空文件：{path}")
    if require_exact_hash:
        actual_size = path.stat().st_size
        actual_hash = sha256_file(path)
        if actual_size != record.get("bytes") or actual_hash != record.get("sha256"):
            if force:
                print(
                    f"警告：{label} 工件哈希已变化，已通过 --force 忽略差异：{path}",
                    file=sys.stderr,
                )
            else:
                raise ValueError(f"{label} 工件已变化，Pilot 批准失效：{path}")


def contract_continuity_mode(raw_path: str | Path) -> str:
    path = Path(raw_path).expanduser().resolve()
    if not path.is_file():
        raise FileNotFoundError(f"Concept Contract 不存在：{path}")
    try:
        contract = yaml.load(
            path.read_text(encoding="utf-8"),
            Loader=UniqueKeyLoader,
        )
    except yaml.YAMLError as error:
        raise ValueError(f"Concept Contract YAML 无效：{error}") from error
    if not isinstance(contract, dict):
        raise ValueError("Concept Contract 顶层必须是 YAML 对象")
    mode = contract.get("clip_continuity")
    if mode not in {"chain", "independent"}:
        raise ValueError(
            "Concept Contract 顶层必须显式包含 "
            "clip_continuity: chain | independent"
        )
    return mode


def create_pilot_approval(args: argparse.Namespace) -> dict[str, Any]:
    if args.decision != "pass":
        raise ValueError("只有明确传入 --decision pass 才能生成 Pilot 批准文件")
    continuity_mode = contract_continuity_mode(args.contract)
    artifacts = {
        "conceptContract": artifact_record(args.contract),
        "firstFrame": artifact_record(args.first_frame),
        "lastFrame": artifact_record(args.last_frame),
        "pilotVideo": artifact_record(args.video),
        "pageEvidence": artifact_record(args.page_evidence),
    }
    if args.identity_bible:
        artifacts["identityBible"] = artifact_record(args.identity_bible)
    report = {
        "schemaVersion": 1,
        "passed": True,
        "approvedAt": datetime.now(timezone.utc).isoformat(),
        "reviewer": args.reviewer,
        "continuityMode": continuity_mode,
        "notes": args.notes or "",
        "artifacts": artifacts,
    }
    output = Path(args.output).expanduser().resolve()
    if output.exists() and not args.force:
        raise FileExistsError(f"Pilot 批准文件已存在：{output}；确认后使用 --force")
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(
        json.dumps(report, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return report


def validate_pilot_approval(
    raw_path: str | Path,
    force: bool = False,
) -> dict[str, Any]:
    path = Path(raw_path).expanduser().resolve()
    if not path.is_file():
        raise FileNotFoundError(f"缺少 Pilot 批准文件：{path}")
    report = json.loads(path.read_text(encoding="utf-8"))
    if report.get("schemaVersion") != 1 or report.get("passed") is not True:
        raise ValueError(f"Pilot 尚未通过：{path}")
    if not str(report.get("reviewer", "")).strip():
        raise ValueError(f"Pilot 批准缺少 reviewer：{path}")
    artifacts = report.get("artifacts")
    if not isinstance(artifacts, dict):
        raise ValueError(f"Pilot 批准缺少 artifacts：{path}")
    for label in PILOT_ARTIFACTS:
        record = artifacts.get(label)
        if not isinstance(record, dict):
            raise ValueError(f"Pilot 批准缺少 {label}：{path}")
        is_strict = label != "pageEvidence"
        validate_artifact(record, label, require_exact_hash=is_strict, force=force)
    approved_mode = report.get("continuityMode")
    if approved_mode not in {"chain", "independent"}:
        raise ValueError(f"Pilot 批准缺少有效 continuityMode：{path}")
    contract_path = artifacts["conceptContract"]["path"]
    actual_mode = contract_continuity_mode(contract_path)
    if actual_mode != approved_mode:
        if force:
            print(
                f"警告：Concept Contract 连续模式已由 {approved_mode} 变为 {actual_mode}，已通过 --force 允许执行",
                file=sys.stderr,
            )
        else:
            raise ValueError(f"Concept Contract 连续模式已变化，Pilot 批准失效：{path}")
    identity = artifacts.get("identityBible")
    if identity is not None:
        if not isinstance(identity, dict):
            raise ValueError(f"Pilot identityBible 记录无效：{path}")
        validate_artifact(identity, "identityBible", force=force)
    return report


def verify_frame_chain(
    previous_tail: str | Path,
    next_first: str | Path,
    segment_index: int,
    manifest_path: str | Path | None = None,
    force: bool = False,
) -> dict[str, Any]:
    if segment_index < 2:
        raise ValueError("帧链只用于第 2 段及之后的片段")
    previous = artifact_record(previous_tail)
    current = artifact_record(next_first)
    exact_match = (
        previous["bytes"] == current["bytes"]
        and previous["sha256"] == current["sha256"]
    )
    if not exact_match:
        if force:
            print(
                f"警告：第 {segment_index} 段首帧与上一段尾帧哈希不一致，已通过 --force 忽略差异继续执行",
                file=sys.stderr,
            )
        else:
            raise ValueError(
                "连续帧链断裂：下一段 --first-frame 不是上一段验收尾帧的原文件"
            )
    link = {
        "segmentIndex": segment_index,
        "verifiedAt": datetime.now(timezone.utc).isoformat(),
        "exactSha256Match": exact_match,
        "previousTail": previous,
        "nextFirst": current,
    }
    if manifest_path is not None:
        manifest = Path(manifest_path).expanduser().resolve()
        if manifest.is_file():
            payload = json.loads(manifest.read_text(encoding="utf-8"))
        else:
            payload = {"schemaVersion": 1, "links": []}
        links = payload.setdefault("links", [])
        if not isinstance(links, list):
            raise ValueError(f"帧链清单格式错误：{manifest}")
        links = [
            item
            for item in links
            if item.get("segmentIndex") != segment_index
        ]
        links.append(link)
        payload["links"] = sorted(links, key=lambda item: item["segmentIndex"])
        manifest.parent.mkdir(parents=True, exist_ok=True)
        manifest.write_text(
            json.dumps(payload, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
    return link


def frame_similarity(previous: Path, current: Path) -> dict[str, float]:
    with Image.open(previous) as opened:
        first = np.asarray(opened.convert("RGB"), dtype=np.float64) / 255.0
    with Image.open(current) as opened:
        second = np.asarray(opened.convert("RGB"), dtype=np.float64) / 255.0
    if first.shape != second.shape:
        raise ValueError(
            f"相邻成片尺寸不同：{first.shape[1]}x{first.shape[0]} 与 "
            f"{second.shape[1]}x{second.shape[0]}"
        )
    mae = float(np.mean(np.abs(first - second)))
    first_mean = np.mean(first, axis=(0, 1))
    second_mean = np.mean(second, axis=(0, 1))
    first_variance = np.var(first, axis=(0, 1))
    second_variance = np.var(second, axis=(0, 1))
    covariance = np.mean(
        (first - first_mean) * (second - second_mean), axis=(0, 1)
    )
    c1 = 0.01**2
    c2 = 0.03**2
    ssim = np.mean(
        ((2 * first_mean * second_mean + c1) * (2 * covariance + c2))
        / (
            (first_mean**2 + second_mean**2 + c1)
            * (first_variance + second_variance + c2)
        )
    )
    return {"ssim": round(float(ssim), 6), "normalizedMae": round(mae, 6)}


def verify_output_chain(
    previous_video: str | Path,
    next_video: str | Path,
    segment_index: int,
    manifest_path: str | Path,
    evidence_directory: str | Path,
    minimum_ssim: float = 0.97,
    maximum_mae: float = 0.04,
) -> dict[str, Any]:
    if segment_index < 2:
        raise ValueError("成片接缝只用于第 2 段及之后的片段")
    if not 0 <= minimum_ssim <= 1 or not 0 <= maximum_mae <= 1:
        raise ValueError("SSIM 与 MAE 阈值必须在 0..1")
    evidence = Path(evidence_directory).expanduser().resolve()
    previous_tail = evidence / f"segment-{segment_index - 1:02d}-tail.png"
    next_head = evidence / f"segment-{segment_index:02d}-head.png"
    extract_last_frame(previous_video, previous_tail)
    extract_first_frame(next_video, next_head)
    metrics = frame_similarity(previous_tail, next_head)
    passed = (
        metrics["ssim"] >= minimum_ssim
        and metrics["normalizedMae"] <= maximum_mae
    )
    link = {
        "segmentIndex": segment_index,
        "verifiedAt": datetime.now(timezone.utc).isoformat(),
        "passed": passed,
        "thresholds": {
            "minimumSsim": minimum_ssim,
            "maximumNormalizedMae": maximum_mae,
        },
        "metrics": metrics,
        "previousTail": artifact_record(previous_tail),
        "nextHead": artifact_record(next_head),
        "previousVideo": artifact_record(previous_video),
        "nextVideo": artifact_record(next_video),
    }
    manifest = Path(manifest_path).expanduser().resolve()
    if manifest.is_file():
        payload = json.loads(manifest.read_text(encoding="utf-8"))
    else:
        payload = {"schemaVersion": 1, "links": [], "outputLinks": []}
    output_links = payload.setdefault("outputLinks", [])
    if not isinstance(output_links, list):
        raise ValueError(f"帧链清单 outputLinks 格式错误：{manifest}")
    output_links = [
        item for item in output_links if item.get("segmentIndex") != segment_index
    ]
    output_links.append(link)
    payload["outputLinks"] = sorted(
        output_links, key=lambda item: item["segmentIndex"]
    )
    manifest.parent.mkdir(parents=True, exist_ok=True)
    manifest.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    if not passed:
        raise ValueError(
            "相邻成片接缝不连续："
            f"SSIM {metrics['ssim']:.4f}，MAE {metrics['normalizedMae']:.4f}"
        )
    return link


def parser() -> argparse.ArgumentParser:
    result = argparse.ArgumentParser(description="校验 oil-motion 生产硬门")
    commands = result.add_subparsers(dest="command", required=True)

    approve = commands.add_parser("approve-pilot", help="生成可校验的 Pilot 批准文件")
    approve.add_argument("--contract", required=True)
    approve.add_argument("--identity-bible")
    approve.add_argument("--first-frame", required=True)
    approve.add_argument("--last-frame", required=True)
    approve.add_argument("--video", required=True)
    approve.add_argument("--page-evidence", required=True)
    approve.add_argument("--reviewer", required=True)
    approve.add_argument("--notes")
    approve.add_argument("--decision", choices=("pass", "reject"), required=True)
    approve.add_argument("--output", required=True)
    approve.add_argument("--force", action="store_true")

    check = commands.add_parser("check-pilot", help="复核 Pilot 工件未变化")
    check.add_argument("approval")

    chain = commands.add_parser("verify-chain", help="验证并记录相邻片段帧链")
    chain.add_argument("--previous-tail", required=True)
    chain.add_argument("--next-first", required=True)
    chain.add_argument("--segment-index", type=int, required=True)
    chain.add_argument("--manifest", required=True)

    output_chain = commands.add_parser(
        "verify-output-chain", help="验证相邻成片解码后的实际接缝"
    )
    output_chain.add_argument("--previous-video", required=True)
    output_chain.add_argument("--next-video", required=True)
    output_chain.add_argument("--segment-index", type=int, required=True)
    output_chain.add_argument("--manifest", required=True)
    output_chain.add_argument("--evidence-dir", required=True)
    output_chain.add_argument("--min-ssim", type=float, default=0.97)
    output_chain.add_argument("--max-mae", type=float, default=0.04)
    return result


def main() -> int:
    args = parser().parse_args()
    if args.command == "approve-pilot":
        create_pilot_approval(args)
        print(f"Pilot 已批准：{Path(args.output).expanduser().resolve()}")
    elif args.command == "check-pilot":
        validate_pilot_approval(args.approval)
        print(f"Pilot 工件有效：{Path(args.approval).expanduser().resolve()}")
    elif args.command == "verify-chain":
        verify_frame_chain(
            args.previous_tail,
            args.next_first,
            args.segment_index,
            args.manifest,
        )
        print(f"帧链已验证：segment {args.segment_index}")
    else:
        verify_output_chain(
            args.previous_video,
            args.next_video,
            args.segment_index,
            args.manifest,
            args.evidence_dir,
            args.min_ssim,
            args.max_mae,
        )
        print(f"成片接缝已验证：segment {args.segment_index}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (
        FileNotFoundError,
        FileExistsError,
        RuntimeError,
        ValueError,
        json.JSONDecodeError,
    ) as error:
        print(f"错误：{error}")
        raise SystemExit(1) from error

````

<!-- ===== FILE: scripts/requirements.txt ===== -->
````txt
Pillow>=10.0.0
numpy>=1.24.0
PyYAML>=6.0.0

````