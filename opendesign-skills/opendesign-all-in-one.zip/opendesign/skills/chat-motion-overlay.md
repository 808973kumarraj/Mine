---
name: chat-motion-overlay
description: Generate configurable chat motion overlays from a transcript or screenshot, including plain bubble scenes, app-style chat containers, optional device frames, preset or uploaded avatars, nickname display rules, and transparent-video-ready Remotion bundles. Use when Codex needs to create reusable short-form chat clips for Douyin, demo videos, story reenactments, social-message proof scenes, or embeddable alpha overlays for Hyperframe and Remotion workflows.
triggers:
  - "chat motion overlay"
  - "animated chat"
  - "chat bubbles"
  - "message overlay"
  - "transparent chat video"
  - "微信聊天动效"
  - "聊天气泡动效"
  - "透明聊天视频"
od:
  mode: utility
  category: animation-motion
  design_system:
    requires: false
---

# Chat Motion Overlay

Turn chat content into a configurable motion overlay clip instead of a single hard-coded WeChat mock.

## Workflow

1. Normalize the chat input.
   - If the user gives a screenshot, extract the visible messages into the transcript format in `references/input-format.md`.
   - If the user gives plain text, keep one message per beat and preserve exact wording when authenticity matters.
   - For screenshots, use visible avatars as clues for participant count and message grouping, but do not crop or recreate avatar images by default. Infer participants and sides, then render with preset avatars unless the user provides avatar files or explicitly requests screenshot-derived avatars.

2. Choose a scene config.
   - Read `references/config-schema.md`.
   - Decide container style, avatar mode, device frame, nickname mode, and delivery format before generating the bundle.
   - When the user has not provided enough information, follow the question policy in `references/question-strategy.md`.

3. Build the scene spec.
   - Run `scripts/build_chat_overlay_spec.py` with a transcript and optional config JSON.
   - The script outputs a single JSON spec that Remotion can render directly.

4. Prepare a renderable bundle.
   - Run `scripts/prepare_chat_overlay_bundle.py`.
   - It copies the Remotion template, injects `src/chatSpec.ts`, and copies any uploaded avatar files into `public/`.

5. Render the target output.
   - Use the exact export commands in `references/output-modes.md`.
   - Prefer `MOV（透明背景，可直接导入剪映 / PR / FCP 叠加）` for editing, `WebM（透明背景，适合网页 / 浏览器播放）` for browsers, and editable engineering outputs when the user wants to keep composing downstream.

## Supported Dimensions

- `container`: `none`, `wechat`, `telegram`, `messenger`
- `avatarMode`: `preset`, `upload`, `mixed`
- `deviceFrame`: `none`, `iphone-dynamic-island`
- `nicknameMode`: `hidden`, `first-message-only`, `always`
- `deliveryFormat`:
  - `mov`: `MOV（透明背景，可直接导入剪映 / PR / FCP 叠加）`
  - `webm`: `WebM（透明背景，适合网页 / 浏览器播放）`
  - `remotion`: `Remotion 工程（适合继续编辑和拼装）`
  - `hyperframe`: `Hyperframe 工程（适合作为模块继续复用）`
  - `json`: `JSON 数据（适合程序处理 / 自定义渲染）`
  - `preview`: `预览图 / 预览工程（适合先确认效果）`

## Output Rules

- Keep the composition root transparent for overlay outputs.
- Use `container: none` for standalone bubble motion without an app shell.
- Use `container: wechat|telegram|messenger` when the platform chrome is part of the story.
- Treat uploaded avatars as content assets and copy them into `public/` for the render bundle.
- Prefer preset avatars when the user does not specify avatar files. Screenshot avatars may help identify participants, but recommend user-provided avatar files before attempting to crop or recreate avatars from screenshots.
- Keep config-driven behavior explicit; do not silently switch style families.

## Question Policy

- Prefer inference first, questions second.
- If the user gives enough information for a sensible default, continue and clearly state the assumptions.
- Ask only for missing high-impact choices.
- Keep the question set to 1-3 items.
- Prefer user-facing wording over technical wording.
- Ask about `deliveryFormat` using `格式（场景描述）` labels, not internal render terms.
- If the user says they do not care, continue with defaults and note them in the result.

## Resources

- Transcript format: `references/input-format.md`
- Config fields and examples: `references/config-schema.md`
- Question strategy: `references/question-strategy.md`
- Output commands and targets: `references/output-modes.md`
- Transcript/config to spec: `scripts/build_chat_overlay_spec.py`
- Remotion bundle preparation: `scripts/prepare_chat_overlay_bundle.py`
- Remotion render template: `assets/remotion-template/`


<!-- ===== FILE: agents/openai.yaml ===== -->
````yaml
interface:
  display_name: "聊天动效叠层"
  short_description: "把聊天内容生成多风格可配置的透明视频动效片段"
  default_prompt: "Use $chat-motion-overlay to turn this chat transcript or screenshot into a configurable chat motion overlay clip."

policy:
  allow_implicit_invocation: true

````

<!-- ===== FILE: assets/examples/chat-transcript.txt ===== -->
````txt
title: 闺蜜群（6）
time: 星期二 22:19

闺蜜|今天没运动
闺蜜|能不能让你老公在那个链接里
闺蜜|加一个拉粑粑记录|highlight
老婆|好
老婆|他说怎么会有这么奇怪的需求
老婆|我说他们这种不便秘的人不了解我们

````

<!-- ===== FILE: assets/examples/config-wechat-phone.json ===== -->
````json
{
  "container": "wechat",
  "avatarMode": "preset",
  "deviceFrame": "iphone-dynamic-island",
  "nicknameMode": "hidden",
  "deliveryFormat": "mov",
  "showTimestamp": true,
  "participants": {
    "闺蜜": {
      "side": "left",
      "preset": "female-bunny-pink"
    },
    "老婆": {
      "side": "right",
      "preset": "female-cat-orange"
    }
  }
}

````

<!-- ===== FILE: assets/remotion-template/package.json ===== -->
````json
{
  "name": "chat-motion-overlay-template",
  "version": "1.0.0",
  "private": true,
  "scripts": {
    "start": "remotion studio",
    "render:mov": "remotion render src/index.ts ChatMotionOverlay out/chat-motion-overlay.mov --image-format=png --pixel-format=yuva444p10le --codec=prores --prores-profile=4444",
    "render:webm": "remotion render src/index.ts ChatMotionOverlay out/chat-motion-overlay.webm --image-format=png --pixel-format=yuva420p --codec=vp9"
  },
  "dependencies": {
    "react": "^19.0.0",
    "react-dom": "^19.0.0",
    "remotion": "^4.0.0"
  },
  "devDependencies": {
    "@remotion/cli": "^4.0.0",
    "@types/react": "^19.0.0",
    "typescript": "^5.5.0"
  }
}

````

<!-- ===== FILE: assets/remotion-template/remotion.config.ts ===== -->
````ts
import {Config} from "@remotion/cli/config";

Config.setVideoImageFormat("png");
Config.setPixelFormat("yuva444p10le");
Config.setCodec("prores");
Config.setProResProfile("4444");

````

<!-- ===== FILE: assets/remotion-template/src/Root.tsx ===== -->
````tsx
import {Composition} from "remotion";
import {ChatMotionOverlay} from "./components/ChatMotionOverlay";
import {chatSpec} from "./chatSpec";

export const RemotionRoot = () => {
  return (
    <Composition
      id="ChatMotionOverlay"
      component={ChatMotionOverlay}
      durationInFrames={chatSpec.durationInFrames}
      fps={30}
      width={1080}
      height={1920}
      defaultProps={{chatSpec}}
    />
  );
};

````

<!-- ===== FILE: assets/remotion-template/src/chatSpec.ts ===== -->
````ts
export const chatSpec = {
  title: "聊天记录",
  timestamp: "今天",
  durationInFrames: 90,
  timing: {"start": 15, "gap": 18, "hold": 36},
  sceneConfig: {
    "container": "wechat",
    "avatarMode": "preset",
    "deviceFrame": "iphone-dynamic-island",
    "nicknameMode": "hidden",
    "deliveryFormat": "mov",
    "output": "mov-alpha",
    "showTimestamp": true
  },
  participants: [],
  messages: []
} as const;

````

<!-- ===== FILE: assets/remotion-template/src/components/BubbleScene.tsx ===== -->
````tsx
import React from "react";
import {interpolate, spring, useCurrentFrame, useVideoConfig} from "remotion";
import {AvatarImage, avatarSrcFor} from "./avatarLibrary";
import type {ChatSpec} from "./types";

const CONTAINER_THEME = {
  none: {screenBg: "transparent", headerBg: "transparent", bubbleLeft: "#FFFFFF", bubbleRight: "#F4F5F7", subtitle: "#7C7C7C"},
  wechat: {screenBg: "#EDEDED", headerBg: "#EDEDED", bubbleLeft: "#FFFFFF", bubbleRight: "#95EC69", subtitle: "#9A9A9A"},
  telegram: {screenBg: "#DDE8F6", headerBg: "#F5F8FC", bubbleLeft: "#FFFFFF", bubbleRight: "#E2F3FF", subtitle: "#7B8EA5"},
  messenger: {screenBg: "#F3F5F8", headerBg: "#FFFFFF", bubbleLeft: "#FFFFFF", bubbleRight: "#0A84FF", subtitle: "#7E8695"},
} as const;

const CHAT_WIDTH = 780;
const ROW_MAX_WIDTH_RATIO = 0.86;
const AVATAR_SIZE = 62;
const AVATAR_GAP = 12;
const BUBBLE_HORIZONTAL_PADDING = 44;
const BUBBLE_WIDTH_SAFETY = 18;
const BUBBLE_FONT_SIZE = 30;
const BUBBLE_FONT_WEIGHT = 500;
const FONT_FAMILY = `"PingFang SC", "Alibaba PuHuiTi", "Noto Sans SC", sans-serif`;
const CANVAS_CACHE_KEY = "__chat_motion_overlay_measure_canvas__";

const estimateCharWidth = (char: string) => {
  if (/\s/.test(char)) return BUBBLE_FONT_SIZE * 0.35;
  if (/[\u0000-\u00ff]/.test(char)) return BUBBLE_FONT_SIZE * 0.58;
  return BUBBLE_FONT_SIZE * 1.02;
};

const measureTextWidth = (text: string) => {
  if (typeof document === "undefined") {
    return Array.from(text).reduce((sum, char) => sum + estimateCharWidth(char), 0);
  }
  const win = document.defaultView as (Window & {[CANVAS_CACHE_KEY]?: HTMLCanvasElement}) | null;
  if (!win) {
    return Array.from(text).reduce((sum, char) => sum + estimateCharWidth(char), 0);
  }
  const canvas = win[CANVAS_CACHE_KEY] ?? document.createElement("canvas");
  if (!win[CANVAS_CACHE_KEY]) {
    win[CANVAS_CACHE_KEY] = canvas;
  }
  const context = canvas.getContext("2d");
  if (!context) {
    return Array.from(text).reduce((sum, char) => sum + estimateCharWidth(char), 0);
  }
  context.font = `${BUBBLE_FONT_WEIGHT} ${BUBBLE_FONT_SIZE}px ${FONT_FAMILY}`;
  return context.measureText(text).width;
};

const maxTextWidthFor = (container: ChatSpec["sceneConfig"]["container"]) => {
  const horizontalPadding = container === "none" ? 184 : 44;
  const availableRowWidth = (CHAT_WIDTH - horizontalPadding) * ROW_MAX_WIDTH_RATIO;
  return availableRowWidth - AVATAR_SIZE - AVATAR_GAP - BUBBLE_HORIZONTAL_PADDING;
};

const wrapMessageText = (text: string, maxTextWidth: number) => {
  const paragraphs = text.split("\n");
  const wrapped = paragraphs.map((paragraph) => {
    if (!paragraph || measureTextWidth(paragraph) <= maxTextWidth) {
      return paragraph;
    }
    const lines: string[] = [];
    let currentLine = "";
    for (const char of paragraph) {
      const nextLine = currentLine + char;
      if (currentLine && measureTextWidth(nextLine) > maxTextWidth) {
        lines.push(currentLine);
        currentLine = char;
        continue;
      }
      currentLine = nextLine;
    }
    if (currentLine) {
      lines.push(currentLine);
    }
    return lines.join("\n");
  });
  return wrapped.join("\n");
};

const bubbleWidthFor = (text: string, maxTextWidth: number) => {
  const lines = text.split("\n");
  const widestLine = lines.reduce((max, line) => Math.max(max, measureTextWidth(line)), 0);
  return Math.min(maxTextWidth, widestLine + BUBBLE_WIDTH_SAFETY) + BUBBLE_HORIZONTAL_PADDING;
};

const Bubble = ({
  message,
  participant,
  chatSpec,
  seenBySpeaker,
}: {
  message: ChatSpec["messages"][number];
  participant: ChatSpec["participants"][number];
  chatSpec: ChatSpec;
  seenBySpeaker: boolean;
}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const theme = CONTAINER_THEME[chatSpec.sceneConfig.container];
  const isRight = message.side === "right";
  if (frame < message.appearAt) {
    return <div style={{display: "none"}} />;
  }
  const local = frame - message.appearAt;
  const scale = spring({frame: local, fps, config: {damping: 14, stiffness: 180, mass: 0.7}, durationInFrames: 18});
  const x = interpolate(local, [0, 12], [isRight ? 26 : -26, 0], {extrapolateRight: "clamp"});
  const opacity = interpolate(local, [0, 8], [0, 1], {extrapolateRight: "clamp"});
  const bubbleBg = isRight ? theme.bubbleRight : theme.bubbleLeft;
  const textColor = chatSpec.sceneConfig.container === "messenger" && isRight ? "#FFFFFF" : "#1F1F1F";
  const maxTextWidth = maxTextWidthFor(chatSpec.sceneConfig.container);
  const displayText = wrapMessageText(message.text, maxTextWidth);
  const singleLineWidth = measureTextWidth(message.text);
  const fitsSingleLine = !message.text.includes("\n") && singleLineWidth + BUBBLE_WIDTH_SAFETY <= maxTextWidth;
  const bubbleWidth = fitsSingleLine
    ? singleLineWidth + BUBBLE_WIDTH_SAFETY + BUBBLE_HORIZONTAL_PADDING
    : bubbleWidthFor(displayText, maxTextWidth);
  const showName =
    chatSpec.sceneConfig.nicknameMode === "always" ||
    (chatSpec.sceneConfig.nicknameMode === "first-message-only" && !seenBySpeaker);
  return (
    <div
      style={{
        display: "flex",
        marginBottom: 14,
        opacity,
        justifyContent: isRight ? "flex-end" : "flex-start",
      }}
    >
      <div style={{display: "flex", gap: 12, alignItems: "flex-start", flexDirection: isRight ? "row-reverse" : "row", maxWidth: "86%"}}>
        <AvatarImage src={avatarSrcFor(participant)} />
        <div style={{maxWidth: "calc(100% - 76px)", display: "flex", flexDirection: "column", alignItems: isRight ? "flex-end" : "flex-start", gap: 6}}>
          {showName ? <div style={{fontSize: 18, color: "#7C8490", fontWeight: 700}}>{message.speaker}</div> : null}
          <div
            style={{
              background: bubbleBg,
              display: "block",
              width: Math.ceil(bubbleWidth),
              maxWidth: "100%",
              padding: "16px 22px",
              borderRadius: 16,
              fontSize: BUBBLE_FONT_SIZE,
              lineHeight: 1.35,
              fontWeight: BUBBLE_FONT_WEIGHT,
              color: textColor,
              fontFamily: FONT_FAMILY,
              whiteSpace: fitsSingleLine ? "nowrap" : "pre-wrap",
              wordBreak: "break-word",
              overflowWrap: "normal",
              boxShadow: message.highlight ? "0 8px 26px rgba(236,135,120,0.18)" : "0 2px 6px rgba(0,0,0,0.05)",
              border: message.highlight ? "2px solid rgba(235,135,120,0.45)" : "1px solid rgba(0,0,0,0.04)",
              transform: `translateX(${x}px) scale(${scale})`,
              transformOrigin: isRight ? "right center" : "left center",
            }}
          >
            {displayText}
          </div>
        </div>
      </div>
    </div>
  );
};

export const BubbleScene = ({chatSpec}: {chatSpec: ChatSpec}) => {
  const frame = useCurrentFrame();
  const theme = CONTAINER_THEME[chatSpec.sceneConfig.container];
  const headerOpacity = interpolate(frame, [0, 12], [0, 1], {extrapolateRight: "clamp"});
  const seen = new Set<string>();
  const participantsByName = new Map(chatSpec.participants.map((participant) => [participant.name, participant]));
  const showContainer = chatSpec.sceneConfig.container !== "none";
  const inner = (
    <>
      {showContainer ? (
        <>
          <div
            style={{
              height: 132,
              background: theme.headerBg,
              borderBottom: "1px solid rgba(0,0,0,0.06)",
              display: "flex",
              alignItems: "flex-end",
              padding: "0 22px 14px",
              opacity: headerOpacity,
              flexShrink: 0,
            }}
          >
            <div style={{fontSize: 40, color: "#1F1F1F", fontWeight: 300, width: 32}}>‹</div>
            <div style={{flex: 1, textAlign: "center", fontSize: 28, fontWeight: 700, color: "#1F1F1F"}}>{chatSpec.title}</div>
            <div style={{fontSize: 36, color: "#1F1F1F", letterSpacing: 3, width: 32, textAlign: "right"}}>···</div>
          </div>
          {chatSpec.sceneConfig.showTimestamp ? (
            <div style={{textAlign: "center", marginTop: 18, marginBottom: 20, color: theme.subtitle, fontSize: 22, fontWeight: 500, opacity: headerOpacity}}>
              {chatSpec.timestamp}
            </div>
          ) : null}
        </>
      ) : null}
      <div style={{padding: showContainer ? "0 22px" : "180px 92px", flex: 1, width: "100%"}}>
        {chatSpec.messages.map((message) => {
          const seenBefore = seen.has(message.speaker);
          seen.add(message.speaker);
          const participant = participantsByName.get(message.speaker);
          if (!participant) return null;
          return <Bubble key={message.id} message={message} participant={participant} chatSpec={chatSpec} seenBySpeaker={seenBefore} />;
        })}
      </div>
    </>
  );
  if (!showContainer) {
    return (
      <div
        style={{
          width: 1080,
          height: 1920,
          display: "flex",
          flexDirection: "column",
          background: "transparent",
        }}
      >
        {inner}
      </div>
    );
  }
  return (
    <div
      style={{
        width: "100%",
        height: "100%",
        background: theme.screenBg,
        display: "flex",
        flexDirection: "column",
        fontFamily: `"PingFang SC", "Alibaba PuHuiTi", "Noto Sans SC", sans-serif`,
        overflow: "hidden",
      }}
    >
      {inner}
    </div>
  );
};

````

<!-- ===== FILE: assets/remotion-template/src/components/ChatMotionOverlay.tsx ===== -->
````tsx
import React from "react";
import {AbsoluteFill} from "remotion";
import {BubbleScene} from "./BubbleScene";
import {DeviceFrame} from "./DeviceFrame";
import type {ChatSpec} from "./types";

export const ChatMotionOverlay = ({chatSpec}: {chatSpec: ChatSpec}) => {
  const content = <BubbleScene chatSpec={chatSpec} />;
  const wrapped = chatSpec.sceneConfig.deviceFrame === "iphone-dynamic-island" ? <DeviceFrame>{content}</DeviceFrame> : content;
  return (
    <AbsoluteFill
      style={{
        backgroundColor: "transparent",
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      {wrapped}
    </AbsoluteFill>
  );
};

````

<!-- ===== FILE: assets/remotion-template/src/components/DeviceFrame.tsx ===== -->
````tsx
import React, {type ReactNode} from "react";

export const DeviceFrame = ({children}: {children: ReactNode}) => {
  return (
    <div
      style={{
        width: 820,
        height: 1660,
        borderRadius: 88,
        background: "#101516",
        padding: 20,
        boxSizing: "border-box",
        position: "relative",
      }}
    >
      <div
        style={{
          position: "absolute",
          top: 22,
          left: "50%",
          transform: "translateX(-50%)",
          width: 180,
          height: 42,
          borderRadius: 999,
          background: "#070909",
          zIndex: 4,
        }}
      />
      <div
        style={{
          width: "100%",
          height: "100%",
          borderRadius: 70,
          overflow: "hidden",
          background: "transparent",
        }}
      >
        {children}
      </div>
    </div>
  );
};

````

<!-- ===== FILE: assets/remotion-template/src/components/avatarLibrary.tsx ===== -->
````tsx
import React from "react";
import {Img, staticFile} from "remotion";
import type {AvatarKey, ChatSpec} from "./types";

const PRESET_FILES: Record<AvatarKey, string> = {
  "female-bunny-pink": "female-bunny-pink.png",
  "female-cat-orange": "female-cat-orange.png",
  "female-fox-yellow": "female-fox-yellow.png",
  "male-bear-mint": "male-bear-mint.png",
  "male-penguin-blue": "male-penguin-blue.png",
  "male-koala-lilac": "male-koala-lilac.png",
};

export const avatarSrcFor = (participant: ChatSpec["participants"][number]) => {
  if (participant.uploadAsset) return staticFile(participant.uploadAsset);
  const key = (participant.avatarKey in PRESET_FILES ? participant.avatarKey : "female-bunny-pink") as AvatarKey;
  return staticFile(PRESET_FILES[key]);
};

export const AvatarImage = ({
  src,
  size = 62,
}: {
  src: string;
  size?: number;
}) => (
  <div
    style={{
      width: size,
      height: size,
      borderRadius: 18,
      overflow: "hidden",
      flexShrink: 0,
      boxShadow: "0 4px 14px rgba(56,72,92,0.10)",
      border: "1px solid rgba(255,255,255,0.88)",
      background: "#FFFFFF",
    }}
  >
    <Img src={src} style={{width: "100%", height: "100%", objectFit: "cover", display: "block"}} />
  </div>
);

````

<!-- ===== FILE: assets/remotion-template/src/components/types.ts ===== -->
````ts
export type AvatarKey =
  | "female-bunny-pink"
  | "female-cat-orange"
  | "female-fox-yellow"
  | "male-bear-mint"
  | "male-penguin-blue"
  | "male-koala-lilac";

export type ChatSpec = {
  title: string;
  timestamp: string;
  durationInFrames: number;
  timing: {start: number; gap: number; hold: number};
  sceneConfig: {
    container: "none" | "wechat" | "telegram" | "messenger";
    avatarMode: "preset" | "upload" | "mixed";
    deviceFrame: "none" | "iphone-dynamic-island";
    nicknameMode: "hidden" | "first-message-only" | "always";
    deliveryFormat: "mov" | "webm" | "json" | "remotion" | "hyperframe" | "preview";
    output: "mov-alpha" | "webm-alpha" | "json-spec" | "remotion-component" | "hyperframe-ready" | "preview-only";
    showTimestamp: boolean;
  };
  participants: ReadonlyArray<{id: string; name: string; side: "left" | "right"; avatarKey: AvatarKey | string; uploadAsset?: string | null}>;
  messages: ReadonlyArray<{
    id: string;
    speaker: string;
    text: string;
    side: "left" | "right";
    avatarKey: AvatarKey | string;
    appearAt: number;
    highlight?: boolean;
  }>;
};

````

<!-- ===== FILE: assets/remotion-template/src/index.ts ===== -->
````ts
import {registerRoot} from "remotion";
import {RemotionRoot} from "./Root";

registerRoot(RemotionRoot);

````

<!-- ===== FILE: assets/remotion-template/tsconfig.json ===== -->
````json
{
  "compilerOptions": {
    "target": "ES2020",
    "module": "ESNext",
    "jsx": "react-jsx",
    "moduleResolution": "Bundler",
    "allowSyntheticDefaultImports": true,
    "strict": true,
    "resolveJsonModule": true,
    "esModuleInterop": true,
    "skipLibCheck": true
  },
  "include": ["src"]
}

````

<!-- ===== FILE: references/config-schema.md ===== -->
````md
# Config Schema

Provide a JSON file when the user wants anything beyond the defaults.

## Example

```json
{
  "container": "wechat",
  "avatarMode": "mixed",
  "deviceFrame": "iphone-dynamic-island",
  "nicknameMode": "first-message-only",
  "deliveryFormat": "mov",
  "showTimestamp": true,
  "participants": {
    "Alice": {
      "side": "left",
      "preset": "female-fox-yellow"
    },
    "Bob": {
      "side": "right",
      "preset": "male-penguin-blue",
      "uploadPath": "/path/to/bob-avatar.png"
    }
  }
}
```

## Fields

- `container`
  - `none`: standalone bubbles only
  - `wechat`: WeChat-style UI shell
  - `telegram`: Telegram-like UI shell
  - `messenger`: Facebook Messenger-like UI shell

- `avatarMode`
  - `preset`: use only bundled preset avatars
  - `upload`: require uploaded avatar files for all participants
  - `mixed`: combine preset and uploaded avatars across participants

- `deviceFrame`
  - `none`
  - `iphone-dynamic-island`
  - `container: none` only supports `deviceFrame: none`; phone framing is available for app containers

- `nicknameMode`
  - `hidden`
  - `first-message-only`
  - `always`

- `deliveryFormat`
  - `mov`: `MOV（透明背景，可直接导入剪映 / PR / FCP 叠加）`
  - `webm`: `WebM（透明背景，适合网页 / 浏览器播放）`
  - `remotion`: `Remotion 工程（适合继续编辑和拼装）`
  - `hyperframe`: `Hyperframe 工程（适合作为模块继续复用）`
  - `json`: `JSON 数据（适合程序处理 / 自定义渲染）`
  - `preview`: `预览图 / 预览工程（适合先确认效果）`

- `showTimestamp`
  - boolean

- `participants`
  - Keys are speaker names from the transcript or screenshot.
  - `side`: `left` or `right`; the same participant must stay on the same side.
  - `preset`: optional bundled preset avatar key.
  - `uploadPath`: optional local avatar file path used during bundle preparation.
  - If omitted, participants are inferred from the transcript and assigned stable preset avatars.
  - In generated bundles, local `uploadPath` values are removed and only copied `uploadAsset` names are retained.

## Preset Avatar Keys

- `female-bunny-pink`
- `female-cat-orange`
- `female-fox-yellow`
- `male-bear-mint`
- `male-penguin-blue`
- `male-koala-lilac`

````

<!-- ===== FILE: references/input-format.md ===== -->
````md
# Input Format

Use this transcript format before generating the scene spec.

## Minimal Form

```text
title: 闺蜜群（6）
time: 星期二 22:19

闺蜜|今天没运动
闺蜜|能不能让你老公在那个链接里
闺蜜|加一个拉粑粑记录|highlight
老婆|好
老婆|他说怎么会有这么奇怪的需求
老婆|我说他们这种不便秘的人不了解我们
```

## Full Form

```text
title: 飞书项目群
time: 今天 14:32
start: 18
gap: 20
hold: 36

我|right|male-bear-mint|帮我做一个胰岛素抵抗管理工具
Hermes|left|male-penguin-blue|收到，我先生成首页结构
Hermes|left|male-penguin-blue|再补食物、运动和体重趋势
我|right|male-bear-mint|行，先给我能看的版本
```

## Message Rules

- Metadata lines support `title`, `time`, `start`, `gap`, `hold`.
- Message lines support:
  - `name|text`
  - `name|text|highlight`
  - `name|side|text`
  - `name|side|avatar|text`
  - `name|side|avatar|text|highlight`
- Valid sides: `left`, `right`, `左`, `右`.
- Valid flag: `highlight`.
- If side is missing, the first speaker defaults to left and the second to right.
- If avatar is missing, the spec builder auto-assigns one per participant.
- The same speaker must stay on the same side throughout the transcript. If a transcript or screenshot implies conflicting sides for one speaker, stop and ask the user to confirm.
- Avatar selection is participant-first: use the participant config when provided, otherwise use the transcript avatar hint, otherwise auto-assign a preset.
- For screenshots, use visible avatars as clues for participant count and message grouping, but default to preset render avatars. Do not crop or recreate screenshot avatar images unless the user explicitly asks for screenshot-derived avatars.

## Screenshot Workflow

When the user gives a screenshot:

1. Read the messages in display order.
2. Infer side from bubble placement.
3. Infer participants from repeated nicknames, repeated avatar visuals, bubble grouping, and side placement.
4. Keep the same participant on the same side; ask for confirmation if the screenshot suggests otherwise.
5. Record title and timestamp if visible.
6. Keep uncertain OCR fragments explicit instead of inventing cleaner text.
7. Convert the result into the transcript format above before running the script.

## Screenshot Avatar Policy

- Default: use preset avatars for all inferred participants.
- Use screenshot avatars as visual evidence for participant count and message grouping, especially in group chats.
- If the user wants exact rendered avatars, first ask them to provide avatar image files or cropped avatar assets.
- Only attempt to crop or recreate avatars from the screenshot when the user explicitly requests it and accepts that recognition may be imperfect.
- Participant identity should come from nickname, repeated avatar visuals, message grouping, and side consistency together; do not rely on avatar visuals alone when ambiguous.

````

<!-- ===== FILE: references/output-modes.md ===== -->
````md
# Output Modes

Use user-facing delivery choices and let the skill map them to concrete artifacts.

## MOV（透明背景，可直接导入剪映 / PR / FCP 叠加）

Use this when the clip should be layered in editors such as Premiere, Final Cut, Jianying, or CapCut.

```bash
npx remotion render src/index.ts ChatMotionOverlay out/chat-motion-overlay.mov --image-format=png --pixel-format=yuva444p10le --codec=prores --prores-profile=4444
```

## WebM（透明背景，适合网页 / 浏览器播放）

Use this when the clip should play in browser or web composition contexts.

```bash
npx remotion render src/index.ts ChatMotionOverlay out/chat-motion-overlay.webm --image-format=png --pixel-format=yuva420p --codec=vp9
```

## JSON 数据（适合程序处理 / 自定义渲染）

Use this when another system should consume the scene structure directly.

- Run `scripts/build_chat_overlay_spec.py`
- Keep the resulting JSON as the transport artifact

## Remotion 工程 / Hyperframe 工程（适合继续编辑和拼装）

Use this when the user wants to keep composing downstream rather than receiving a final video.

- Run `scripts/prepare_chat_overlay_bundle.py`
- Deliver the generated bundle directory

## Visual Rules

- `container: none` should keep only bubbles and avatars on a transparent root.
- `container: none` only supports `deviceFrame: none`; do not pair bubble-only overlays with `iphone-dynamic-island`.
- App containers should keep their own screen background but never add a global background outside the content region.
- `deviceFrame: iphone-dynamic-island` adds phone hardware while preserving transparent outer space.

````

<!-- ===== FILE: references/question-strategy.md ===== -->
````md
# Question Strategy

Use this policy when the user triggers `$chat-motion-overlay` without enough detail.

## Principle

Ask only for decisions that materially change the result. Infer the rest.

## Default Behavior

- Infer `container=wechat` when the user says "微信聊天" or gives a WeChat-like screenshot.
- Infer `avatarMode=preset` when no avatar preference is given.
- For screenshot inputs, use visible avatars to help count and group participants, but use preset render avatars unless the user asks for custom or screenshot-derived avatars.
- Infer `deviceFrame=iphone-dynamic-island` only when the user explicitly asks for a phone frame or the prior context strongly implies phone mockup output.
- Infer `nicknameMode=hidden` for one-to-one chat clips unless the user asks to preserve identity or the content is clearly a group chat proof scene.
- Infer `deliveryFormat=mov` when the user says they want to use the result in editing software or says "透明视频片段".

## When To Ask

Ask when any of these are missing and would significantly change the output:

1. Container style
2. Avatar source
3. Device frame presence
4. Delivery format
5. Nickname display mode

## Preferred User-Facing Questions

### Delivery format

Ask:

- `MOV（透明背景，可直接导入剪映 / PR / FCP 叠加）`
- `WebM（透明背景，适合网页 / 浏览器播放）`
- `Remotion 工程（适合继续编辑和拼装）`
- `Hyperframe 工程（适合作为模块继续复用）`
- `JSON 数据（适合程序处理 / 自定义渲染）`
- `预览图 / 预览工程（适合先确认效果）`

Do not ask with internal terms such as `mov-alpha`, `json-spec`, or `hyperframe-ready`.

### Container style

Ask:

- `纯对话气泡`
- `微信`
- `Telegram`
- `Messenger`

### Avatar source

Ask:

- `预设头像`
- `上传头像`
- `部分角色上传头像`

For screenshot inputs, phrase the default clearly:

- `默认用预设头像（更稳定）`
- `我提供头像图片`
- `尝试从截图裁头像（可能不准）`

### Device frame

Ask:

- `不加手机边框`
- `iPhone 灵动岛边框`

### Nickname mode

Ask:

- `不显示昵称`
- `首次出现时显示昵称`
- `每条消息都显示昵称`

## Question Limits

- Ask at most 3 items in one turn.
- If more than 3 items are missing, ask for the highest-impact ones first:
  1. delivery format
  2. container style
  3. avatar source

## If The User Does Not Care

If the user responds with "随便", "默认就行", or equivalent:

- continue with defaults
- list the chosen defaults briefly in the result

````

<!-- ===== FILE: references/test-matrix.md ===== -->
````md
# Test Matrix

This matrix covers the configurable surface of `$chat-motion-overlay`.

## Goals

- Validate transcript to spec generation
- Validate bundle preparation and asset copying
- Validate template type safety
- Validate representative rendering for each major scene family
- Catch invalid config combinations early
- Validate group chats can assign avatars per participant instead of only per side
- Validate uploaded avatar asset names remain unique when participant slugs collide
- Validate bubble-only overlays keep right-side rows explicitly right-aligned
- Lock down the question strategy so incomplete requests are handled consistently
- Validate transcript avatar hints are checked against preset keys before use
- Validate `uploadPath` is rejected when `avatarMode` is `preset`
- Validate config participant presets override transcript avatar hints
- Validate `--force` rejects dangerous output directories instead of deleting them
- Reject the unsupported bubble-only plus phone-frame combination before rendering
- Validate rendered frames across a message `appearAt` boundary, not only a later still
## Covered Dimensions

- `container`: `none`, `wechat`, `telegram`, `messenger`
- `avatarMode`: `preset`, `upload`, `mixed`
- `deviceFrame`: `none`, `iphone-dynamic-island`
- `nicknameMode`: `hidden`, `first-message-only`, `always`
- `deliveryFormat`: `mov`, `webm`, `json`, `remotion`, `hyperframe`, `preview`

## Cases

1. `default_wechat_phone_preset_hidden`
   - Container: `wechat`
   - Avatar mode: `preset`
   - Device frame: `iphone-dynamic-island`
   - Nickname mode: `hidden`
   - Delivery: `MOV（透明背景，可直接导入剪映 / PR / FCP 叠加）`
   - Render frames: `14`, `15`, `120` to cross the first message `appearAt`

2. `plain_bubbles_no_frame_first_message`
   - Container: `none`
   - Avatar mode: `preset`
   - Device frame: `none`
   - Nickname mode: `first-message-only`
   - Delivery: `Remotion 工程（适合继续编辑和拼装）`

3. `telegram_no_frame_always`
   - Container: `telegram`
   - Avatar mode: `preset`
   - Device frame: `none`
   - Nickname mode: `always`
   - Delivery: `WebM（透明背景，适合网页 / 浏览器播放）`

4. `messenger_phone_hidden`
   - Container: `messenger`
   - Avatar mode: `preset`
   - Device frame: `iphone-dynamic-island`
   - Nickname mode: `hidden`
   - Delivery: `MOV（透明背景，可直接导入剪映 / PR / FCP 叠加）`

5. `upload_phone_always`
   - Container: `wechat`
   - Avatar mode: `upload`
   - Device frame: `iphone-dynamic-island`
   - Nickname mode: `always`
   - Delivery: `MOV（透明背景，可直接导入剪映 / PR / FCP 叠加）`

6. `mixed_wechat_phone_first_message`
   - Container: `wechat`
   - Avatar mode: `mixed`
   - Device frame: `iphone-dynamic-island`
   - Nickname mode: `first-message-only`
   - Delivery: `Hyperframe 工程（适合作为模块继续复用）`

7. `json_spec_only`
   - Container: `wechat`
   - Avatar mode: `preset`
   - Device frame: `iphone-dynamic-island`
   - Nickname mode: `hidden`
   - Delivery: `JSON 数据（适合程序处理 / 自定义渲染）`

8. `group_multi_participant_distinct_presets`
   - Container: `wechat`
   - Avatar mode: `preset`
   - Four speakers across left and right sides
   - Expected: each participant can resolve to a distinct avatar

9. `invalid_upload_missing_side`
   - Avatar mode: `upload`
   - Missing one upload path
   - Expected: fail with validation error

10. `invalid_mixed_without_upload`
   - Avatar mode: `mixed`
   - No upload path
   - Expected: fail with validation error

11. `invalid_upload_missing_file`
   - Avatar mode: `upload`
   - Upload path points to a missing file
   - Expected: bundle preparation fails fast with a clear missing-file error and leaves no generated `chatSpec.ts` leaking local upload paths

12. `invalid_participant_side_conflict`
   - One participant appears on both left and right sides
   - Expected: fail with validation error and ask for consistent participant side

13. `upload_slug_collision_unique_assets`
   - Avatar mode: `upload`
   - Two distinct speaker names normalize to the same slug
   - Expected: generated participant ids and copied upload assets remain unique


14. `invalid_transcript_avatar_key`
   - Transcript line includes a non-preset avatar key
   - Expected: fail with validation error instead of silently falling back to a preset avatar

15. `invalid_preset_mode_upload_path`
   - Avatar mode: `preset` but a participant config carries `uploadPath`
   - Expected: fail with validation error

16. `config_preset_overrides_transcript_avatar_hint`
   - Config preset differs from transcript avatar hint for the same participant
   - Expected: generated spec uses the config preset, not the transcript hint

17. `invalid_force_dangerous_output_dir`
   - `--force` targets a dangerous existing directory such as the skill root
   - Expected: bundle preparation fails before any recursive deletion happens

18. `invalid_bubble_only_phone_frame`
   - Container: `none`
   - Device frame: `iphone-dynamic-island`
   - Expected: fail with a validation error instead of generating a clipped phone-frame scene

## Pass Criteria

- Valid cases generate JSON spec successfully
- Valid bundle cases prepare output bundle successfully
- Generated bundle sanitizes machine-local upload paths out of `src/chatSpec.ts`
- Generated bundle passes `tsc --noEmit`
- Representative valid cases render a still frame successfully
- Group chat cases assign avatars by participant, not only by left/right side
- Uploaded avatar assets remain collision-proof for participants with colliding slug bases
- Bubble-only overlays explicitly use right-side row alignment in the generated template
- Participant side conflicts fail instead of rendering one person on both sides
- Invalid cases fail with the expected validation error
- Invalid upload-path cases fail during bundle preparation instead of silently falling back to preset avatars

- Transcript-provided avatar keys that are not in the preset library fail with a clear validation error
- `avatarMode=preset` configs that include `uploadPath` fail with a clear validation error
- Config participant presets take precedence over transcript avatar hints when both are present
- `--force` rejects dangerous output directories before deleting anything
- Advertised Remotion render scripts keep `src/index.ts` before the composition id
- `container=none + deviceFrame=iphone-dynamic-island` fails with a clear validation error
- Representative render coverage crosses at least one message `appearAt` frame boundary
- Question policy is documented with defaults, triggers, and user-facing wording

````

<!-- ===== FILE: references/test-report.md ===== -->
````md
# Test Report

Date: 2026-07-01

## Scope

Validated the new `$chat-motion-overlay` skill across:

- transcript -> spec generation
- config validation
- bundle preparation
- preset avatar asset copying
- uploaded avatar asset copying
- generated bundle sanitization for uploaded avatar paths
- collision-proof uploaded avatar asset names
- group chat participant-level avatar assignment
- bubble-only right-side alignment
- participant side consistency validation
- Remotion template type safety
- representative still rendering
- documented question strategy for incomplete requests

## Matrix Result

- Total cases: 18
- Passed: 18
- Failed: 0

## Covered Cases

1. `default_wechat_phone_preset_hidden`
2. `plain_bubbles_no_frame_first_message`
3. `telegram_no_frame_always`
4. `messenger_phone_hidden`
5. `upload_phone_always`
6. `mixed_wechat_phone_first_message`
7. `json_spec_only`
8. `group_multi_participant_distinct_presets`
9. `invalid_upload_missing_side`
10. `invalid_mixed_without_upload`
11. `invalid_upload_missing_file`
12. `invalid_participant_side_conflict`
13. `upload_slug_collision_unique_assets`

14. `invalid_transcript_avatar_key`
15. `invalid_preset_mode_upload_path`
16. `config_preset_overrides_transcript_avatar_hint`
17. `invalid_force_dangerous_output_dir`
18. `invalid_bubble_only_phone_frame`

## Issues Found And Fixed

1. `chatSpec.ts` generated readonly arrays while template types expected mutable arrays.
   - Fix: changed template `ChatSpec` types to use `ReadonlyArray`.

2. Config validation for `avatarMode=upload` and `avatarMode=mixed` was too loose.
   - Fix: added explicit validation in `build_chat_overlay_spec.py`.
   - Update: `avatarMode=upload` now requires uploaded avatar paths on participant configs.

3. New skill needed bundled preset avatar assets available in generated Remotion bundles.
   - Fix: added avatar library copying in `prepare_chat_overlay_bundle.py`.

4. User-facing output choices were too technical.
   - Fix: replaced direct `output` selection with `deliveryFormat`, then mapped it internally to render targets and artifact modes.

5. Incomplete user requests needed a consistent clarification strategy.
   - Fix: added a documented question policy with defaults, question limits, and user-facing wording.

6. Missing uploaded avatar files could silently fall back to preset avatars during bundle preparation.
   - Fix: made `prepare_chat_overlay_bundle.py` fail fast when a configured upload path does not exist, and added bundle-stage coverage for that case.

7. Group chats needed participant-level avatars instead of only side-level avatars.
   - Fix: replaced side-level avatar assignment with participant-level preset and upload assignment support.

8. One speaker could be interpreted on both sides if the transcript conflicted.
   - Fix: added participant side consistency validation.

9. Distinct participant names could normalize to the same slug and overwrite uploaded avatar assets.
   - Fix: generated stable unique participant ids and added a collision test with two uploaded avatars.

10. Bubble-only overlays needed explicit right-side row alignment.
    - Fix: split row alignment from avatar/bubble ordering, and added a style assertion for the plain bubble case.

11. Transcript-provided avatar keys that are not in the preset library could silently fall back to a default avatar.
    - Fix: validate transcript avatar hints against `PRESET_KEYS` before storing the participant.

12. `avatarMode=preset` configs with a participant `uploadPath` could render uploaded files instead of preset avatars.
    - Fix: reject `uploadPath` when `avatarMode` is `preset`, only carry upload paths for `upload` and `mixed` modes.

13. Transcript avatar hints took precedence over explicit participant config presets, so config could not override transcript-derived or OCR-derived hints.
    - Fix: changed avatar selection order to config-first (`configured.get("preset") or message["avatar"] or auto...`), consistent with `references/input-format.md`.

14. `--force` could recursively delete arbitrary existing directories when `--output-dir` was mistyped.
    - Fix: reject dangerous targets up front, and only allow `--force` overwrites for previously generated bundle directories marked with `.chat-motion-overlay-bundle`.

15. A failed uploaded-avatar copy could leave a partial bundle behind with `src/chatSpec.ts` still containing local `uploadPath` values.
    - Fix: validate upload sources before copying, delay `chatSpec.ts` writing until sanitization succeeds, and remove the generated bundle if preparation fails mid-run.

16. The documented MOV/WebM export commands and shipped package scripts omitted `src/index.ts`, so Remotion would treat the composition id as the entry file.
    - Fix: update both package scripts and `references/output-modes.md` to use `remotion render src/index.ts ChatMotionOverlay ...`, and keep that path checked in the matrix.

17. `container=none` could still be combined with `deviceFrame=iphone-dynamic-island`, which let a 1080x1920 bubble-only scene render into the smaller phone viewport and clip right-side content.
    - Fix: reject that unsupported combination during config validation, and document it in the config schema, visual rules, and matrix.

18. Bubble wrapping logic introduced `useMemo` calls after a frame-based early return, which could change hook order when playback crossed a message `appearAt` frame.
    - Fix: replace those `useMemo` calls with plain local calculations, and extend render coverage to include frames on both sides of the first message boundary.

## Verification Notes

- Representative bundles were rendered to still images successfully.
- Invalid config cases failed with the expected validation errors.
- Invalid uploaded-avatar file paths failed during bundle preparation with a clear error.
- Generated `chatSpec.ts` bundles kept only participant `uploadAsset` entries and did not leak local `uploadPath` values.
- Uploaded avatar assets stayed unique when participant display names slugified to the same base id.
- Group chat participants resolved to distinct participant avatars instead of sharing side-level avatars.
- Bubble-only transparent overlays explicitly align right-side rows to the right edge.
- Side conflicts for a single participant failed with a clear validation error.
- Bundle type checking passed with `tsc --noEmit`.
- Config participant presets correctly override transcript avatar hints.
- Transcript avatar hints that are not valid preset keys fail with a clear validation error.
- `avatarMode=preset` configs that include `uploadPath` fail with a clear validation error.
- Dangerous `--force` output targets are rejected before any recursive deletion occurs.
- Failed uploaded-avatar copies do not leave a generated `chatSpec.ts` containing local upload paths.
- Shipped Remotion render scripts keep `src/index.ts` before the composition id.
- `container=none + deviceFrame=iphone-dynamic-island` fails with a clear validation error before any bundle or render step.
- Representative render coverage now crosses a message `appearAt` frame boundary instead of checking only a later still.

## References

- Test matrix: `references/test-matrix.md`
- Test runner: `scripts/run_test_matrix.py`

````

<!-- ===== FILE: scripts/build_chat_overlay_spec.py ===== -->
````py
#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path


SIDE_MAP = {"left": "left", "right": "right", "左": "left", "右": "right"}
PRESET_KEYS = [
    "female-bunny-pink",
    "female-cat-orange",
    "female-fox-yellow",
    "male-bear-mint",
    "male-penguin-blue",
    "male-koala-lilac",
]

ALLOWED_CONTAINERS = {"none", "wechat", "telegram", "messenger"}
ALLOWED_AVATAR_MODES = {"preset", "upload", "mixed"}
ALLOWED_DEVICE_FRAMES = {"none", "iphone-dynamic-island"}
ALLOWED_NICKNAME_MODES = {"hidden", "first-message-only", "always"}
ALLOWED_DELIVERY_FORMATS = {"mov", "webm", "json", "remotion", "hyperframe", "preview"}
DELIVERY_TO_OUTPUT = {
    "mov": "mov-alpha",
    "webm": "webm-alpha",
    "json": "json-spec",
    "remotion": "remotion-component",
    "hyperframe": "hyperframe-ready",
    "preview": "preview-only",
}

DEFAULT_CONFIG = {
    "container": "wechat",
    "avatarMode": "preset",
    "deviceFrame": "iphone-dynamic-island",
    "nicknameMode": "hidden",
    "deliveryFormat": "mov",
    "showTimestamp": True,
    "participants": {},
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Build a configurable chat motion overlay scene spec.")
    parser.add_argument("--input", required=True, help="Path to transcript text file")
    parser.add_argument("--config", help="Path to scene config JSON")
    parser.add_argument("--output", help="Path to output JSON file")
    return parser.parse_args()


def parse_transcript(path: Path) -> dict:
    metadata = {"title": "聊天记录", "time": "今天", "start": 15, "gap": 18, "hold": 36}
    raw_messages: list[dict] = []
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        meta_match = re.match(r"^(title|time|start|gap|hold)\s*[:：]\s*(.+)$", line, flags=re.IGNORECASE)
        if meta_match:
            key = meta_match.group(1).strip().lower()
            value = meta_match.group(2).strip()
            metadata[key] = int(value) if key in {"start", "gap", "hold"} else value
            continue
        raw_messages.append(parse_message_line(line))
    return {"metadata": metadata, "messages": raw_messages}


def parse_message_line(line: str) -> dict:
    parts = [part.strip() for part in line.split("|")] if "|" in line else []
    if not parts:
        match = re.match(r"^([^:：]{1,30})[:：]\s*(.+)$", line)
        if not match:
            raise ValueError(f"Cannot parse line: {line}")
        parts = [match.group(1).strip(), match.group(2).strip()]
    result = {"speaker": parts[0], "side": None, "avatar": None, "text": "", "highlight": False}
    if len(parts) == 2:
        result["text"] = parts[1]
        return result
    if len(parts) == 3:
        if is_flag(parts[2]):
            result["text"] = parts[1]
            result["highlight"] = True
            return result
        if is_side(parts[1]):
            result["side"] = SIDE_MAP[parts[1]]
            result["text"] = parts[2]
            return result
        result["text"] = parts[1]
        result["avatar"] = parts[2]
        return result
    if len(parts) >= 4 and is_side(parts[1]):
        result["side"] = SIDE_MAP[parts[1]]
        result["avatar"] = parts[2]
        result["text"] = parts[3]
        result["highlight"] = len(parts) > 4 and is_flag(parts[4])
        return result
    raise ValueError(f"Unsupported message line shape: {line}")


def is_side(value: str) -> bool:
    return value in SIDE_MAP


def is_flag(value: str) -> bool:
    return value.strip().lower() == "highlight"


def load_config(path: str | None) -> dict:
    config = json.loads(json.dumps(DEFAULT_CONFIG))
    if not path:
        validate_config(config)
        return config
    user = json.loads(Path(path).read_text(encoding="utf-8"))
    config.update(user)
    validate_config(config)
    return config


def validate_config(config: dict) -> None:
    if config["container"] not in ALLOWED_CONTAINERS:
        raise ValueError(f"Unsupported container: {config['container']}")
    if config["avatarMode"] not in ALLOWED_AVATAR_MODES:
        raise ValueError(f"Unsupported avatarMode: {config['avatarMode']}")
    if config["deviceFrame"] not in ALLOWED_DEVICE_FRAMES:
        raise ValueError(f"Unsupported deviceFrame: {config['deviceFrame']}")
    if config["nicknameMode"] not in ALLOWED_NICKNAME_MODES:
        raise ValueError(f"Unsupported nicknameMode: {config['nicknameMode']}")
    if config["deliveryFormat"] not in ALLOWED_DELIVERY_FORMATS:
        raise ValueError(f"Unsupported deliveryFormat: {config['deliveryFormat']}")
    if config["container"] == "none" and config["deviceFrame"] == "iphone-dynamic-island":
        raise ValueError("container=none does not support deviceFrame=iphone-dynamic-island; use deviceFrame=none or choose an app container")

    for speaker, participant in config.get("participants", {}).items():
        side = participant.get("side")
        if side and side not in {"left", "right"}:
            raise ValueError(f"Unsupported side for participant {speaker}: {side}")
        preset_key = participant.get("preset")
        if preset_key and preset_key not in PRESET_KEYS:
            raise ValueError(f"Unsupported preset for participant {speaker}: {preset_key}")
        upload_path = participant.get("uploadPath")
        if participant.get("uploadAsset"):
            raise ValueError(f"Participant {speaker} config must use uploadPath, not uploadAsset")
        if config["avatarMode"] == "preset" and upload_path:
            raise ValueError(f"avatarMode=preset does not allow uploadPath for participant {speaker}")
        if config["avatarMode"] == "upload" and not upload_path:
            raise ValueError(f"avatarMode=upload requires uploadPath for participant {speaker}")


def auto_avatar_for_participant(participant_index: int, used_avatar_keys: set[str]) -> str:
    preferred = [*PRESET_KEYS[participant_index:], *PRESET_KEYS[:participant_index]]
    for avatar_key in preferred:
        if avatar_key not in used_avatar_keys:
            return avatar_key
    return PRESET_KEYS[participant_index % len(PRESET_KEYS)]


def configured_participant(speaker: str, config: dict) -> dict:
    return config.get("participants", {}).get(speaker, {})


def build_spec(parsed: dict, config: dict) -> dict:
    meta = parsed["metadata"]
    participants = {}
    used_participant_ids = set()
    order = []
    messages = []
    start = int(meta["start"])
    gap = int(meta["gap"])
    for index, message in enumerate(parsed["messages"]):
        speaker = message["speaker"]
        if speaker not in participants:
            order.append(speaker)
            configured = configured_participant(speaker, config)
            inferred_side = "left" if len(order) == 1 else "right" if len(order) == 2 else "left"
            side = configured.get("side") or message["side"] or inferred_side
            avatar_key = configured.get("preset") or message["avatar"] or auto_avatar_for_participant(
                len(order) - 1, {p["avatarKey"] for p in participants.values()}
            )
            if avatar_key not in PRESET_KEYS:
                raise ValueError(f"Unsupported avatar key for participant {speaker}: {avatar_key}")
            participant = {
                "id": unique_slug(slugify(speaker), used_participant_ids),
                "name": speaker,
                "side": side,
                "avatarKey": avatar_key,
            }
            used_participant_ids.add(participant["id"])
            if config["avatarMode"] in {"upload", "mixed"} and configured.get("uploadPath"):
                participant["uploadPath"] = configured["uploadPath"]
            if config["avatarMode"] == "upload" and not participant.get("uploadPath"):
                raise ValueError(f"avatarMode=upload requires uploadPath for participant {speaker}")
            participants[speaker] = participant
        participant = participants[speaker]
        side = message["side"] or participant["side"]
        if side != participant["side"]:
            raise ValueError(f"Participant {speaker} appears on both {participant['side']} and {side}; use one side per participant")
        avatar_key = participant["avatarKey"]
        if message["avatar"] and message["avatar"] != participant["avatarKey"] and not configured_participant(speaker, config).get("preset"):
            raise ValueError(f"Participant {speaker} has conflicting transcript avatar hints: {participant['avatarKey']} and {message['avatar']}; set a config preset to override")
        messages.append(
            {
                "id": f"msg-{index + 1}",
                "speaker": speaker,
                "text": message["text"].strip(),
                "side": side,
                "avatarKey": avatar_key,
                "appearAt": start + index * gap,
                "highlight": bool(message["highlight"]),
            }
        )
    if config["avatarMode"] == "mixed" and not any(participant.get("uploadPath") for participant in participants.values()):
        raise ValueError("avatarMode=mixed requires at least one upload path")
    duration = start + max(len(messages) - 1, 0) * gap + int(meta["hold"])
    runtime_output = DELIVERY_TO_OUTPUT[config["deliveryFormat"]]
    scene_config = {key: value for key, value in config.items() if key != "participants"}
    return {
        "title": meta["title"],
        "timestamp": meta["time"],
        "durationInFrames": duration,
        "timing": {"start": start, "gap": gap, "hold": int(meta["hold"])},
        "sceneConfig": {**scene_config, "output": runtime_output},
        "participants": list(participants.values()),
        "messages": messages,
    }


def slugify(text: str) -> str:
    lowered = text.strip().lower()
    return re.sub(r"[^a-z0-9\u4e00-\u9fff]+", "-", lowered).strip("-") or "speaker"


def unique_slug(base: str, used: set[str]) -> str:
    if base not in used:
        return base
    index = 2
    while f"{base}-{index}" in used:
        index += 1
    return f"{base}-{index}"


def main() -> None:
    args = parse_args()
    parsed = parse_transcript(Path(args.input))
    config = load_config(args.config)
    spec = build_spec(parsed, config)
    output = json.dumps(spec, ensure_ascii=False, indent=2)
    if args.output:
        Path(args.output).write_text(output + "\n", encoding="utf-8")
    else:
        print(output)


if __name__ == "__main__":
    main()

````

<!-- ===== FILE: scripts/prepare_chat_overlay_bundle.py ===== -->
````py
#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

from build_chat_overlay_spec import build_spec, load_config, parse_transcript


BUNDLE_MARKER = ".chat-motion-overlay-bundle"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Prepare a renderable Remotion chat overlay bundle.")
    parser.add_argument("--transcript", required=True, help="Path to transcript text file")
    parser.add_argument("--config", help="Path to scene config JSON")
    parser.add_argument("--output-dir", required=True, help="Directory to create the Remotion bundle in")
    parser.add_argument("--force", action="store_true", help="Overwrite the output directory if it exists")
    return parser.parse_args()


def script_dir() -> Path:
    return Path(__file__).resolve().parent


def skill_root() -> Path:
    return script_dir().parent


def template_dir() -> Path:
    return skill_root() / "assets" / "remotion-template"


def avatar_library_dir() -> Path:
    return skill_root() / "assets" / "avatar-library"


def repo_root() -> Path:
    return skill_root().parent.parent


def bundle_marker_path(output_dir: Path) -> Path:
    return output_dir / BUNDLE_MARKER


def validate_output_dir(output_dir: Path, force: bool) -> None:
    dangerous_targets = {
        Path.cwd().resolve(),
        Path.home().resolve(),
        repo_root(),
        skill_root(),
        template_dir(),
    }
    if output_dir in dangerous_targets:
        raise SystemExit(
            f"Refusing to use dangerous output directory: {output_dir}. "
            "Choose a dedicated generated-bundle directory instead."
        )
    if output_dir.exists() and force and not bundle_marker_path(output_dir).exists():
        raise SystemExit(
            f"Refusing to overwrite unmanaged output directory: {output_dir}. "
            f"Only directories containing {BUNDLE_MARKER} can be replaced with --force."
        )


def copy_template(output_dir: Path, force: bool) -> None:
    validate_output_dir(output_dir, force)
    if output_dir.exists():
        if not force:
            raise SystemExit(f"Output directory already exists: {output_dir}. Use --force to overwrite.")
        shutil.rmtree(output_dir)
    shutil.copytree(template_dir(), output_dir)
    bundle_marker_path(output_dir).write_text("generated by chat-motion-overlay\n", encoding="utf-8")


def write_chat_spec_ts(spec: dict, output_dir: Path) -> None:
    target = output_dir / "src" / "chatSpec.ts"
    content = "export const chatSpec = " + json.dumps(spec, ensure_ascii=False, indent=2) + " as const;\n"
    target.write_text(content, encoding="utf-8")


def remove_local_upload_paths(spec: dict) -> None:
    for participant in spec["participants"]:
        participant.pop("uploadPath", None)


def copy_avatar_assets(spec: dict, output_dir: Path) -> dict:
    upload_sources: list[tuple[dict, Path]] = []
    for participant in spec["participants"]:
        upload_path = participant.get("uploadPath")
        if upload_path:
            source = Path(upload_path).expanduser().resolve()
            if not source.exists():
                raise SystemExit(
                    f"Configured uploadPath for participant {participant['name']} does not exist: {source}. "
                    "Fix the upload avatar path before preparing the bundle."
                )
            upload_sources.append((participant, source))
    public_dir = output_dir / "public"
    public_dir.mkdir(parents=True, exist_ok=True)
    for preset_file in avatar_library_dir().glob("*.png"):
        shutil.copy2(preset_file, public_dir / preset_file.name)
    for participant, source in upload_sources:
        target_name = f"{participant['id']}-upload{source.suffix.lower()}"
        shutil.copy2(source, public_dir / target_name)
        participant["uploadAsset"] = target_name
    remove_local_upload_paths(spec)
    return spec


def main() -> None:
    args = parse_args()
    parsed = parse_transcript(Path(args.transcript))
    config = load_config(args.config)
    spec = build_spec(parsed, config)
    out_dir = Path(args.output_dir).resolve()
    copy_template(out_dir, args.force)
    try:
        sanitized_spec = copy_avatar_assets(spec, out_dir)
        write_chat_spec_ts(sanitized_spec, out_dir)
    except BaseException:
        if out_dir.exists():
            shutil.rmtree(out_dir)
        raise
    print(f"Prepared Remotion bundle at {out_dir}")


if __name__ == "__main__":
    main()

````

<!-- ===== FILE: scripts/run_test_matrix.py ===== -->
````py
#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
from pathlib import Path


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run the chat-motion-overlay test matrix.")
    parser.add_argument("--skill-root", required=True, help="Path to the skill root")
    parser.add_argument("--work-dir", required=True, help="Directory for generated test artifacts")
    parser.add_argument("--node-modules", required=True, help="Resolved node_modules directory with remotion/react/typescript")
    parser.add_argument("--render", action="store_true", help="Render representative still frames with Remotion")
    return parser.parse_args()


def write_json(path: Path, payload: dict) -> None:
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def run(cmd: list[str], cwd: Path) -> subprocess.CompletedProcess[str]:
    return subprocess.run(cmd, cwd=str(cwd), text=True, capture_output=True)


def read_generated_chat_spec(path: Path) -> dict:
    content = path.read_text(encoding="utf-8").strip()
    prefix = "export const chatSpec = "
    suffix = " as const;"
    if not content.startswith(prefix) or not content.endswith(suffix):
        raise ValueError("Generated chatSpec.ts has an unexpected shape")
    return json.loads(content[len(prefix) : -len(suffix)])


def participant(side: str, preset: str, upload_path: str | None = None) -> dict:
    value = {"side": side, "preset": preset}
    if upload_path:
        value["uploadPath"] = upload_path
    return value


def base_config(
    *,
    container: str = "wechat",
    avatar_mode: str = "preset",
    device_frame: str = "iphone-dynamic-island",
    nickname_mode: str = "hidden",
    delivery_format: str = "mov",
    show_timestamp: bool = True,
    participants: dict | None = None,
) -> dict:
    return {
        "container": container,
        "avatarMode": avatar_mode,
        "deviceFrame": device_frame,
        "nicknameMode": nickname_mode,
        "deliveryFormat": delivery_format,
        "showTimestamp": show_timestamp,
        "participants": participants or {
            "闺蜜": participant("left", "female-bunny-pink"),
            "老婆": participant("right", "female-cat-orange"),
        },
    }


def main() -> None:
    args = parse_args()
    skill_root = Path(args.skill_root).resolve()
    work_dir = Path(args.work_dir).resolve()
    node_modules = Path(args.node_modules).resolve()
    build_script = skill_root / "scripts" / "build_chat_overlay_spec.py"
    bundle_script = skill_root / "scripts" / "prepare_chat_overlay_bundle.py"
    transcript = skill_root / "assets" / "examples" / "chat-transcript.txt"
    avatar_dir = skill_root / "assets" / "avatar-library"

    if work_dir.exists():
        shutil.rmtree(work_dir)
    work_dir.mkdir(parents=True)

    sample_upload_left = str((avatar_dir / "female-bunny-pink.png").resolve())
    sample_upload_right = str((avatar_dir / "male-penguin-blue.png").resolve())
    missing_upload_right = str((avatar_dir / "missing-avatar-does-not-exist.png").resolve())
    group_transcript = """title: 闺蜜群（6）
time: 星期二 22:19

闺蜜A|左|今天没运动
闺蜜B|左|我也没动
老婆|右|那晚上少喝奶茶
闺蜜C|左|我已经点好了
"""
    side_conflict_transcript = """title: 冲突测试
time: 今天

老婆|right|第一句在右侧
老婆|left|第二句错误地在左侧
"""
    colliding_upload_transcript = """title: 碰撞测试
time: 今天

A!|left|第一个上传头像
A?|right|第二个上传头像
"""

    cases = [
        {
            "name": "default_wechat_phone_preset_hidden",
            "config": base_config(),
            "render": True,
            "render_frames": [14, 15, 120],
            "expect_fail": False,
        },
        {
            "name": "plain_bubbles_no_frame_first_message",
            "config": base_config(container="none", device_frame="none", nickname_mode="first-message-only", delivery_format="remotion", show_timestamp=False),
            "render": True,
            "expect_fail": False,
        },
        {
            "name": "telegram_no_frame_always",
            "config": base_config(
                container="telegram",
                device_frame="none",
                nickname_mode="always",
                delivery_format="webm",
                participants={
                    "闺蜜": participant("left", "female-fox-yellow"),
                    "老婆": participant("right", "male-bear-mint"),
                },
            ),
            "render": True,
            "expect_fail": False,
        },
        {
            "name": "messenger_phone_hidden",
            "config": base_config(
                container="messenger",
                participants={
                    "闺蜜": participant("left", "male-koala-lilac"),
                    "老婆": participant("right", "male-penguin-blue"),
                },
            ),
            "render": True,
            "expect_fail": False,
        },
        {
            "name": "upload_phone_always",
            "config": base_config(
                avatar_mode="upload",
                nickname_mode="always",
                participants={
                    "闺蜜": participant("left", "female-bunny-pink", sample_upload_left),
                    "老婆": participant("right", "female-cat-orange", sample_upload_right),
                },
            ),
            "render": True,
            "expect_fail": False,
        },
        {
            "name": "mixed_wechat_phone_first_message",
            "config": base_config(
                avatar_mode="mixed",
                nickname_mode="first-message-only",
                delivery_format="hyperframe",
                participants={
                    "闺蜜": participant("left", "female-bunny-pink", sample_upload_left),
                    "老婆": participant("right", "male-penguin-blue"),
                },
            ),
            "render": True,
            "expect_fail": False,
        },
        {
            "name": "json_spec_only",
            "config": base_config(delivery_format="json"),
            "render": False,
            "expect_fail": False,
        },
        {
            "name": "group_multi_participant_distinct_presets",
            "transcriptContent": group_transcript,
            "config": base_config(
                nickname_mode="always",
                delivery_format="preview",
                participants={
                    "闺蜜A": participant("left", "female-bunny-pink"),
                    "闺蜜B": participant("left", "female-fox-yellow"),
                    "老婆": participant("right", "female-cat-orange"),
                    "闺蜜C": participant("left", "male-bear-mint"),
                },
            ),
            "render": False,
            "expect_fail": False,
            "assert_distinct_participant_avatars": True,
        },
        {
            "name": "invalid_upload_missing_side",
            "config": base_config(
                avatar_mode="upload",
                nickname_mode="always",
                participants={
                    "闺蜜": participant("left", "female-bunny-pink", sample_upload_left),
                    "老婆": participant("right", "female-cat-orange"),
                },
            ),
            "render": False,
            "expect_fail": True,
            "expected_error": "avatarMode=upload requires uploadPath for participant 老婆",
        },
        {
            "name": "invalid_mixed_without_upload",
            "config": base_config(avatar_mode="mixed", nickname_mode="always"),
            "render": False,
            "expect_fail": True,
            "expected_error": "avatarMode=mixed requires at least one upload path",
        },
        {
            "name": "invalid_upload_missing_file",
            "config": base_config(
                avatar_mode="upload",
                nickname_mode="always",
                participants={
                    "闺蜜": participant("left", "female-bunny-pink", sample_upload_left),
                    "老婆": participant("right", "female-cat-orange", missing_upload_right),
                },
            ),
            "render": False,
            "expect_fail": True,
            "fail_phase": "prepare_bundle",
            "expected_error": "Configured uploadPath for participant 老婆 does not exist",
            "assert_no_partial_spec_on_failure": True,
        },
        {
            "name": "invalid_force_dangerous_output_dir",
            "config": base_config(),
            "render": False,
            "expect_fail": True,
            "fail_phase": "prepare_bundle",
            "output_dir": "__SKILL_ROOT__",
            "expected_error": "Refusing to use dangerous output directory",
        },
        {
            "name": "invalid_participant_side_conflict",
            "transcriptContent": side_conflict_transcript,
            "config": base_config(
                participants={
                    "老婆": participant("right", "female-cat-orange"),
                },
            ),
            "render": False,
            "expect_fail": True,
            "expected_error": "Participant 老婆 appears on both right and left",
        },
       {
           "name": "upload_slug_collision_unique_assets",
           "transcriptContent": colliding_upload_transcript,
           "config": base_config(
               avatar_mode="upload",
               nickname_mode="always",
               participants={
                   "A!": participant("left", "female-bunny-pink", sample_upload_left),
                   "A?": participant("right", "male-penguin-blue", sample_upload_right),
               },
           ),
           "render": False,
           "expect_fail": False,
           "assert_unique_upload_assets": True,
       },
        {
            "name": "invalid_transcript_avatar_key",
            "transcriptContent": "title: 无效头像测试\ntime: 今天\n\nAlice|left|not-a-preset|你好\n",
            "config": base_config(nickname_mode="always"),
            "render": False,
            "expect_fail": True,
            "expected_error": "Unsupported avatar key for participant Alice: not-a-preset",
        },
        {
            "name": "invalid_preset_mode_upload_path",
            "config": base_config(
                avatar_mode="preset",
                nickname_mode="always",
                participants={
                    "闺蜜": participant("left", "female-bunny-pink"),
                    "老婆": participant("right", "female-cat-orange", sample_upload_left),
                },
            ),
            "render": False,
            "expect_fail": True,
            "expected_error": "avatarMode=preset does not allow uploadPath for participant 老婆",
        },
        {
            "name": "config_preset_overrides_transcript_avatar_hint",
            "transcriptContent": "title: \u4f18\u5148\u7ea7\u6d4b\u8bd5\ntime: \u4eca\u5929\n\nAlice|left|male-penguin-blue|\u4f60\u597d\n",
            "config": base_config(
                nickname_mode="always",
                participants={
                    "Alice": participant("left", "female-bunny-pink"),
                },
            ),
            "render": False,
            "expect_fail": False,
            "assert_config_avatar_wins": True,
        },
   ]

    results = []
    tsc_bin = node_modules / ".bin" / "tsc"
    remotion_bin = node_modules / ".bin" / "remotion"

    for case in cases:
        case_dir = work_dir / case["name"]
        case_dir.mkdir(parents=True, exist_ok=True)
        config_path = case_dir / "config.json"
        spec_path = case_dir / "spec.json"
        bundle_dir = skill_root if case.get("output_dir") == "__SKILL_ROOT__" else case_dir / "bundle"
        active_transcript = transcript
        if case.get("transcriptContent"):
            active_transcript = case_dir / "transcript.txt"
            active_transcript.write_text(case["transcriptContent"], encoding="utf-8")
        write_json(config_path, case["config"])

        build_proc = run(
            [sys.executable, str(build_script), "--input", str(active_transcript), "--config", str(config_path), "--output", str(spec_path)],
            cwd=skill_root,
        )

        if case["expect_fail"]:
            fail_phase = case.get("fail_phase", "validation")
            if fail_phase == "validation":
                combined = (build_proc.stdout or "") + (build_proc.stderr or "")
                ok = build_proc.returncode != 0 and case["expected_error"] in combined
                results.append({"case": case["name"], "status": "passed" if ok else "failed", "phase": "validation", "details": combined.strip()})
                continue

            if build_proc.returncode != 0:
                results.append({"case": case["name"], "status": "failed", "phase": "build_spec", "details": build_proc.stderr.strip() or build_proc.stdout.strip()})
                continue

            bundle_proc = run(
                [
                    sys.executable,
                    str(bundle_script),
                    "--transcript",
                    str(transcript),
                    "--config",
                    str(config_path),
                    "--output-dir",
                    str(bundle_dir),
                    "--force",
                ],
                cwd=skill_root,
            )
            combined = (bundle_proc.stdout or "") + (bundle_proc.stderr or "")
            ok = bundle_proc.returncode != 0 and case["expected_error"] in combined
            if ok and case.get("assert_no_partial_spec_on_failure"):
                leaked_spec = bundle_dir / "src" / "chatSpec.ts"
                if leaked_spec.exists():
                    leaked_content = leaked_spec.read_text(encoding="utf-8")
                    if "uploadPath" in leaked_content or "/Users/" in leaked_content:
                        ok = False
                        combined += "\nPartial bundle leaked local upload-path data after failure."
            results.append({"case": case["name"], "status": "passed" if ok else "failed", "phase": "prepare_bundle", "details": combined.strip()})
            continue

        if build_proc.returncode != 0:
            results.append({"case": case["name"], "status": "failed", "phase": "build_spec", "details": build_proc.stderr.strip()})
            continue

        if case.get("assert_distinct_participant_avatars"):
            spec = json.loads(spec_path.read_text(encoding="utf-8"))
            avatar_keys = [participant["avatarKey"] for participant in spec["participants"]]
            if len(set(avatar_keys)) != len(avatar_keys):
                results.append(
                    {
                        "case": case["name"],
                        "status": "failed",
                        "phase": "participant_avatars",
                        "details": f"Expected distinct participant avatars, got {avatar_keys}",
                    }
                )
                continue

        if case.get("assert_config_avatar_wins"):
            spec = json.loads(spec_path.read_text(encoding="utf-8"))
            alice = next(p for p in spec["participants"] if p["name"] == "Alice")
            if alice["avatarKey"] != "female-bunny-pink":
                results.append(
                    {
                        "case": case["name"],
                        "status": "failed",
                        "phase": "config_avatar_precedence",
                        "details": f"Expected config preset female-bunny-pink, got {alice['avatarKey']}",
                    }
                )
                continue

        bundle_proc = run(
            [
                sys.executable,
                str(bundle_script),
                "--transcript",
                str(active_transcript),
                "--config",
                str(config_path),
                "--output-dir",
                str(bundle_dir),
                "--force",
            ],
            cwd=skill_root,
        )
        if bundle_proc.returncode != 0:
            results.append({"case": case["name"], "status": "failed", "phase": "prepare_bundle", "details": bundle_proc.stderr.strip()})
            continue

        generated_spec = (bundle_dir / "src" / "chatSpec.ts").read_text(encoding="utf-8")
        if "uploadPath" in generated_spec or "UploadPath" in generated_spec or "/Users/" in generated_spec:
            results.append(
                {
                    "case": case["name"],
                    "status": "failed",
                    "phase": "bundle_sanitization",
                    "details": "Generated chatSpec.ts leaked local upload-path data.",
                }
            )
            continue

        if case.get("assert_unique_upload_assets"):
            spec = read_generated_chat_spec(bundle_dir / "src" / "chatSpec.ts")
            upload_assets = [participant.get("uploadAsset") for participant in spec["participants"] if participant.get("uploadAsset")]
            if len(upload_assets) != len(set(upload_assets)):
                results.append(
                    {
                        "case": case["name"],
                        "status": "failed",
                        "phase": "upload_asset_collision",
                        "details": f"Expected unique upload assets, got {upload_assets}",
                    }
                )
                continue
            missing_assets = [asset for asset in upload_assets if not (bundle_dir / "public" / asset).exists()]
            if missing_assets:
                results.append(
                    {
                        "case": case["name"],
                        "status": "failed",
                        "phase": "upload_asset_files",
                        "details": f"Generated spec references missing upload assets: {missing_assets}",
                    }
                )
                continue

        if case["name"] == "plain_bubbles_no_frame_first_message":
            bubble_scene_source = (bundle_dir / "src" / "components" / "BubbleScene.tsx").read_text(encoding="utf-8")
            if 'justifyContent: isRight ? "flex-end" : "flex-start"' not in bubble_scene_source:
                results.append(
                    {
                        "case": case["name"],
                        "status": "failed",
                        "phase": "bubble_alignment_style",
                        "details": "Bubble-only template must explicitly justify right-side rows to flex-end.",
                    }
                )
                continue

        if case["name"] == "default_wechat_phone_preset_hidden":
            package_json_source = (bundle_dir / "package.json").read_text(encoding="utf-8")
            if '"render:mov": "remotion render src/index.ts ChatMotionOverlay out/chat-motion-overlay.mov' not in package_json_source:
                results.append(
                    {
                        "case": case["name"],
                        "status": "failed",
                        "phase": "render_command",
                        "details": "render:mov script must include src/index.ts before the composition id.",
                    }
                )
                continue
            if '"render:webm": "remotion render src/index.ts ChatMotionOverlay out/chat-motion-overlay.webm' not in package_json_source:
                results.append(
                    {
                        "case": case["name"],
                        "status": "failed",
                        "phase": "render_command",
                        "details": "render:webm script must include src/index.ts before the composition id.",
                    }
                )
                continue

        symlink_path = bundle_dir / "node_modules"
        if symlink_path.exists() or symlink_path.is_symlink():
            symlink_path.unlink()
        symlink_path.symlink_to(node_modules)

        tsc_proc = run([str(tsc_bin), "--noEmit", "-p", str(bundle_dir / "tsconfig.json")], cwd=bundle_dir)
        if tsc_proc.returncode != 0:
            results.append({"case": case["name"], "status": "failed", "phase": "tsc", "details": tsc_proc.stderr.strip() or tsc_proc.stdout.strip()})
            continue

        if args.render and case["render"]:
            frames = case.get("render_frames", [120])
            for frame in frames:
                preview_path = case_dir / f"preview-frame-{frame}.png"
                render_proc = run(
                    [str(remotion_bin), "still", "src/index.ts", "ChatMotionOverlay", str(preview_path), "--scale=0.15", f"--frame={frame}"],
                    cwd=bundle_dir,
                )
                if render_proc.returncode != 0:
                    results.append(
                        {
                            "case": case["name"],
                            "status": "failed",
                            "phase": "render",
                            "details": f"frame={frame}: " + (render_proc.stderr.strip() or render_proc.stdout.strip()),
                        }
                    )
                    break
            else:
                results.append({"case": case["name"], "status": "passed", "phase": "complete", "details": ""})
                continue

        results.append({"case": case["name"], "status": "passed", "phase": "complete", "details": ""})

    summary = {
        "passed": sum(1 for item in results if item["status"] == "passed"),
        "failed": sum(1 for item in results if item["status"] == "failed"),
        "results": results,
    }
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

````